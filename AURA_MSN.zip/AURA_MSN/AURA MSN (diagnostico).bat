@echo off
rem Abre o AURA MSN mostrando as mensagens, para descobrir problemas.
cd /d "%~dp0"
echo ==== AURA MSN - modo diagnostico ====
echo.
where py >/dev/null 2>nul
if %errorlevel%==0 goto usa_py
where python >/dev/null 2>nul
if %errorlevel%==0 goto usa_python
echo O Python 3 NAO esta instalado neste computador.
echo De dois cliques em "INSTALAR NO WINDOWS.bat" para instalar tudo.
goto fim
:usa_py
py -3 --version
py -3 "%~dp0aura_msn.py"
goto fim
:usa_python
python --version
python "%~dp0aura_msn.py"
:fim
echo.
echo ==== Fim. Se apareceu algum erro acima, tire um print desta janela. ====
pause
