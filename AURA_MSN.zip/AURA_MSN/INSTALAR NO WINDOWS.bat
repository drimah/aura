@echo off
rem Instala o AURA MSN no Windows (dois cliques).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-windows.ps1" %*
echo.
pause
