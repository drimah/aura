# AURA MSN 26

Um mensageiro instantâneo inspirado nos programas de bate-papo dos anos 2000, imaginado
como se tivesse continuado a evoluir por 20 anos.

Você **cria uma conta com seu e-mail ou entra com o Google** e conversa com qualquer pessoa pela
internet, como no MSN de antigamente. O servidor é seu: ele roda na sua própria hospedagem
(`https://drimah.com.br/aura`), então o AURA não morre se alguém desligar um servidor de terceiros.
Se preferir, ainda existe o **modo rede local**, sem conta e sem servidor: os computadores da mesma
rede se encontram sozinhos.

Funciona no **Windows 10, Windows 11 e Linux Mint** (e em outros Linux com Python 3).

## O que ele faz

| Clássico dos anos 2000 | Como ficou no AURA |
|---|---|
| Entrar com e-mail e senha | Conta com e-mail (código de confirmação por e-mail), "Esqueci minha senha" e **Entrar com Google**. Escolha "Entrar como: Ocupado/Invisível" já na tela de login |
| Adicionar contato pelo e-mail | Pedido de amizade que a outra pessoa aceita ou recusa. Se ela ainda não tem conta, dá para mandar um convite por e-mail |
| Lista de contatos com status | Status com anel colorido: Disponível, Ausente, Ocupado e Invisível. Grupos Favoritos, Disponíveis e Offline |
| Mensagem pessoal | Editável direto no cabeçalho, com emoticons |
| Foto de exibição | Recortada e reduzida automaticamente. Sem foto, mostra as iniciais num gradiente |
| "Chamar a atenção" | Tremida na janela + som (com limite de tempo para ninguém abusar) |
| Emoticons `:)` `(y)` `<3` | Viram emojis Unicode. Painel de emojis e emoji sozinho aparece gigante |
| Envio de arquivos | Até 25 MB: arraste para a conversa, cole uma imagem (Ctrl+V) ou use 📎. Imagens aparecem inline |
| "Fulano está digitando" | ✔ |
| Mensagens offline | O servidor guarda e entrega quando o contato entrar. Sem internet, ficam na fila (⏳) e saem quando a conexão voltar |
| — | A mesma conta em vários computadores: o que você manda ou lê num aparece no outro |
| — | Confirmação de entrega ✓ e de leitura ✓✓ |
| — | Reações às mensagens (👍 ❤️ 😂 …) |
| — | Busca em todas as conversas e dentro de uma conversa |
| — | Tema claro/escuro automático e 8 cores de destaque |
| — | Notificações nativas do sistema e título piscando |
| — | Ausente automático após 10 minutos sem uso |
| — | Apelidos, favoritos, ocultar e bloquear contatos |
| — | *negrito*, _itálico_, ~riscado~ e links clicáveis |

## Instalação

### Windows 10/11
1. Clique com o botão direito em **`instalar-windows.ps1`** e escolha **Executar com o PowerShell**.
   Se o Python 3 não estiver instalado, o script instala sozinho pelo `winget`.
2. Use o atalho **AURA MSN** no Menu Iniciar ou na Área de Trabalho.
3. Entre com seu e-mail ou crie uma conta. Só no modo rede local o Firewall do Windows pergunta
   alguma coisa: nesse caso marque **Redes privadas** e clique em **Permitir**.

Para usar sem instalar, dê dois cliques em **`AURA MSN.bat`**.

### Linux Mint
```bash
bash instalar-linux-mint.sh
```
Depois procure **AURA MSN** no menu. Para ele abrir numa janela própria, sem barra de
endereço, instale o Chromium (`sudo apt install chromium`). Sem o Chromium, ele abre como aba do Firefox.

Para desinstalar, use `bash instalar-linux-mint.sh --desinstalar` ou
`instalar-windows.ps1 -Desinstalar`.

## O servidor (uma vez só, na HostGator)
A pasta **`servidor/`** deste ZIP tem tudo o que vai para a hospedagem, e o passo a passo com os
cliques no cPanel está em **`servidor/LEIA-ME-SERVIDOR.md`**. O aplicativo já vem apontando para
`https://drimah.com.br/aura` (arquivo `aura_config.json`). Se um dia mudar de domínio, é só
editar esse arquivo.

Quem só vai **usar** o AURA não precisa da pasta `servidor`: basta instalar o aplicativo e criar a conta.

## Onde ficam os dados
- Perfil, contatos e histórico (cada conta numa subpasta `conta-N`):
  - Windows: `%APPDATA%\AURAMSN\`
  - Linux: `~/.local/share/aura-msn/`
- A sessão fica lembrada: na próxima vez o AURA já abre conectado. Para trocar de conta, use
  ⚙ Configurações → **Sair da conta**.
- Arquivos recebidos: `Downloads/AURA MSN/`

## Opções de linha de comando
```
python aura_msn.py --perfil maria    # outro perfil (duas contas no mesmo PC)
python aura_msn.py --manter-aberto   # continua online mesmo com a janela fechada
python aura_msn.py --sem-janela      # só o serviço; mostra o endereço da interface
```

## Privacidade e limitações
- No modo conta, tudo viaja por **HTTPS** até o seu servidor. O servidor guarda mensagens e arquivos
  só por 30 dias, o tempo de entregar a todos os seus computadores, e apaga sozinho depois.
  As mensagens não têm criptografia de ponta a ponta: quem administra o servidor (você) consegue ver o banco.
- No modo rede local, as mensagens vão direto de um computador para o outro e **não são criptografadas**,
  então use esse modo só em redes de confiança.
- A interface só aceita conexões do próprio computador e exige um token aleatório criado a cada execução.
- Ainda não tem conversas em grupo nem chamadas de voz ou vídeo.

Requisitos: Python 3.8 ou mais novo, só a biblioteca padrão, sem dependências extras.
