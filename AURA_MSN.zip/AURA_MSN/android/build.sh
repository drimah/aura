#!/bin/bash
# Gera AURA_MSN.apk (sem Gradle): javac -> dx -> aapt -> zipalign -> apksigner
set -euo pipefail
cd "$(dirname "$0")"
SDK=/usr/lib/android-sdk
JAR=$SDK/platforms/android-23/android.jar
rm -rf out && mkdir -p out/classes out/gen
aapt package -f -m -J out/gen -M AndroidManifest.xml -S res -I "$JAR"
javac -source 8 -target 8 -encoding UTF-8 -Xlint:-options -bootclasspath "$JAR" -d out/classes $(find src out/gen -name '*.java')
dalvik-exchange --dex --output=out/classes.dex out/classes
aapt package -f -M AndroidManifest.xml -S res -I "$JAR" -F out/unsigned.apk
(cd out && aapt add unsigned.apk classes.dex >/dev/null)
zipalign -f -p 4 out/unsigned.apk out/aligned.apk
if [ ! -f aura-release.keystore ]; then
  echo "AVISO: sem a chave original o Android nao aceita atualizar o app ja instalado."
  keytool -genkeypair -keystore aura-release.keystore -storepass auramsn2026 -keypass auramsn2026 -alias aura \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=AURA MSN, O=Drimah, C=BR" >/dev/null 2>&1
fi
apksigner sign --ks aura-release.keystore --ks-pass pass:auramsn2026 --key-pass pass:auramsn2026 --ks-key-alias aura \
  --min-sdk-version 23 --out AURA_MSN.apk out/aligned.apk
apksigner verify --verbose AURA_MSN.apk | head -4
ls -la AURA_MSN.apk
