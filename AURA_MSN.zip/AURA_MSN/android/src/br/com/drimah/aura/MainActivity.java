package br.com.drimah.aura;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Constructor;

/** AURA MSN para Android: a interface vem de https://drimah.com.br/aura/app/ (sempre atualizada). */
public class MainActivity extends Activity {
    static final String HOME = "https://drimah.com.br/aura/app/";
    static final String CHANNEL = "aura_msgs";
    static final int PICK = 41;

    WebView web;
    ValueCallback<Uri[]> fileCb;
    boolean visible = true;
    int notifId = 1;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setUserAgentString(s.getUserAgentString() + " AuraMSN-Android/26.2");
        web.addJavascriptInterface(new Bridge(), "AuraAndroid");

        web.setWebViewClient(new WebViewClient() {
            boolean external(String url) {
                return !(url.startsWith("https://drimah.com.br/aura/app") || url.startsWith("about:") || url.startsWith("blob:") || url.startsWith("data:"));
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (!external(url)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { /* sem app */ }
                return true;
            }
            @Override
            public void onReceivedError(WebView v, int code, String desc, String url) {
                if (url != null && url.startsWith(HOME)) showOffline();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = p.getAcceptTypes();
                String type = (types != null && types.length > 0 && types[0] != null && types[0].length() > 0) ? types[0] : "*/*";
                i.setType(type);
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "Escolher arquivo"), PICK);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        }
        createChannel();
        if (saved != null) web.restoreState(saved);
        else web.loadUrl(HOME);
    }

    void showOffline() {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
            + "<body style='margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:sans-serif;"
            + "background:linear-gradient(135deg,#5b8cff,#8b5cf6 60%,#14b8a6)'><div style='background:#fff;border-radius:20px;padding:28px;margin:20px;text-align:center'>"
            + "<h2 style='margin:0 0 8px'>Sem internet</h2><p style='color:#555'>O AURA MSN precisa de internet para abrir.</p>"
            + "<button onclick=\"location.href='" + HOME + "'\" style='border:0;background:#3b82f6;color:#fff;border-radius:12px;padding:12px 22px;font-size:16px'>Tentar de novo</button>"
            + "</div></body></html>";
        web.loadDataWithBaseURL("about:blank", html, "text/html", "utf-8", null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req != PICK || fileCb == null) { super.onActivityResult(req, res, data); return; }
        Uri[] out = null;
        if (res == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                out = new Uri[n];
                for (int k = 0; k < n; k++) out[k] = data.getClipData().getItemAt(k).getUri();
            } else if (data.getData() != null) {
                out = new Uri[]{data.getData()};
            }
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.auraBack && window.auraBack()) ? 'yes' : 'no'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (v == null || !v.contains("yes")) moveTaskToBack(true);
            }
        });
    }

    void setPageVisible(boolean on) {
        visible = on;
        if (web != null) web.evaluateJavascript("window.__auraSetHidden && window.__auraSetHidden(" + (!on) + ")", null);
    }
    @Override protected void onResume() { super.onResume(); setPageVisible(true); cancelNotifs(); }
    @Override protected void onPause() { super.onPause(); setPageVisible(false); }
    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); web.saveState(b); }

    void cancelNotifs() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancelAll();
    }

    /* NotificationChannel só existe a partir do Android 8: criado por reflexão para compilar com a API 23. */
    void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            Class<?> ch = Class.forName("android.app.NotificationChannel");
            Constructor<?> c = ch.getConstructor(String.class, CharSequence.class, int.class);
            Object channel = c.newInstance(CHANNEL, "Mensagens", 4 /* IMPORTANCE_HIGH */);
            ch.getMethod("enableVibration", boolean.class).invoke(channel, true);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationManager.class.getMethod("createNotificationChannel", ch).invoke(nm, channel);
        } catch (Exception e) { /* ignora */ }
    }

    void showNotification(String title, String body) {
        try {
            Intent open = new Intent(this, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | 0x04000000 /* FLAG_IMMUTABLE */);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                b = Notification.Builder.class.getConstructor(Context.class, String.class).newInstance(this, CHANNEL);
            } else {
                b = new Notification.Builder(this);
                b.setPriority(Notification.PRIORITY_HIGH);
                b.setDefaults(Notification.DEFAULT_ALL);
            }
            b.setSmallIcon(getApplicationInfo().icon)
             .setContentTitle(title)
             .setContentText(body)
             .setStyle(new Notification.BigTextStyle().bigText(body))
             .setAutoCancel(true)
             .setContentIntent(pi);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(notifId++, b.build());
        } catch (Exception e) { /* sem permissão: ignora */ }
    }

    class Bridge {
        @JavascriptInterface
        public boolean isVisible() { return visible; }

        @JavascriptInterface
        public void notify(final String title, final String body) {
            if (visible) return;
            runOnUiThread(new Runnable() { public void run() { showNotification(title, body); } });
        }

        @JavascriptInterface
        public void vibrate(long ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(new long[]{0, 120, 80, 120, 80, 220}, -1);
            } catch (Exception e) { /* ignora */ }
        }

        @JavascriptInterface
        public String saveFile(String name, String mime, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                if (mime == null || mime.length() == 0) mime = "application/octet-stream";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put("_display_name", name);
                    cv.put("mime_type", mime);
                    cv.put("relative_path", "Download/AURA MSN");
                    Uri uri = getContentResolver().insert(Uri.parse("content://media/external/downloads"), cv);
                    if (uri == null) return "erro";
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    os.write(data);
                    os.close();
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AURA MSN");
                    dir.mkdirs();
                    FileOutputStream fo = new FileOutputStream(new File(dir, name));
                    fo.write(data);
                    fo.close();
                }
                return "ok";
            } catch (Exception e) {
                return "erro: " + e.getMessage();
            }
        }
    }
}
