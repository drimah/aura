#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AURA MSN 26
Mensageiro instantâneo com conta (e-mail ou Google) pelo servidor AURA, ou ponto a ponto na rede local.

- Modo conta: conversa com qualquer pessoa pela internet, via servidor PHP (servidor/aura).
- Modo rede local: os computadores se acham sozinhos na rede, sem servidor nenhum.
- Funciona no Windows 10/11 e no Linux (Mint, Ubuntu...) usando apenas Python 3.8+.
- Interface moderna aberta numa janela própria (Edge/Chrome/Chromium em modo app).

Uso:
    python3 aura_msn.py                 abre o mensageiro
    python3 aura_msn.py --perfil maria  usa outro perfil (várias contas no mesmo PC)
    python3 aura_msn.py --gerar-icones  gera icone.png / icone.ico na pasta web/
"""
from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
import json
import mimetypes
import os
import queue
import re
import secrets
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import ProxyHandler, Request, build_opener, urlopen

APP_NAME = "AURA MSN"
VERSION = "26.2.1"
PROTO = 1
DISCOVERY_PORT = 47100
P2P_PORT = 47101
PRESENCE_EVERY = 4          # segundos entre anúncios de presença
ONLINE_TTL = 15             # sem anúncio por esse tempo => offline
MAX_FILE = 25 * 1024 * 1024
MAX_BODY = MAX_FILE * 4 // 3 + 256 * 1024
MAX_TEXT = 8000
MAX_AVATAR = 400 * 1024
STATUSES = {"online", "away", "busy", "invisible"}
PEER_STATUSES = {"online", "away", "busy", "offline"}
APP_DIR = Path(__file__).resolve().parent
WEB_DIR = APP_DIR / "web"
CONFIG_FILE = APP_DIR / "aura_config.json"
POLL_EVERY = 2.0            # segundos entre consultas ao servidor (modo conta)
OPENER = build_opener(ProxyHandler({}))  # nunca usar proxy para falar com a rede local


# ----------------------------------------------------------------- utilidades
def now() -> float:
    return time.time()


def data_root() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("APPDATA", str(Path.home()))) / "AURAMSN"
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "aura-msn"


def downloads_dir() -> Path:
    d = Path.home() / "Downloads"
    if os.name != "nt" and shutil.which("xdg-user-dir"):
        try:
            out = subprocess.run(["xdg-user-dir", "DOWNLOAD"], capture_output=True,
                                 text=True, timeout=3).stdout.strip()
            if out and out != str(Path.home()):
                d = Path(out)
        except Exception:
            pass
    return d / APP_NAME


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, obj) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)


_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


def safe_name(name) -> str:
    name = str(name).replace("\\", "/").split("/")[-1]
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name).strip(" .")
    if name.split(".")[0].upper() in _RESERVED:
        name = "_" + name
    return name[:150] or "arquivo"


def unique_path(folder: Path, name: str) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    p = folder / name
    i = 1
    while p.exists():
        p = folder / f"{Path(name).stem} ({i}){Path(name).suffix}"
        i += 1
    return p


def primary_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # não envia nada, só escolhe a interface
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def local_ips() -> list[str]:
    ips = {primary_ip()}
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except Exception:
        pass
    ips = {ip for ip in ips if not ip.startswith("127.") and not ip.startswith("169.254.")}
    return sorted(ips) or ["127.0.0.1"]


def is_loopback(host: str) -> bool:
    return host.startswith("127.") or host == "::1"


def open_path(path: Path, select: bool = False) -> None:
    try:
        if os.name == "nt":
            if select and path.is_file():
                subprocess.Popen(["explorer", "/select,", str(path)])
            else:
                os.startfile(str(path if path.is_dir() else path.parent))  # type: ignore[attr-defined]
        else:
            target = path.parent if (select or path.is_file()) else path
            subprocess.Popen(["xdg-open", str(target)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        print("Não foi possível abrir a pasta:", exc)


# ------------------------------------------------------------ núcleo do app
class Messenger:
    mode = "lan"

    def __init__(self, profile_name: str, preferred_port: int, listeners: list | None = None,
                 root: Path | None = None):
        self.root = root or (data_root() / safe_name(profile_name))
        self.hist_dir = self.root / "historico"
        self.sent_dir = self.root / "enviados"
        self.recv_dir = downloads_dir()
        for d in (self.root, self.hist_dir, self.sent_dir):
            d.mkdir(parents=True, exist_ok=True)

        self.lock = threading.RLock()
        self.listeners: list[queue.Queue] = listeners if listeners is not None else []
        self.had_client = False
        self.last_client = now()
        self.running = True
        self.p2p_port = preferred_port
        self.udp: socket.socket | None = None
        self.online: set[str] = set()
        self.delivering: set[str] = set()
        self.histories: dict[str, list] = {}

        try:
            default_name = getpass.getuser().capitalize()
        except Exception:
            default_name = "Eu"
        self.profile = read_json(self.root / "perfil.json", {})
        for k, v in {"id": uuid.uuid4().hex, "name": default_name, "status": "online", "psm": "",
                     "avatar": "", "theme": "auto", "accent": "#3b82f6", "sounds": True,
                     "notify": True}.items():
            self.profile.setdefault(k, v)
        if self.profile["status"] not in STATUSES:
            self.profile["status"] = "online"
        self.save_profile()

        self.contacts: dict[str, dict] = read_json(self.root / "contatos.json", {})
        for c in self.contacts.values():
            c["last_seen"] = 0
            c["status"] = "offline"

    # ---------------------------------------------------------- persistência
    def save_profile(self):
        with self.lock:
            write_json(self.root / "perfil.json", self.profile)

    def save_contacts(self):
        with self.lock:
            write_json(self.root / "contatos.json", self.contacts)

    def history(self, pid: str) -> list:
        with self.lock:
            if pid not in self.histories:
                self.histories[pid] = read_json(self.hist_dir / f"{safe_name(pid)}.json", [])
            return self.histories[pid]

    def save_history(self, pid: str):
        with self.lock:
            write_json(self.hist_dir / f"{safe_name(pid)}.json", self.history(pid))

    def add_msg(self, pid: str, m: dict):
        with self.lock:
            self.history(pid).append(m)
            self.save_history(pid)

    def find_msg(self, pid: str, mid: str):
        with self.lock:
            for m in reversed(self.history(pid)):
                if m.get("id") == mid:
                    return m
        return None

    def update_msg(self, pid: str, mid: str, **fields):
        with self.lock:
            m = self.find_msg(pid, mid)
            if not m:
                return None
            m.update(fields)
            self.save_history(pid)
            snapshot = dict(m)
        self.emit("update", snapshot)
        return snapshot

    # ------------------------------------------------------------- eventos
    def emit(self, kind: str, data):
        for q in list(self.listeners):
            q.put((kind, data))

    # ------------------------------------------------------------ perfil
    def avatar_hash(self) -> str:
        a = self.profile.get("avatar") or ""
        return hashlib.sha1(a.encode()).hexdigest()[:12] if a else ""

    def public_status(self) -> str:
        st = self.profile["status"]
        return "offline" if (st == "invisible" or not self.running) else st

    def public(self) -> dict:
        p = self.profile
        return {"app": "aura", "proto": PROTO, "v": VERSION, "id": p["id"], "name": p["name"],
                "psm": p["psm"], "status": self.public_status(), "port": self.p2p_port,
                "ah": self.avatar_hash()}

    def update_profile(self, data: dict) -> dict:
        with self.lock:
            p = self.profile
            if "name" in data:
                p["name"] = str(data["name"]).strip()[:80] or p["name"]
            if "psm" in data:
                p["psm"] = str(data["psm"]).strip()[:200]
            if data.get("status") in STATUSES:
                p["status"] = data["status"]
            if "avatar" in data:
                a = str(data["avatar"] or "")
                if a and (not a.startswith("data:image/") or len(a) > MAX_AVATAR):
                    raise ValueError("Imagem de perfil inválida ou grande demais")
                p["avatar"] = a
            if data.get("theme") in ("auto", "light", "dark"):
                p["theme"] = data["theme"]
            if isinstance(data.get("accent"), str) and re.fullmatch(r"#[0-9a-fA-F]{6}", data["accent"]):
                p["accent"] = data["accent"]
            for k in ("sounds", "notify"):
                if k in data:
                    p[k] = bool(data[k])
            self.save_profile()
            snapshot = dict(p)
        self.announce()
        self.emit("me", snapshot)
        return snapshot

    # ----------------------------------------------------------- contatos
    @staticmethod
    def new_contact(pid: str) -> dict:
        return {"id": pid, "name": "", "alias": "", "psm": "", "status": "offline", "host": "",
                "port": P2P_PORT, "ah": "", "avatar": "", "last_seen": 0, "seen_at": 0,
                "favorite": False, "blocked": False, "hidden": False, "manual": False, "unread": 0}

    def is_online(self, c: dict) -> bool:
        return c.get("status") != "offline" and now() - c.get("last_seen", 0) < ONLINE_TTL

    def contact_view(self, c: dict) -> dict:
        on = self.is_online(c)
        return {"id": c["id"], "name": c.get("alias") or c.get("name") or "Contato",
                "realname": c.get("name", ""), "alias": c.get("alias", ""), "psm": c.get("psm", ""),
                "status": c.get("status", "online") if on else "offline", "avatar": c.get("avatar", ""),
                "favorite": c.get("favorite", False), "blocked": c.get("blocked", False),
                "hidden": c.get("hidden", False), "unread": c.get("unread", 0),
                "addr": f"{c.get('host')}:{c.get('port')}", "seen_at": c.get("seen_at", 0),
                "manual": c.get("manual", False)}

    def _set_host(self, c: dict, host: str):
        # não troca um IP de rede por 127.0.0.1 (instâncias no mesmo PC)
        if not c.get("host") or not is_loopback(host) or is_loopback(c["host"]):
            c["host"] = host

    def handle_presence(self, pkt: dict, host: str) -> dict | None:
        pid = str(pkt.get("id", ""))[:64]
        if not pid or pid == self.profile["id"]:
            return None
        try:
            port = int(pkt.get("port", P2P_PORT))
        except (TypeError, ValueError):
            port = P2P_PORT
        status = pkt.get("status") if pkt.get("status") in PEER_STATUSES else "online"
        name = str(pkt.get("name", ""))[:80]
        psm = str(pkt.get("psm", ""))[:200]
        ah = str(pkt.get("ah", ""))[:40]
        with self.lock:
            c = self.contacts.get(pid)
            new = c is None
            if new:
                c = self.contacts[pid] = self.new_contact(pid)
            before = (c["name"], c["psm"], c["status"], c["host"], c["port"])
            self._set_host(c, host)
            c.update(name=name or c["name"], psm=psm, status=status, port=port)
            if status == "offline":
                c["last_seen"] = 0
            else:
                c["last_seen"] = c["seen_at"] = now()
            need_avatar = bool(ah) and ah != c.get("ah")
            if not ah and c.get("avatar"):
                c["avatar"] = c["ah"] = ""
                new = True
            changed = new or before != (c["name"], c["psm"], c["status"], c["host"], c["port"])
            if changed:
                self.save_contacts()
            view = self.contact_view(c)
        if need_avatar:
            threading.Thread(target=self.fetch_avatar, args=(pid,), daemon=True).start()
        if changed:
            self.emit("contact", view)
        self.check_online(pid)
        return view

    def check_online(self, pid: str):
        with self.lock:
            c = self.contacts.get(pid)
            if not c:
                return
            on = self.is_online(c)
            if on == (pid in self.online):
                return
            (self.online.add if on else self.online.discard)(pid)
            view = self.contact_view(c)
        self.emit("contact", view)
        if on:
            self.emit("signin", {"id": pid})
            self.flush_pending(pid)

    def fetch_avatar(self, pid: str):
        c = self.contacts.get(pid)
        if not c:
            return
        try:
            r = self.peer_call(c, "/p2p/avatar")
            a = str(r.get("avatar") or "")
            if a and (not a.startswith("data:image/") or len(a) > MAX_AVATAR):
                return
            with self.lock:
                c["avatar"], c["ah"] = a, str(r.get("ah", ""))[:40]
                self.save_contacts()
                view = self.contact_view(c)
            self.emit("contact", view)
        except Exception:
            pass

    def add_by_address(self, address: str) -> dict:
        address = address.strip()
        m = re.fullmatch(r"\[?([0-9A-Za-z.\-:]+?)\]?(?::(\d{1,5}))?", address)
        if not m:
            raise ValueError("Endereço inválido. Use algo como 192.168.0.20:47101")
        host, port = m.group(1), int(m.group(2) or P2P_PORT)
        try:
            hello = self.peer_call({"host": host, "port": port}, "/p2p/hello", timeout=5)
        except Exception:
            raise ValueError(f"Ninguém respondeu em {host}:{port}. O AURA está aberto lá?")
        if hello.get("app") != "aura":
            raise ValueError("Esse endereço não é um AURA MSN.")
        view = self.handle_presence(hello, host)
        if not view:
            raise ValueError("Esse endereço é você mesmo 🙂")
        with self.lock:
            c = self.contacts[view["id"]]
            c["manual"] = True
            c["hidden"] = False
            self.save_contacts()
            view = self.contact_view(c)
        self.emit("contact", view)
        self.announce()
        return view

    def update_contact(self, pid: str, data: dict) -> dict:
        with self.lock:
            c = self.require_contact(pid)
            if "alias" in data:
                c["alias"] = str(data["alias"]).strip()[:80]
            for k in ("favorite", "blocked", "hidden"):
                if k in data:
                    c[k] = bool(data[k])
            self.save_contacts()
            view = self.contact_view(c)
        self.emit("contact", view)
        return view

    def require_contact(self, pid: str) -> dict:
        c = self.contacts.get(str(pid))
        if not c:
            raise ValueError("Contato desconhecido")
        return c

    # ------------------------------------------------------- comunicação P2P
    def peer_call(self, c: dict, path: str, payload=None, timeout: float = 6):
        host = c["host"]
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        data = json.dumps(payload).encode() if payload is not None else None
        req = Request(f"http://{host}:{c['port']}{path}", data=data,
                      headers={"Content-Type": "application/json"},
                      method="POST" if data is not None else "GET")
        with OPENER.open(req, timeout=timeout) as r:
            return json.loads(r.read(MAX_BODY).decode("utf-8") or "{}")

    def envelope(self, kind: str, **kw) -> dict:
        env = {"from": self.profile["id"], "name": self.profile["name"], "fp": self.p2p_port,
               "st": self.public_status(), "kind": kind}
        env.update(kw)
        return env

    def fire(self, pid: str, env: dict):
        """Envio sem fila (digitando, confirmação de leitura, reação)."""
        c = self.contacts.get(pid)
        if not c or not c.get("host"):
            return

        def run():
            try:
                self.peer_call(c, "/p2p/msg", env, timeout=4)
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()

    def new_msg(self, pid: str, kind: str, **kw) -> dict:
        m = {"id": uuid.uuid4().hex, "peer": pid, "dir": "out", "kind": kind, "ts": now(),
             "state": "sending"}
        m.update(kw)
        return m

    def send(self, pid: str, kind: str, **kw) -> dict:
        self.require_contact(pid)
        m = self.new_msg(pid, kind, **kw)
        self.add_msg(pid, m)
        self.emit("message", m)
        threading.Thread(target=self.deliver, args=(pid, m["id"]), daemon=True).start()
        return m

    def send_text(self, pid: str, text: str) -> dict:
        text = str(text or "").strip()[:MAX_TEXT]
        if not text:
            raise ValueError("Mensagem vazia")
        return self.send(pid, "text", text=text)

    def send_file(self, pid: str, name: str, b64: str) -> dict:
        raw = base64.b64decode(b64 or "", validate=True)
        if len(raw) > MAX_FILE:
            raise ValueError("Arquivo maior que 25 MB")
        path = unique_path(self.sent_dir, safe_name(name))
        path.write_bytes(raw)
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        return self.send(pid, "file", file={"name": path.name, "size": len(raw), "mime": mime,
                                            "path": str(path)})

    def deliver(self, pid: str, mid: str):
        with self.lock:
            if mid in self.delivering:
                return
            self.delivering.add(mid)
        try:
            m = self.find_msg(pid, mid)
            c = self.contacts.get(pid)
            if not m or not c:
                return
            env = self.envelope(m["kind"], id=m["id"], ts=m["ts"])
            if m["kind"] == "text":
                env["text"] = m["text"]
            elif m["kind"] == "file":
                f = m["file"]
                try:
                    data = Path(f["path"]).read_bytes()
                except OSError:
                    self.update_msg(pid, mid, state="failed")
                    return
                env["file"] = {"name": f["name"], "size": f["size"], "mime": f["mime"],
                               "data": base64.b64encode(data).decode()}
            ok = False
            if c.get("host") and not c.get("blocked"):
                try:
                    ok = bool(self.peer_call(c, "/p2p/msg", env,
                                             timeout=120 if m["kind"] == "file" else 6).get("ok"))
                except Exception:
                    ok = False
            if ok:
                if m.get("state") != "read":
                    self.update_msg(pid, mid, state="sent")
            else:
                # texto e arquivos ficam na fila e saem quando o contato aparecer
                self.update_msg(pid, mid, state="failed" if m["kind"] == "nudge" else "pending")
        finally:
            with self.lock:
                self.delivering.discard(mid)

    def flush_pending(self, pid: str):
        with self.lock:
            ids = [m["id"] for m in self.history(pid) if m.get("dir") == "out" and m.get("state") == "pending"]
        for mid in ids:
            threading.Thread(target=self.deliver, args=(pid, mid), daemon=True).start()

    def mark_read(self, pid: str):
        with self.lock:
            c = self.require_contact(pid)
            ids = []
            for m in self.history(pid):
                if m.get("dir") == "in" and m.get("state") == "received":
                    m["state"] = "read"
                    ids.append(m["id"])
            if ids:
                self.save_history(pid)
            changed = c.get("unread", 0) != 0
            c["unread"] = 0
            if changed:
                self.save_contacts()
            view = self.contact_view(c)
        if changed:
            self.emit("contact", view)
        if ids:
            self.fire(pid, self.envelope("read", ids=ids[-500:]))

    def react(self, pid: str, mid: str, emoji: str):
        emoji = str(emoji or "")[:8]
        with self.lock:
            m = self.find_msg(pid, mid)
            if not m:
                raise ValueError("Mensagem não encontrada")
            r = dict(m.get("reactions") or {})
            if emoji:
                r["me"] = emoji
            else:
                r.pop("me", None)
        self.update_msg(pid, mid, reactions=r)
        self.fire(pid, self.envelope("react", target=mid, emoji=emoji))

    def clear_history(self, pid: str):
        with self.lock:
            self.histories[pid] = []
            self.save_history(pid)

    def search(self, q: str) -> list:
        q = q.lower().strip()
        out = []
        if len(q) < 2:
            return out
        for f in sorted(self.hist_dir.glob("*.json")):
            pid = f.stem
            for m in reversed(self.history(pid)):
                txt = m.get("text") or (m.get("file") or {}).get("name") or ""
                if q in txt.lower():
                    out.append({"peer": pid, "id": m["id"], "text": txt[:160], "ts": m["ts"], "dir": m["dir"]})
                    if len(out) >= 80:
                        return sorted(out, key=lambda x: -x["ts"])
        return sorted(out, key=lambda x: -x["ts"])

    # ------------------------------------------------------- recebimento P2P
    def receive(self, env: dict, host: str) -> dict:
        pid = str(env.get("from", ""))[:64]
        if not pid or pid == self.profile["id"]:
            return {"ok": False}
        kind = env.get("kind")
        with self.lock:
            c = self.contacts.get(pid)
            new = c is None
            if new:
                c = self.contacts[pid] = self.new_contact(pid)
                c["name"] = str(env.get("name", ""))[:80] or host
            self._set_host(c, host)
            try:
                c["port"] = int(env.get("fp", c["port"]))
            except (TypeError, ValueError):
                pass
            st = env.get("st")
            if st in PEER_STATUSES:
                c["status"] = st
                if st != "offline":
                    c["last_seen"] = c["seen_at"] = now()
            if kind in ("text", "nudge", "file"):
                c["hidden"] = False
            if new:
                self.save_contacts()
            blocked = c.get("blocked")
            view = self.contact_view(c)
        if new:
            self.emit("contact", view)
            threading.Thread(target=self.fetch_avatar, args=(pid,), daemon=True).start()
        self.check_online(pid)
        if blocked:
            return {"ok": True}
        raw = None
        if kind == "file":
            try:
                raw = base64.b64decode((env.get("file") or {}).get("data", ""), validate=True)
            except Exception:
                return {"ok": False}
        return self.ingest(pid, kind, env, raw)

    def store_file(self, name, raw: bytes) -> dict:
        path = unique_path(self.recv_dir, safe_name(name or "arquivo"))
        path.write_bytes(raw)
        return {"name": path.name, "size": len(raw),
                "mime": mimetypes.guess_type(path.name)[0] or "application/octet-stream", "path": str(path)}

    def ingest(self, pid: str, kind, env: dict, raw: bytes | None = None) -> dict:
        """Mensagem recebida de um contato (já conferido e não bloqueado)."""
        c = self.contacts.get(pid)
        if not c:
            return {"ok": False}
        if kind == "typing":
            self.emit("typing", {"id": pid})
        elif kind in ("text", "nudge", "file"):
            mid = re.sub(r"[^0-9a-zA-Z]", "", str(env.get("id") or ""))[:64] or uuid.uuid4().hex
            if self.find_msg(pid, mid):
                return {"ok": True}  # duplicada (reenvio da fila)
            m = {"id": mid, "peer": pid, "dir": "in", "kind": kind, "ts": now(), "state": "received"}
            if kind == "text":
                m["text"] = str(env.get("text", ""))[:MAX_TEXT]
            elif kind == "file":
                if raw is None or len(raw) > MAX_FILE:
                    return {"ok": False}
                m["file"] = self.store_file((env.get("file") or {}).get("name"), raw)
            if env.get("ts") and kind != "nudge":
                try:  # horário de quem enviou (mensagens que ficaram na fila)
                    m["ts"] = min(float(env["ts"]), now())
                except (TypeError, ValueError):
                    pass
            self.add_msg(pid, m)
            with self.lock:
                c["unread"] = c.get("unread", 0) + 1
                self.save_contacts()
                view = self.contact_view(c)
            quiet = bool(env.get("stale"))  # sincronizando mensagens antigas: sem som nem tremida
            self.emit("message", dict(m, quiet=True) if quiet else m)
            self.emit("contact", view)
            if kind == "nudge" and not quiet:
                self.emit("nudge", {"id": pid})
        elif kind == "read":
            ids = env.get("ids") if isinstance(env.get("ids"), list) else []
            for mid in ids[:500]:
                m = self.find_msg(pid, str(mid))
                if m and m.get("dir") == "out" and m.get("state") != "read":
                    self.update_msg(pid, m["id"], state="read")
        elif kind == "react":
            m = self.find_msg(pid, str(env.get("target", "")))
            if m:
                r = dict(m.get("reactions") or {})
                emoji = str(env.get("emoji") or "")[:8]
                if emoji:
                    r[pid] = emoji
                else:
                    r.pop(pid, None)
                self.update_msg(pid, m["id"], reactions=r)
        return {"ok": True}

    # ----------------------------------------------------------- descoberta
    def start_discovery(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        try:
            s.bind(("", DISCOVERY_PORT))
        except OSError as exc:
            print(f"Aviso: porta de descoberta {DISCOVERY_PORT} indisponível ({exc}); "
                  "use 'Adicionar por endereço'.")
            s.bind(("", 0))
        s.settimeout(1.0)
        self.udp = s
        threading.Thread(target=self._udp_recv, daemon=True).start()
        threading.Thread(target=self._udp_announce_loop, daemon=True).start()
        threading.Thread(target=self._watchdog, daemon=True).start()

    def announce(self, status: str | None = None):
        if not self.udp:
            return
        pkt = self.public()
        if status:
            pkt["status"] = status
        data = json.dumps(pkt).encode("utf-8")
        targets = {"255.255.255.255", "127.0.0.1"}
        for ip in local_ips():
            parts = ip.split(".")
            if len(parts) == 4:
                targets.add(".".join(parts[:3] + ["255"]))
        with self.lock:
            for c in self.contacts.values():
                if c.get("host") and ":" not in c["host"] and not c.get("blocked"):
                    targets.add(c["host"])
        for t in targets:
            try:
                self.udp.sendto(data, (t, DISCOVERY_PORT))
            except OSError:
                pass

    def _udp_announce_loop(self):
        while self.running:
            self.announce()
            for _ in range(PRESENCE_EVERY * 4):
                if not self.running:
                    return
                time.sleep(0.25)

    def _udp_recv(self):
        while self.running:
            try:
                data, addr = self.udp.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                if not self.running:
                    return
                continue  # Windows: ICMP "port unreachable" vira ConnectionResetError
            try:
                pkt = json.loads(data.decode("utf-8"))
            except Exception:
                continue
            if isinstance(pkt, dict) and pkt.get("app") == "aura":
                self.handle_presence(pkt, addr[0])

    def _watchdog(self):
        tick = 0
        while self.running:
            time.sleep(2)
            tick += 1
            for pid in list(self.contacts):
                self.check_online(pid)
            if tick % 15 == 0:  # a cada ~30 s tenta de novo a fila de quem está online
                for pid in list(self.online):
                    self.flush_pending(pid)

    def stop(self):
        """Para o transporte sem fechar a janela (sair da conta / trocar de modo)."""
        if not self.running:
            return
        self.running = False
        for _ in range(2):
            self.announce("offline")
            time.sleep(0.1)
        try:
            if self.udp:
                self.udp.close()
        except OSError:
            pass

    def shutdown(self):
        if not self.running:
            return
        self.stop()
        self.emit("bye", {})

    def state_extra(self) -> dict:
        return {"addresses": [f"{ip}:{self.p2p_port}" for ip in local_ips()]}


# --------------------------------------------------------------- modo conta
def load_config() -> dict:
    cfg = read_json(CONFIG_FILE, {})
    return cfg if isinstance(cfg, dict) else {}


def device_name() -> str:
    plat = "Windows" if os.name == "nt" else "Linux"
    try:
        return f"{socket.gethostname()[:50]} ({plat})"
    except Exception:
        return plat


class CloudError(Exception):
    def __init__(self, msg: str, status: int = 0, data: dict | None = None):
        super().__init__(msg)
        self.status = status
        self.data = data or {}


class CloudClient:
    """Fala com o servidor AURA (servidor/aura/api.php) por HTTPS."""

    def __init__(self, server: str, token: str = ""):
        self.server = server.rstrip("/")
        self.token = token

    def call(self, action: str, payload=None, query: dict | None = None, raw: bytes | None = None,
             timeout: float = 20, want_bytes: bool = False):
        if not self.server:
            raise CloudError("O endereço do servidor AURA não foi configurado (aura_config.json).")
        url = f"{self.server}/api.php?a={action}" + (("&" + urlencode(query)) if query else "")
        headers = {"User-Agent": f"AURA-MSN/{VERSION} ({sys.platform})", "Accept": "application/json"}
        if self.token:
            headers["X-Aura-Token"] = self.token
        data = None
        if raw is not None:
            data = raw
            headers["Content-Type"] = "application/octet-stream"
        elif payload is not None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json; charset=utf-8"
        req = Request(url, data=data, headers=headers, method="POST" if data is not None else "GET")
        try:
            with urlopen(req, timeout=timeout) as r:
                body = r.read()
        except HTTPError as e:
            try:
                d = json.loads(e.read().decode("utf-8") or "{}")
            except Exception:
                d = {}
            msg = d.get("error") if isinstance(d, dict) else None
            raise CloudError(msg or f"O servidor respondeu com erro {e.code}.", e.code, d if isinstance(d, dict) else {})
        except (URLError, OSError, ValueError) as e:
            raise CloudError("Sem conexão com o servidor AURA. Confira sua internet.", 0) from e
        if want_bytes:
            return body
        try:
            d = json.loads(body.decode("utf-8") or "{}")
        except Exception:
            raise CloudError("O servidor respondeu algo inesperado. O endereço em aura_config.json está certo?", 0)
        return d if isinstance(d, dict) else {}


def uid_of(pid: str) -> int:
    try:
        return int(str(pid).lstrip("u"))
    except ValueError:
        raise ValueError("Contato inválido")


class CloudMessenger(Messenger):
    """Mesmo mensageiro, mas o transporte é o servidor AURA em vez da rede local."""
    mode = "cloud"

    def __init__(self, shell: "Shell", account: dict):
        self.shell = shell
        self.account = account
        self.cloud = CloudClient(account["server"], account["token"])
        uid = int(account["uid"])
        super().__init__(shell.profile_name, P2P_PORT, shell.listeners, shell.root / f"conta-{uid}")
        u = account.get("user") or {}
        p = self.profile
        p["id"] = f"u{uid}"
        p["email"] = account.get("email", "")
        if not p.get("cloud_synced"):  # primeira vez neste PC: pega nome, frase e foto do servidor
            for k in ("name", "psm", "avatar"):
                if isinstance(u.get(k), str):
                    p[k] = u[k]
            p["cloud_synced"] = True
        if account.get("status") in STATUSES:
            p["status"] = account["status"]
        self.save_profile()
        st = read_json(self.root / "servidor.json", {})
        self.cursor = int(st.get("cursor", 0)) if st.get("server") == self.cloud.server else 0
        self.connected = False
        self.wake = threading.Event()

    # ------------------------------------------------------------ utilidades
    def remote(self, action: str, payload=None, **kw):
        """Chamada feita por um clique do usuário: erros viram mensagens amigáveis."""
        try:
            return self.cloud.call(action, payload, **kw)
        except CloudError as e:
            if e.status == 401:
                self.shell.auth_lost(str(e))
            raise ValueError(str(e))

    def save_cursor(self):
        write_json(self.root / "servidor.json", {"server": self.cloud.server, "cursor": self.cursor})

    def is_online(self, c: dict) -> bool:
        return self.connected and c.get("status", "offline") != "offline"

    def contact_view(self, c: dict) -> dict:
        v = super().contact_view(c)
        v.update(email=c.get("email", ""), addr=c.get("email", ""), state=c.get("state", "ok"))
        if not self.connected:
            v["status"] = "offline"
        return v

    def state_extra(self) -> dict:
        return {"addresses": [], "account": {"email": self.account.get("email", ""), "server": self.cloud.server},
                "connected": self.connected}

    def announce(self, status=None):
        self.wake.set()  # mudou algo: consulta o servidor já

    # ------------------------------------------------------------ perfil
    def update_profile(self, data: dict) -> dict:
        remote = {k: data[k] for k in ("name", "psm", "avatar") if k in data}
        if remote:
            self.remote("profile", remote)
        return super().update_profile(data)

    # ------------------------------------------------------------ contatos
    def sync_contacts(self, items: list):
        changed, requests, avatars, removed = [], [], [], []
        with self.lock:
            seen = set()
            for sc in items:
                try:
                    pid = f"u{int(sc['id'])}"
                except (KeyError, TypeError, ValueError):
                    continue
                seen.add(pid)
                c = self.contacts.get(pid)
                new = c is None
                if new:
                    c = self.contacts[pid] = self.new_contact(pid)
                    c["manual"] = True
                before = (c.get("name"), c.get("psm"), c.get("status"), c.get("state"), c.get("email"),
                          c.get("blocked"), c.get("seen_at"))
                status = sc.get("status") if sc.get("status") in PEER_STATUSES else "offline"
                c.update(name=str(sc.get("name") or "")[:80], psm=str(sc.get("psm") or "")[:200], status=status,
                         email=str(sc.get("email") or ""), state=sc.get("state") or "ok",
                         blocked=bool(sc.get("blocked")), seen_at=int(sc.get("seen_at") or 0))
                c["last_seen"] = now() if status != "offline" else 0
                ah = str(sc.get("ah") or "")
                if ah and ah != c.get("ah"):
                    avatars.append(pid)
                elif not ah and c.get("avatar"):
                    c["avatar"] = c["ah"] = ""
                    new = True
                if new or before != (c.get("name"), c.get("psm"), c.get("status"), c.get("state"), c.get("email"),
                                     c.get("blocked"), c.get("seen_at")):
                    changed.append(pid)
                    if c["state"] == "in" and (new or before[3] != "in"):
                        requests.append(pid)
            removed = [pid for pid in self.contacts if pid not in seen]
            for pid in removed:
                del self.contacts[pid]
                self.online.discard(pid)
            if changed or removed:
                self.save_contacts()
            views = {pid: self.contact_view(self.contacts[pid]) for pid in changed}
        for pid, v in views.items():
            self.emit("contact", v)
        for pid in removed:
            self.emit("remove", {"id": pid})
        for pid in requests:
            self.emit("request", views[pid])
        for pid in avatars:
            threading.Thread(target=self.fetch_avatar, args=(pid,), daemon=True).start()
        for pid in list(self.contacts):
            self.check_online(pid)

    def fetch_avatar(self, pid: str):
        try:
            r = self.cloud.call("avatar", query={"id": uid_of(pid)})
        except (CloudError, ValueError):
            return
        a = str(r.get("avatar") or "")
        if a and (not a.startswith("data:image/") or len(a) > MAX_AVATAR):
            return
        with self.lock:
            c = self.contacts.get(pid)
            if not c:
                return
            c["avatar"], c["ah"] = a, str(r.get("ah", ""))[:40]
            self.save_contacts()
            view = self.contact_view(c)
        self.emit("contact", view)

    def add_by_email(self, email: str) -> dict:
        email = email.strip().lower()
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise ValueError("Digite um e-mail válido, ex.: amigo@gmail.com")
        try:
            r = self.cloud.call("contact_add", {"email": email})
        except CloudError as e:
            if e.status == 401:
                self.shell.auth_lost(str(e))
            if e.data.get("not_found"):
                return {"not_found": True, "email": email}
            raise ValueError(str(e))
        self.sync_contacts(r.get("contacts") or [])
        with self.lock:
            for c in self.contacts.values():
                if c.get("email") == email:
                    c["hidden"] = False
                    self.save_contacts()
                    return self.contact_view(c)
        return {"ok": True}

    def add_by_address(self, address: str) -> dict:
        return self.add_by_email(address)

    def invite(self, email: str):
        self.remote("invite", {"email": email.strip().lower()})

    def answer(self, pid: str, accept: bool):
        r = self.remote("contact_answer", {"id": uid_of(pid), "accept": bool(accept)})
        self.sync_contacts(r.get("contacts") or [])

    def remove_contact(self, pid: str):
        r = self.remote("contact_remove", {"id": uid_of(pid)})
        self.sync_contacts(r.get("contacts") or [])

    def update_contact(self, pid: str, data: dict) -> dict:
        if "blocked" in data:
            self.remote("contact_block", {"id": uid_of(pid), "blocked": bool(data["blocked"])})
        return super().update_contact(pid, data)

    # ------------------------------------------------------------ envio
    def send(self, pid: str, kind: str, **kw) -> dict:
        c = self.require_contact(pid)
        if c.get("state") != "ok":
            raise ValueError("Essa pessoa ainda não aceitou seu convite.")
        return super().send(pid, kind, **kw)

    def fire(self, pid: str, env: dict):
        if not self.connected or pid not in self.contacts:
            return
        payload = {"to": uid_of(pid), "kind": env.get("kind")}
        for k in ("ids", "target", "emoji"):
            if k in env:
                payload[k] = env[k]

        def run():
            try:
                self.cloud.call("send", payload, timeout=10)
            except CloudError:
                pass
        threading.Thread(target=run, daemon=True).start()

    def deliver(self, pid: str, mid: str):
        with self.lock:
            if mid in self.delivering:
                return
            self.delivering.add(mid)
        try:
            m = self.find_msg(pid, mid)
            c = self.contacts.get(pid)
            if not m or not c:
                return
            try:
                if m["kind"] == "file":
                    self.upload(c, m)
                else:
                    self.cloud.call("send", {"to": uid_of(pid), "kind": m["kind"], "id": m["id"], "ts": m["ts"],
                                             "text": m.get("text", "")})
                if m.get("state") != "read":
                    self.update_msg(pid, mid, state="sent")
            except OSError:
                self.update_msg(pid, mid, state="failed")
            except CloudError as e:
                if e.status == 401:
                    self.shell.auth_lost(str(e))
                temporary = e.status == 0 or e.status >= 500 or e.status == 429
                if m["kind"] == "nudge" or not temporary:
                    self.update_msg(pid, mid, state="failed", error=str(e))
                else:
                    self.update_msg(pid, mid, state="pending")  # sai sozinha quando a internet voltar
        finally:
            with self.lock:
                self.delivering.discard(mid)

    def upload(self, c: dict, m: dict):
        f = m["file"]
        data = Path(f["path"]).read_bytes()
        r = self.cloud.call("file_init", {"to": uid_of(c["id"]), "name": f["name"], "size": len(data),
                                          "mime": f["mime"]})
        fid, size = r["fid"], int(r.get("chunk") or 1048576)
        off, stuck = 0, 0
        while off < len(data):
            rr = self.cloud.call("file_chunk", query={"fid": fid, "off": off}, raw=data[off:off + size], timeout=180)
            got = int(rr.get("received", off))
            stuck = stuck + 1 if got <= off else 0
            if stuck > 3:
                raise CloudError("O servidor não está aceitando o arquivo.", 500)
            off = got
        self.cloud.call("file_done", {"fid": fid, "id": m["id"], "ts": m["ts"]})

    def flush_all(self):
        with self.lock:
            pids = list(self.contacts)
        for pid in pids:
            self.flush_pending(pid)

    # ------------------------------------------------------------ recebimento
    def download(self, fid: str) -> bytes | None:
        try:
            return self.cloud.call("file_get", query={"fid": fid}, want_bytes=True, timeout=300)
        except CloudError as e:
            if e.status in (403, 404):
                return None  # expirou no servidor: não adianta tentar de novo
            raise

    def handle_event(self, ev: dict, server_time: float):
        kind = str(ev.get("kind") or "")
        d = ev.get("data") if isinstance(ev.get("data"), dict) else {}
        stale = server_time - float(ev.get("ts") or server_time) > 90
        if kind == "contacts":
            return
        if kind.startswith("self_"):
            return self.handle_self(kind[5:], f"u{d.get('peer')}", d, stale)
        pid = f"u{ev.get('from')}"
        c = self.contacts.get(pid)
        if not c or c.get("blocked"):
            return
        if kind == "typing" and stale:
            return
        env = dict(d)
        env["stale"] = stale
        raw = None
        if kind == "file":
            mid = re.sub(r"[^0-9a-zA-Z]", "", str(d.get("id") or ""))[:64]
            if mid and self.find_msg(pid, mid):
                return
            raw = self.download(str((d.get("file") or {}).get("fid") or ""))
            if raw is None:
                return
        if kind in ("text", "nudge", "file"):
            with self.lock:
                c["hidden"] = False
        self.ingest(pid, kind, env, raw)

    def handle_self(self, kind: str, pid: str, d: dict, stale: bool):
        """O que você mesmo fez em outro computador com a mesma conta."""
        if pid not in self.contacts:
            return
        if kind in ("text", "nudge", "file"):
            mid = re.sub(r"[^0-9a-zA-Z]", "", str(d.get("id") or ""))[:64]
            if not mid or self.find_msg(pid, mid):
                return  # foi enviada por este computador
            try:
                ts = min(float(d.get("ts") or now()), now())
            except (TypeError, ValueError):
                ts = now()
            m = {"id": mid, "peer": pid, "dir": "out", "kind": kind, "ts": ts, "state": "sent"}
            if kind == "text":
                m["text"] = str(d.get("text", ""))[:MAX_TEXT]
            elif kind == "file":
                f = d.get("file") or {}
                raw = self.download(str(f.get("fid") or ""))
                if raw is None:
                    return
                path = unique_path(self.sent_dir, safe_name(f.get("name") or "arquivo"))
                path.write_bytes(raw)
                m["file"] = {"name": path.name, "size": len(raw), "path": str(path),
                             "mime": mimetypes.guess_type(path.name)[0] or "application/octet-stream"}
            self.add_msg(pid, m)
            self.emit("message", dict(m, quiet=True))
        elif kind == "read":
            ids = {str(x) for x in (d.get("ids") or [])}
            with self.lock:
                changed = False
                for m in self.history(pid):
                    if m.get("dir") == "in" and m["id"] in ids and m.get("state") != "read":
                        m["state"] = "read"
                        changed = True
                if changed:
                    self.save_history(pid)
                c = self.contacts[pid]
                c["unread"] = 0
                self.save_contacts()
                view = self.contact_view(c)
            self.emit("contact", view)
        elif kind == "react":
            m = self.find_msg(pid, str(d.get("target", "")))
            if m:
                r = dict(m.get("reactions") or {})
                emoji = str(d.get("emoji") or "")[:8]
                if emoji:
                    r["me"] = emoji
                else:
                    r.pop("me", None)
                self.update_msg(pid, m["id"], reactions=r)

    # ------------------------------------------------------------ laço principal
    def start_discovery(self):
        threading.Thread(target=self.poll_loop, daemon=True).start()

    def set_connected(self, ok: bool, msg: str = ""):
        if ok == self.connected:
            return
        self.connected = ok
        self.emit("net", {"ok": ok, "msg": msg})
        with self.lock:
            views = [self.contact_view(c) for c in self.contacts.values()]
        for v in views:
            self.emit("contact", v)
        for pid in list(self.contacts):
            self.check_online(pid)
        if ok:
            self.flush_all()

    def poll_loop(self):
        fails, tick = 0, 0
        while self.running:
            more = False
            try:
                r = self.cloud.call("poll", {"cursor": self.cursor, "status": self.profile["status"]}, timeout=30)
                fails = 0
                self.apply_poll(r)
                self.set_connected(True)
                more = bool(r.get("more"))
                tick += 1
                if tick % 15 == 0:
                    self.flush_all()
            except CloudError as e:
                if e.status == 401:
                    self.shell.auth_lost(str(e))
                    return
                fails += 1
                if fails >= 2:
                    self.set_connected(False, str(e))
            except Exception as e:  # pragma: no cover
                print("Erro ao falar com o servidor:", e)
                fails += 1
            if not self.running:
                return
            if more:
                continue
            wait = POLL_EVERY * (2.5 if self.profile["status"] == "away" else 1)
            if fails:
                wait = min(20, 2 + fails * 3)
            self.wake.wait(wait)
            self.wake.clear()

    def apply_poll(self, r: dict):
        server_time = float(r.get("time") or now())
        self.sync_contacts(r.get("contacts") or [])
        cursor, complete = self.cursor, True
        for ev in r.get("events") or []:
            try:
                self.handle_event(ev, server_time)
            except CloudError:
                complete = False  # não conseguiu baixar um arquivo: tenta de novo na próxima
                break
            except Exception as e:  # um evento estranho não pode travar a fila
                print("Evento ignorado:", e)
            cursor = max(cursor, int(ev.get("id") or 0))
        if complete:
            cursor = max(cursor, int(r.get("cursor") or 0))
        if cursor != self.cursor:
            self.cursor = cursor
            self.save_cursor()

    def stop(self):
        if not self.running:
            return
        self.running = False
        self.wake.set()
        try:
            self.cloud.call("offline", {}, timeout=4)
        except CloudError:
            pass


class Shell:
    """Decide entre tela de login, modo conta e modo rede local, e guarda a sessão."""

    def __init__(self, profile_name: str, port: int):
        self.profile_name = profile_name
        self.port = port
        self.root = data_root() / safe_name(profile_name)
        self.root.mkdir(parents=True, exist_ok=True)
        self.listeners: list[queue.Queue] = []
        self.app: Messenger | None = None
        self.p2p: Server | None = None
        self.running = True
        self.had_client = False
        self.last_client = now()
        self.ui_port = 0
        self.lock = threading.RLock()
        self.google_state: tuple[str, float] | None = None
        self.config = load_config()
        self.account_file = self.root / "conta.json"

    @property
    def server(self) -> str:
        return str(os.environ.get("AURA_SERVIDOR") or self.config.get("servidor") or "").strip().rstrip("/")

    def emit(self, kind: str, data):
        for q in list(self.listeners):
            q.put((kind, data))

    # ------------------------------------------------------------ início
    def start_saved(self):
        acc = read_json(self.account_file, {})
        try:
            if acc.get("mode") == "lan":
                self.start_lan()
            elif acc.get("mode") == "cloud" and acc.get("token") and acc.get("server"):
                self.start_cloud(acc)
        except Exception as e:
            print("Não foi possível retomar a sessão:", e)

    def start_lan(self):
        with self.lock:
            if self.app:
                return
            app = Messenger(self.profile_name, self.port, self.listeners)
            P2PHandler.app = app
            p2p = None
            for port in range(self.port, self.port + 20):
                try:
                    p2p = Server(("0.0.0.0", port), P2PHandler)
                    break
                except OSError:
                    continue
            if not p2p:
                raise ValueError("Nenhuma porta livre entre %d e %d" % (self.port, self.port + 19))
            app.p2p_port = p2p.server_address[1]
            threading.Thread(target=p2p.serve_forever, daemon=True).start()
            app.start_discovery()
            self.p2p, self.app = p2p, app
            write_json(self.account_file, {"mode": "lan"})
            print(f"  Modo rede local. Seus contatos te acham em: "
                  f"{', '.join(f'{ip}:{app.p2p_port}' for ip in local_ips())}")

    def start_cloud(self, acc: dict):
        with self.lock:
            if self.app:
                return
            app = CloudMessenger(self, acc)
            app.start_discovery()
            self.app = app
            print(f"  Conectado como {acc.get('email')} em {acc.get('server')}")

    # ------------------------------------------------------------ login
    def client(self) -> CloudClient:
        return CloudClient(self.server)

    def info(self) -> dict:
        d = {"server": self.server, "configured": bool(self.server), "google": False, "reachable": False,
             "last_email": read_json(self.account_file, {}).get("email", "")}
        if self.server:
            try:
                r = self.client().call("info", timeout=8)
                d["reachable"] = r.get("app") == "aura-server"
                d["google"] = bool(r.get("google"))
            except CloudError as e:
                d["error"] = str(e)
        return d

    def finish_login(self, r: dict, status: str = "online") -> dict:
        u = r.get("user") or {}
        acc = {"mode": "cloud", "server": self.server, "token": r["token"], "uid": int(u["id"]),
               "email": u.get("email", ""), "user": {k: u.get(k) for k in ("name", "psm", "avatar")},
               "status": status if status in STATUSES else "online"}
        write_json(self.account_file, acc)
        try:
            os.chmod(self.account_file, 0o600)
        except OSError:
            pass
        self.start_cloud(acc)
        self.emit("auth", {"ok": True})
        return {"ok": True, "logged": True}

    def auth(self, action: str, d: dict) -> dict:
        if action == "info":
            return self.info()
        if action == "lan":
            self.start_lan()
            self.emit("auth", {"ok": True})
            return {"ok": True, "logged": True}
        if action == "logout":
            self.logout()
            return {"ok": True}
        if self.app:
            return {"ok": True, "logged": True}
        if action == "google":
            state = secrets.token_urlsafe(24)
            self.google_state = (state, now())
            url = f"{self.server}/google.php?" + urlencode({"start": 1, "port": self.ui_port, "state": state})
            webbrowser.open(url)
            return {"ok": True, "url": url}
        if action not in ("login", "register", "verify", "resend", "forgot", "reset"):
            raise ValueError("Ação desconhecida")
        payload = {k: d.get(k) for k in ("email", "password", "name", "code") if k in d}
        payload["device"] = device_name()
        try:
            r = self.client().call(action, payload)
        except CloudError as e:
            raise ValueError(str(e))
        if r.get("token"):
            return self.finish_login(r, str(d.get("status") or "online"))
        return r

    def google_callback(self, ticket: str, state: str) -> tuple[bool, str]:
        gs = self.google_state
        if not gs or not secrets.compare_digest(gs[0], state) or now() - gs[1] > 900:
            return False, "Esse login não foi iniciado por este AURA MSN. Clique em “Entrar com Google” de novo."
        self.google_state = None
        if self.app:
            return True, "Você já está conectado."
        try:
            r = self.client().call("google_ticket", {"ticket": ticket, "device": device_name()})
            self.finish_login(r)
            return True, "Pronto! Pode fechar esta aba e voltar ao AURA MSN."
        except (CloudError, KeyError) as e:
            self.emit("autherr", {"msg": str(e)})
            return False, str(e)

    def drop_app(self):
        with self.lock:
            app, self.app = self.app, None
            p2p, self.p2p = self.p2p, None
        if app:
            app.stop()
        if p2p:
            threading.Thread(target=p2p.shutdown, daemon=True).start()
        return app

    def logout(self):
        app = self.drop_app()
        if isinstance(app, CloudMessenger):
            try:
                app.cloud.call("logout", {}, timeout=6)
            except CloudError:
                pass
        acc = read_json(self.account_file, {})
        write_json(self.account_file, {"email": acc.get("email", "")})
        self.emit("auth", {"ok": False})

    def auth_lost(self, msg: str):
        if not isinstance(self.app, CloudMessenger):
            return
        self.drop_app()
        acc = read_json(self.account_file, {})
        write_json(self.account_file, {"email": acc.get("email", "")})
        self.emit("auth", {"ok": False, "msg": msg})

    def shutdown(self):
        if not self.running:
            return
        self.running = False
        self.drop_app()
        self.emit("bye", {})


# ------------------------------------------------------------ servidores HTTP
class Server(ThreadingHTTPServer):
    daemon_threads = True
    # No Windows SO_REUSEADDR deixa dois processos "dividirem" a mesma porta TCP.
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class BaseHandler(BaseHTTPRequestHandler):
    app: Messenger
    server_version = "AURA/" + VERSION

    def log_message(self, *args):
        pass

    def send_json(self, obj, code: int = 200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise ValueError("Conteúdo grande demais")
        raw = self.rfile.read(n) if n else b"{}"
        data = json.loads(raw.decode("utf-8") or "{}")
        if not isinstance(data, dict):
            raise ValueError("JSON inválido")
        return data


class P2PHandler(BaseHandler):
    """Porta aberta para a rede: só fala o protocolo entre mensageiros."""

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/p2p/hello":
            self.send_json(self.app.public())
        elif path == "/p2p/avatar":
            invisible = self.app.profile["status"] == "invisible"
            self.send_json({"avatar": "" if invisible else self.app.profile.get("avatar", ""),
                            "ah": self.app.avatar_hash()})
        else:
            self.send_json({"error": "não encontrado"}, 404)

    def do_POST(self):
        if urlparse(self.path).path != "/p2p/msg":
            return self.send_json({"error": "não encontrado"}, 404)
        try:
            env = self.read_body()
            self.send_json(self.app.receive(env, self.client_address[0]))
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)


class UIHandler(BaseHandler):
    """Porta local (127.0.0.1) que serve a interface e a API protegida por token."""
    token = ""
    shell: "Shell"

    def need_app(self) -> Messenger:
        app = self.shell.app
        if not app:
            raise ValueError("Entre na sua conta primeiro.")
        return app
    STATIC = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
              ".js": "application/javascript; charset=utf-8", ".svg": "image/svg+xml",
              ".png": "image/png", ".ico": "image/x-icon"}

    def authed(self, q) -> bool:
        tok = self.headers.get("X-Token") or (q.get("t") or [""])[0]
        return secrets.compare_digest(tok, self.token)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/auth/google":
            ok, msg = self.shell.google_callback(q.get("ticket", [""])[0], q.get("state", [""])[0])
            return self.send_html("Tudo certo!" if ok else "Não deu certo", msg, ok)
        if not u.path.startswith("/api/"):
            return self.static(u.path)
        if not self.authed(q):
            return self.send_json({"error": "não autorizado"}, 403)
        shell = self.shell
        try:
            if u.path == "/api/ping":
                return self.send_json({"ok": True})
            if u.path == "/api/events":
                return self.events()
            if u.path == "/api/state":
                app = shell.app
                if not app:
                    return self.send_json({"login": True, "version": VERSION, "platform": sys.platform,
                                           "server": shell.server})
                with app.lock:
                    contacts = [app.contact_view(c) for c in app.contacts.values()]
                st = {"me": app.profile, "contacts": contacts, "version": VERSION, "mode": app.mode,
                      "downloads": str(app.recv_dir), "platform": sys.platform, "server": shell.server}
                st.update(app.state_extra())
                return self.send_json(st)
            app = self.need_app()
            if u.path == "/api/history":
                pid = q.get("peer", [""])[0]
                with app.lock:
                    msgs = list(app.history(pid))[-1500:]
                self.send_json({"messages": msgs})
            elif u.path == "/api/search":
                self.send_json({"results": app.search(q.get("q", [""])[0])})
            elif u.path == "/api/download":
                self.download(q.get("peer", [""])[0], q.get("mid", [""])[0])
            else:
                self.send_json({"error": "não encontrado"}, 404)
        except ValueError as exc:
            self.send_json({"error": str(exc), "login": True}, 409)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        u = urlparse(self.path)
        if not self.authed(parse_qs(u.query)):
            return self.send_json({"error": "não autorizado"}, 403)
        shell = self.shell
        try:
            d = self.read_body()
            peer = str(d.get("peer", ""))
            r: object = {"ok": True}
            if u.path.startswith("/api/auth/"):
                return self.send_json(shell.auth(u.path[len("/api/auth/"):], d))
            if u.path == "/api/quit":
                threading.Thread(target=shell.shutdown, daemon=True).start()
                return self.send_json(r)
            app = self.need_app()
            cloud = isinstance(app, CloudMessenger)
            if u.path == "/api/profile":
                r = app.update_profile(d)
            elif u.path == "/api/send":
                r = app.send_text(peer, d.get("text", ""))
            elif u.path == "/api/file":
                r = app.send_file(peer, d.get("name", "arquivo"), d.get("data", ""))
            elif u.path == "/api/nudge":
                r = app.send(peer, "nudge")
            elif u.path == "/api/typing":
                app.require_contact(peer)
                app.fire(peer, app.envelope("typing"))
            elif u.path == "/api/read":
                app.mark_read(peer)
            elif u.path == "/api/react":
                app.react(peer, str(d.get("mid", "")), d.get("emoji", ""))
            elif u.path == "/api/contacts/add":
                r = app.add_by_address(str(d.get("address", "") or d.get("email", "")))
            elif u.path == "/api/contacts/answer" and cloud:
                app.answer(peer, bool(d.get("accept")))
            elif u.path == "/api/contacts/remove" and cloud:
                app.remove_contact(peer)
            elif u.path == "/api/contacts/invite" and cloud:
                app.invite(str(d.get("email", "")))
            elif u.path == "/api/contacts/update":
                r = app.update_contact(peer, d)
            elif u.path == "/api/history/clear":
                app.clear_history(peer)
            elif u.path == "/api/reveal":
                m = app.find_msg(peer, str(d.get("mid", "")))
                if m and m.get("file"):
                    open_path(Path(m["file"]["path"]), select=True)
            elif u.path == "/api/openfolder":
                app.recv_dir.mkdir(parents=True, exist_ok=True)
                open_path(app.recv_dir)
            else:
                return self.send_json({"error": "não encontrado"}, 404)
            self.send_json(r)
        except ValueError as exc:
            self.send_json({"error": str(exc)}, 400)
        except Exception as exc:  # pragma: no cover
            self.send_json({"error": f"Erro interno: {exc}"}, 500)

    def static(self, path: str):
        name = "index.html" if path in ("/", "") else path.lstrip("/")
        f = (WEB_DIR / name).resolve()
        if WEB_DIR.resolve() not in f.parents or not f.is_file():
            return self.send_json({"error": "não encontrado"}, 404)
        body = f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", self.STATIC.get(f.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, title: str, msg: str, ok: bool = True):
        c = "#22c55e" if ok else "#ef4444"
        page = ('<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>AURA MSN</title></head>'
                '<body style="margin:0;min-height:100vh;display:grid;place-items:center;font-family:Segoe UI,Ubuntu,sans-serif;'
                'background:linear-gradient(135deg,#3b82f6,#8b5cf6 60%,#14b8a6)"><div style="background:#fff;border-radius:18px;'
                'padding:30px 34px;max-width:420px;text-align:center;box-shadow:0 10px 40px rgba(0,0,0,.2)">'
                f'<div style="font-size:44px;color:{c}">{"✔" if ok else "⚠"}</div><h1 style="font-size:21px">'
                f'{title}</h1><p style="color:#4b5468;line-height:1.5">{msg}</p></div></body></html>')
        body = page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def download(self, peer: str, mid: str):
        m = self.need_app().find_msg(peer, mid)
        if not m or not m.get("file"):
            return self.send_json({"error": "não encontrado"}, 404)
        p = Path(m["file"]["path"])
        if not p.is_file():
            return self.send_json({"error": "O arquivo foi movido ou apagado"}, 404)
        self.send_response(200)
        self.send_header("Content-Type", m["file"].get("mime") or "application/octet-stream")
        self.send_header("Content-Length", str(p.stat().st_size))
        self.send_header("Content-Disposition", f"inline; filename*=UTF-8''{quote(p.name)}")
        self.end_headers()
        with p.open("rb") as fh:
            shutil.copyfileobj(fh, self.wfile)

    def events(self):
        app = self.shell
        q: queue.Queue = queue.Queue()
        app.listeners.append(q)
        app.had_client = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(b"retry: 1500\nevent: hello\ndata: {}\n\n")
            self.wfile.flush()
            while app.running:
                try:
                    kind, data = q.get(timeout=15)
                    if kind == "bye":
                        break
                    chunk = f"event: {kind}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
                except queue.Empty:
                    chunk = ": ping\n\n"
                self.wfile.write(chunk.encode("utf-8"))
                self.wfile.flush()
            self.wfile.write(b"event: bye\ndata: {}\n\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        finally:
            if q in app.listeners:
                app.listeners.remove(q)
            app.last_client = now()


# ---------------------------------------------------------------- janela
def find_app_browser() -> str | None:
    if os.name == "nt":
        roots = [os.environ.get(k) for k in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA")]
        rel = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe",
               r"BraveSoftware\Brave-Browser\Application\brave.exe", r"Chromium\Application\chrome.exe"]
        for r in rel:
            for root in roots:
                if root and Path(root, r).is_file():
                    return str(Path(root, r))
        return None
    for exe in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable",
                "brave-browser", "microsoft-edge", "microsoft-edge-stable", "vivaldi-stable"):
        p = shutil.which(exe)
        if p:
            return p
    return None


def open_window(url: str, profile_dir: Path) -> None:
    exe = find_app_browser()
    if exe:
        try:
            subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile_dir}",
                              "--no-first-run", "--no-default-browser-check",
                              "--window-size=1120,740", "--disable-features=Translate"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except OSError:
            pass
    webbrowser.open(url)


# ------------------------------------------------------------------ ícones
def make_icon_png(size: int) -> bytes:
    """Desenha o ícone (gradiente aura + balão) sem bibliotecas externas."""
    stops = [(0.0, (59, 130, 246)), (0.55, (139, 92, 246)), (1.0, (20, 184, 166))]

    def grad(t):
        for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
            if t <= t1:
                k = (t - t0) / (t1 - t0)
                return tuple(c0[i] + (c1[i] - c0[i]) * k for i in range(3))
        return stops[-1][1]

    def sample(x, y):
        r = 0.22
        dx = max(r - x, 0, x - (1 - r))
        dy = max(r - y, 0, y - (1 - r))
        if dx * dx + dy * dy > r * r:
            return None
        bg = grad((x + y) / 2)
        ex, ey = (x - 0.5) / 0.31, (y - 0.46) / 0.235
        in_bubble = ex * ex + ey * ey <= 1
        # cauda do balão
        if not in_bubble and 0.27 <= x <= 0.45 and 0.62 <= y <= 0.82:
            in_bubble = (y - 0.62) <= (0.45 - x) * 1.1 and x >= 0.27 + (y - 0.62) * 0.2
        if in_bubble:
            dots = any(((x - cx) ** 2 + (y - 0.46) ** 2) <= 0.045 ** 2 for cx in (0.38, 0.5, 0.62))
            return bg if dots else (255, 255, 255)
        return bg

    ss = 3
    rows = []
    for py in range(size):
        row = bytearray([0])
        for px in range(size):
            acc = [0.0, 0.0, 0.0]
            a = 0
            for sy in range(ss):
                for sx in range(ss):
                    c = sample((px + (sx + 0.5) / ss) / size, (py + (sy + 0.5) / ss) / size)
                    if c:
                        a += 1
                        for i in range(3):
                            acc[i] += c[i]
            if a:
                row += bytes([int(acc[0] / a), int(acc[1] / a), int(acc[2] / a), int(255 * a / (ss * ss))])
            else:
                row += b"\0\0\0\0"
        rows.append(bytes(row))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))


def generate_icons(folder: Path) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    if (folder / "icone.ico").is_file() and (folder / "icone.png").is_file():
        print("Ícones já existem em", folder)  # mantém o ícone desenhado que vem no pacote
        return
    pngs = {s: make_icon_png(s) for s in (16, 32, 48, 256)}
    (folder / "icone.png").write_bytes(pngs[256])
    header = struct.pack("<HHH", 0, 1, len(pngs))
    entries, data, offset = b"", b"", 6 + 16 * len(pngs)
    for s, png in pngs.items():
        entries += struct.pack("<BBBBHHII", s % 256, s % 256, 0, 0, 1, 32, len(png), offset)
        data += png
        offset += len(png)
    (folder / "icone.ico").write_bytes(header + entries + data)
    print("Ícones gerados em", folder)


# ------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=f"{APP_NAME} {VERSION}")
    ap.add_argument("--perfil", default="padrao", help="nome do perfil (várias contas no mesmo PC)")
    ap.add_argument("--porta", type=int, default=P2P_PORT, help="porta TCP para os contatos (padrão 47101)")
    ap.add_argument("--sem-janela", action="store_true", help="não abre a janela, só mostra o endereço")
    ap.add_argument("--manter-aberto", action="store_true", help="não encerra ao fechar a janela")
    ap.add_argument("--gerar-icones", action="store_true", help="gera icone.png e icone.ico e sai")
    args = ap.parse_args()

    if args.gerar_icones:
        return generate_icons(WEB_DIR)

    shell = Shell(args.perfil, args.porta)

    if sys.stdout is None or sys.stderr is None:  # pythonw no Windows: registra em arquivo
        log = open(shell.root / "aura.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = log

    # instância única por perfil: se já está aberto, só mostra a janela
    rt_file = shell.root / "execucao.json"
    rt = read_json(rt_file, {})
    if rt.get("port") and rt.get("token"):
        try:
            req = Request(f"http://127.0.0.1:{rt['port']}/api/ping", headers={"X-Token": rt["token"]})
            with OPENER.open(req, timeout=2) as r:
                if json.loads(r.read()).get("ok"):
                    url = f"http://127.0.0.1:{rt['port']}/?t={rt['token']}"
                    print("O AURA já está aberto:", url)
                    if not args.sem_janela:
                        open_window(url, shell.root / "janela")
                    return
        except Exception:
            pass

    UIHandler.shell = shell
    UIHandler.token = secrets.token_urlsafe(24)
    ui = Server(("127.0.0.1", 0), UIHandler)
    shell.ui_port = ui.server_address[1]
    write_json(rt_file, {"port": shell.ui_port, "token": UIHandler.token, "pid": os.getpid()})
    threading.Thread(target=ui.serve_forever, daemon=True).start()

    print(f"{APP_NAME} {VERSION} — perfil '{args.perfil}'")
    print(f"  Servidor: {shell.server or '(não configurado — só rede local)'}")
    shell.start_saved()

    url = f"http://127.0.0.1:{shell.ui_port}/?t={UIHandler.token}"
    print(f"  Interface: {url}")
    if not args.sem_janela:
        open_window(url, shell.root / "janela")

    keep = args.manter_aberto or args.sem_janela
    try:  # desligar o PC / encerrar a sessão também avisa o servidor que você saiu
        import signal
        signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    except (ValueError, OSError, AttributeError):
        pass
    try:
        while shell.running:
            time.sleep(0.5)
            if not keep and shell.had_client and not shell.listeners and now() - shell.last_client > 25:
                print("Janela fechada — encerrando.")
                break
    except KeyboardInterrupt:
        pass
    finally:
        shell.shutdown()
        time.sleep(0.4)
        try:
            rt_file.unlink()
        except OSError:
            pass
        ui.shutdown()


if __name__ == "__main__":
    main()
