#!/usr/bin/env bash
# Instala o AURA MSN no Linux Mint (e Ubuntu/Debian) só para o seu usuário.
#   bash instalar-linux-mint.sh              instala
#   bash instalar-linux-mint.sh --desinstalar remove
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.local/share/aura-msn/app"
BIN="$HOME/.local/bin/aura-msn"
DESKTOP="$HOME/.local/share/applications/aura-msn.desktop"
ICON="$HOME/.local/share/icons/hicolor/scalable/apps/aura-msn.svg"

if [[ "${1:-}" == "--desinstalar" ]]; then
  rm -rf "$DEST" "$BIN" "$DESKTOP" "$ICON"
  rm -f "$HOME/.config/autostart/aura-msn.desktop"
  command -v update-desktop-database >/dev/null && update-desktop-database "$HOME/.local/share/applications" || true
  echo "AURA MSN removido (histórico continua em ~/.local/share/aura-msn/)."
  exit 0
fi

if ! command -v python3 >/dev/null; then
  echo "Python 3 não encontrado. Instale com: sudo apt install python3"
  exit 1
fi

mkdir -p "$DEST" "$(dirname "$BIN")" "$(dirname "$DESKTOP")" "$(dirname "$ICON")"
cp "$SRC/aura_msn.py" "$DEST/"
cp -r "$SRC/web" "$DEST/"
cp "$SRC/aura_config.json" "$DEST/"
cp "$SRC/web/icone.svg" "$ICON"

cat > "$BIN" <<EOF
#!/usr/bin/env bash
exec python3 "$DEST/aura_msn.py" "\$@"
EOF
chmod +x "$BIN" "$DEST/aura_msn.py"

cat > "$DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=AURA MSN
GenericName=Mensageiro instantâneo
Comment=Aplicativo de mensagens AURA MSN
Exec=$BIN
Icon=aura-msn
Terminal=false
Categories=Network;InstantMessaging;Chat;
Keywords=chat;mensagem;messenger;rede;
StartupNotify=true
EOF
chmod +x "$DESKTOP"
command -v update-desktop-database >/dev/null && update-desktop-database "$HOME/.local/share/applications" || true
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q "$HOME/.local/share/icons/hicolor" 2>/dev/null || true

echo
echo "✔ AURA MSN instalado! Procure por \"AURA MSN\" no menu."
echo

if ! command -v chromium >/dev/null && ! command -v chromium-browser >/dev/null \
   && ! command -v google-chrome >/dev/null && ! command -v brave-browser >/dev/null \
   && ! command -v microsoft-edge >/dev/null; then
  echo "• Dica: para o AURA abrir em janela própria (sem barra de endereço), instale o Chromium:"
  echo "      sudo apt install chromium"
  echo "  Sem ele, o AURA abre como uma aba do Firefox — funciona igual."
  echo
fi

if command -v ufw >/dev/null && sudo -n ufw status 2>/dev/null | grep -q "Status: active"; then
  echo "• O firewall (ufw) está ativo. Libere o AURA com:"
  echo "      sudo ufw allow 47100/udp && sudo ufw allow 47101:47120/tcp"
  echo
fi

read -r -p "Abrir o AURA automaticamente ao entrar no sistema? [s/N] " ans || true
if [[ "${ans,,}" == s* ]]; then
  mkdir -p "$HOME/.config/autostart"
  cp "$DESKTOP" "$HOME/.config/autostart/aura-msn.desktop"
  echo "Ok, ele vai iniciar junto com a sessão."
fi
