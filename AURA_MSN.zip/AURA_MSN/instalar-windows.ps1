﻿# Instala o AURA MSN no Windows 10/11 (sem precisar de administrador).
# Uso: clique com o botao direito > "Executar com o PowerShell"
#   ou: powershell -ExecutionPolicy Bypass -File instalar-windows.ps1
#   Para remover: powershell -ExecutionPolicy Bypass -File instalar-windows.ps1 -Desinstalar
param([switch]$Desinstalar)
$ErrorActionPreference = 'Stop'

$dest     = Join-Path $env:LOCALAPPDATA 'Programs\AURAMSN'
$menu     = Join-Path ([Environment]::GetFolderPath('Programs')) 'AURA MSN.lnk'
$desktop  = Join-Path ([Environment]::GetFolderPath('Desktop')) 'AURA MSN.lnk'

if ($Desinstalar) {
    Remove-Item $menu, $desktop -ErrorAction SilentlyContinue
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    Write-Host 'AURA MSN removido. (Historico e perfil continuam em %APPDATA%\AURAMSN)'
    exit 0
}

# 1. Python
$pyw = $null
foreach ($c in @('pyw', 'pythonw')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notlike '*WindowsApps*') { $pyw = $cmd.Source; break }
}
if (-not $pyw) {
    Write-Host 'Python 3 nao encontrado. Instalando via winget...'
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $cmd = Get-Command pythonw -ErrorAction SilentlyContinue
    if (-not $cmd) { $cmd = Get-Command pyw -ErrorAction SilentlyContinue }
    if (-not $cmd) { throw 'Instale o Python 3 em https://www.python.org/downloads/ e rode este instalador de novo.' }
    $pyw = $cmd.Source
}
$pyArgs = ''
if ((Split-Path $pyw -Leaf) -ieq 'pyw.exe') { $pyArgs = '-3 ' }

# 2. Copia os arquivos
$src = $PSScriptRoot
New-Item -ItemType Directory -Force $dest | Out-Null
Copy-Item (Join-Path $src 'aura_msn.py') $dest -Force
Copy-Item (Join-Path $src 'web') $dest -Recurse -Force
Copy-Item (Join-Path $src 'aura_config.json') $dest -Force
& ($pyw -replace 'w\.exe$', '.exe') "$dest\aura_msn.py" --gerar-icones | Out-Null

# 3. Atalhos
$sh = New-Object -ComObject WScript.Shell
foreach ($lnk in @($menu, $desktop)) {
    $s = $sh.CreateShortcut($lnk)
    $s.TargetPath = $pyw
    $s.Arguments = $pyArgs + '"' + "$dest\aura_msn.py" + '"'
    $s.WorkingDirectory = $dest
    $s.IconLocation = "$dest\web\icone.ico"
    $s.Description = 'AURA MSN - aplicativo de mensagens AURA MSN'
    $s.Save()
}

Write-Host ''
Write-Host 'AURA MSN instalado!' -ForegroundColor Green
Write-Host '  Atalhos criados no Menu Iniciar e na Area de Trabalho.'
Write-Host '  Abra o AURA MSN e entre com seu e-mail ou com o Google.'
Write-Host '  (So no modo rede local o Firewall pergunta: marque "Redes privadas" e clique em Permitir.)'
