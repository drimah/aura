# Servidor AURA MSN na HostGator (drimah.com.br)

O servidor guarda as contas, a lista de contatos, a presença (online, ausente…) e entrega as
mensagens e os arquivos. Ele é feito em PHP + MySQL, que já vem em qualquer plano de
hospedagem da HostGator. Você faz isto **uma vez só**, e não precisa passar nenhuma senha para ninguém.

O endereço final vai ser: **https://drimah.com.br/aura**

---

## 1. Conferir o PHP e o HTTPS
1. Entre no **cPanel** da HostGator.
2. Procure **"MultiPHP Manager"** (ou "Selecionar versão do PHP") e deixe o `drimah.com.br` em **PHP 8.1 ou mais novo**.
3. Abra `https://drimah.com.br` no navegador. Precisa aparecer o cadeado.
   Se não aparecer, procure **"SSL/TLS Status"** no cPanel e clique em **"Run AutoSSL"** (é grátis).

## 2. Criar o banco de dados
1. No cPanel, abra **"Bancos de dados MySQL"** (MySQL® Databases).
2. Em **Criar novo banco de dados**, digite `aura` e clique em **Criar**.
   O nome final fica algo como `seuusuario_aura`. **Anote esse nome.**
3. Mais abaixo, em **Adicionar novo usuário**, crie o usuário `aura` com uma senha forte
   (use o gerador de senha). O nome final fica `seuusuario_aura`. **Anote o usuário e a senha.**
4. Em **Adicionar usuário ao banco de dados**, escolha esse usuário e esse banco, clique em
   **Adicionar** e marque **TODOS OS PRIVILÉGIOS**.

## 3. Criar o e-mail que manda os códigos
1. No cPanel, abra **"Contas de e-mail"** e crie `nao-responda@drimah.com.br`.
2. Abra **"Email Deliverability"** (Capacidade de entrega de e-mail). Se aparecer algum problema
   em SPF ou DKIM, clique em **"Repair"**. Isso faz os códigos chegarem na caixa de entrada, e não no spam.

## 4. Enviar os arquivos
1. No cPanel, abra o **Gerenciador de arquivos** e entre na pasta do site `drimah.com.br`.
   Se ele for o domínio principal da conta, é a `public_html`. Se for um domínio adicional, costuma ser
   `public_html/drimah.com.br` (ou outra pasta, que aparece em cPanel → **Domínios**, coluna "Raiz do documento").
   Nos passos abaixo, onde está escrito `public_html`, use essa pasta.
2. Clique em **Carregar** (Upload) e envie o arquivo **`servidor/aura.zip`** deste pacote.
3. De volta ao `public_html`, clique com o botão direito em `aura.zip` → **Extrair**.
   Isso cria a pasta `public_html/aura` com tudo dentro. Depois pode apagar o `aura.zip`.
   (Se preferir enviar à mão: crie a pasta `aura` e envie tudo o que está em `servidor/aura`,
   inclusive os arquivos ocultos `.htaccess`. Para vê-los, marque **Configurações →
   "Mostrar arquivos ocultos"** no Gerenciador.)
4. Envie também o próprio `AURA_MSN.zip` para dentro da pasta `aura`, assim o botão de download
   da página https://drimah.com.br/aura funciona.

## 5. Configurar
1. No Gerenciador de arquivos, renomeie `config.exemplo.php` para **`config.php`**.
2. Clique com o botão direito em `config.php`, escolha **Editar** e preencha:
   - `db_name`, `db_user` e `db_pass` com o que você anotou no passo 2;
   - `site_url` já vem como `https://drimah.com.br/aura`;
   - `mail_from` já vem como `nao-responda@drimah.com.br`.
3. Salve.

## 6. Instalar as tabelas
Abra **https://drimah.com.br/aura/instalar.php**. Todos os itens devem ficar ✅.
Depois que tudo der certo, apague o `instalar.php` (ou renomeie para `instalar.php.feito`).

Pronto: o aplicativo já vem configurado para esse endereço (arquivo `aura_config.json`).
Já dá para criar conta com e-mail e senha.

---

## 7. (Opcional) "Entrar com Google"
1. Abra https://console.cloud.google.com e entre com a sua conta Google.
2. Crie um projeto chamado **AURA MSN**.
3. Vá em **APIs e serviços → Tela de consentimento OAuth** (ou "Google Auth Platform → Branding"):
   - Tipo de usuário: **Externo**;
   - Nome do app: `AURA MSN`, e-mail de suporte: o seu;
   - Domínio do app: página inicial `https://drimah.com.br/aura`, política de privacidade
     `https://drimah.com.br/aura/privacidade.html`;
   - Domínio autorizado: `drimah.com.br`;
   - Permissões (escopos): só `openid`, `email` e `profile`, que são os básicos e não exigem análise do Google.
4. Em **Público-alvo** (Audience), clique em **Publicar app**. Enquanto o app estiver em "Teste",
   só os e-mails cadastrados como testadores conseguem entrar.
5. Vá em **Credenciais → Criar credenciais → ID do cliente OAuth**:
   - Tipo: **Aplicativo da Web**;
   - URIs de redirecionamento autorizados: **`https://drimah.com.br/aura/google.php`**
6. Copie o **ID do cliente** e a **Chave secreta do cliente** para o `config.php`
   (`google_client_id` e `google_client_secret`) e salve.
7. Abra o `instalar.php` de novo (ou recoloque-o por um instante): o item "Entrar com Google" deve aparecer ✅.
   O botão "Entrar com Google" aparece sozinho no aplicativo.

---

## Bom saber
- **Segurança:** as senhas são guardadas só como resumo (`password_hash`), as sessões são tokens
  aleatórios, e há limites de tentativas de login e de envio de códigos. O `config.php` e a pasta
  `dados` ficam bloqueados para o navegador pelo `.htaccess`.
- **Limpeza automática:** mensagens e arquivos ficam no servidor por 30 dias (`keep_days`) e depois
  são apagados sozinhos. O histórico completo fica no computador de cada pessoa.
- **Capacidade:** cada aplicativo aberto consulta o servidor a cada 2 segundos (a cada 5 quando
  está "Ausente"). Na hospedagem compartilhada isso aguenta bem algumas dezenas de pessoas online
  ao mesmo tempo. Se o AURA crescer muito, o próximo passo é um VPS.
- **Espaço:** os arquivos enviados ocupam o espaço da sua hospedagem durante esses 30 dias.
  Dá para diminuir `max_file_mb` ou `keep_days` no `config.php`.
- **Erros:** se algo der errado, o cPanel mostra os detalhes em **"Erros"** (Errors / error_log).
