'use strict';
/* AURA MSN — interface */

const TOKEN = new URLSearchParams(location.search).get('t') || '';
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const CORE = window.AuraCore || null;   // celular / navegador: núcleo em core.js
async function api(path, body) {
  if (CORE) return CORE.api(path, body);
  const opt = { headers: { 'X-Token': TOKEN } };
  if (body !== undefined) {
    opt.method = 'POST';
    opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(body);
  }
  const r = await fetch(path, opt);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || r.statusText);
  return data;
}

const S = {
  me: null, contacts: new Map(), active: null, hist: new Map(), filter: '', convFilter: '',
  started: Date.now(), lastActivity: Date.now(), autoAway: false, lastTypingSent: 0,
  typingTimer: null, closedGroups: new Set(JSON.parse(safeGet('closedGroups') || '["Offline"]')),
  addresses: [], downloads: '', version: '', unseen: 0,
};

function safeGet(k) { try { return localStorage.getItem(k); } catch { return null; } }
function safeSet(k, v) { try { localStorage.setItem(k, v); } catch { /* ignora */ } }

const STATUS = {
  online: 'Disponível', away: 'Ausente', busy: 'Ocupado', invisible: 'Invisível', offline: 'Offline',
};

/* ---------------------------------------------------------------- ícones (linha, 24×24) */
const IC = {
  sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2.2"/><circle cx="9" cy="17" r="2.2"/>',
  smile: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14.2c1.9 2.2 5.1 2.2 7 0"/><circle class="f" cx="9" cy="10" r="1.1"/><circle class="f" cx="15" cy="10" r="1.1"/>',
  smilePlus: '<path d="M20.6 10.6A9 9 0 1 1 13.4 3.1"/><path d="M8.5 14.2c1.9 2.2 5.1 2.2 7 0"/><circle class="f" cx="9" cy="10" r="1.1"/><circle class="f" cx="15" cy="10" r="1.1"/><path d="M19 2.5v5M16.5 5h5"/>',
  clip: '<path d="M20 11.6 12 19.5a5 5 0 0 1-7.1-7.1l8.4-8.4a3.3 3.3 0 0 1 4.7 4.7l-8.4 8.4a1.7 1.7 0 0 1-2.4-2.4l7.7-7.7"/>',
  nudge: '<rect x="8" y="3.5" width="8" height="17" rx="2.2"/><path d="M11 17.2h2M4.5 8.5v7M19.5 8.5v7M2 10.5v3M22 10.5v3"/>',
  star: '<path d="m12 3.4 2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.8l-5.2 2.8 1-5.9-4.3-4.1 5.9-.8z"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  more: '<circle class="f" cx="5.5" cy="12" r="1.5"/><circle class="f" cx="12" cy="12" r="1.5"/><circle class="f" cx="18.5" cy="12" r="1.5"/>',
  send: '<path d="M4.4 11.1 19.2 4.3c.7-.3 1.4.4 1.1 1.1l-6.8 14.8c-.3.7-1.3.6-1.5-.1l-1.6-5.4a1 1 0 0 0-.7-.7l-5.4-1.6c-.7-.2-.8-1.2-.1-1.5z"/><path d="m10.6 13.4 4.2-4.2"/>',
  userPlus: '<circle cx="9.5" cy="8" r="3.8"/><path d="M2.8 20c.6-3.6 3.4-5.6 6.7-5.6s6.1 2 6.7 5.6M19 8v6M16 11h6"/>',
  userX: '<circle cx="9.5" cy="8" r="3.8"/><path d="M2.8 20c.6-3.6 3.4-5.6 6.7-5.6s6.1 2 6.7 5.6M17 9l4.5 4.5M21.5 9 17 13.5"/>',
  chat: '<path d="M20.5 11.6a8.2 8.2 0 0 1-12 7.3L3.5 20.3l1.4-4.6a8.2 8.2 0 1 1 15.6-4.1z"/>',
  pencil: '<path d="M4 20h4L19.3 8.7a2.1 2.1 0 0 0 0-3L18.3 4.7a2.1 2.1 0 0 0-3 0L4 16z"/><path d="m13.5 6.5 4 4"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5"/><circle class="f" cx="12" cy="7.8" r="1.1"/>',
  eye: '<path d="M2.3 12C3.3 10.6 6.8 6 12 6s8.7 4.6 9.7 6c-1 1.4-4.5 6-9.7 6s-8.7-4.6-9.7-6z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M3 3l18 18M10.6 6.1c.5-.1.9-.1 1.4-.1 5.2 0 8.7 4.6 9.7 6-.4.6-1.2 1.7-2.4 2.9M6.6 6.6C4.5 8 3 10 2.3 12c1 1.4 4.5 6 9.7 6 1.6 0 3-.4 4.3-1.1M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="m5.7 5.7 12.6 12.6"/>',
  checkCircle: '<circle cx="12" cy="12" r="9"/><path d="m8 12.4 2.8 2.8L16.2 9.8"/>',
  trash: '<path d="M4 7h16M9.5 7V4.5h5V7M6 7l1 12.5a1.5 1.5 0 0 0 1.5 1.5h7a1.5 1.5 0 0 0 1.5-1.5L18 7M10 11v6M14 11v6"/>',
  eraser: '<path d="m7.5 20-4-4a1.8 1.8 0 0 1 0-2.5L13 4a1.8 1.8 0 0 1 2.5 0l4.5 4.5a1.8 1.8 0 0 1 0 2.5L11 20zM20 20H7.5M9 10l5.5 5.5"/>',
  image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="m20.5 16-4.7-4.7a1 1 0 0 0-1.4 0L6 19.5"/>',
  music: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  video: '<rect x="3" y="6" width="13" height="12" rx="2.5"/><path d="m16 10.3 4.4-2.6a.8.8 0 0 1 1.1.7v7.2a.8.8 0 0 1-1.1.7L16 13.7"/>',
  file: '<path d="M14 3.5H7.5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2V8z"/><path d="M14 3.5V8h4.5"/>',
  fileText: '<path d="M14 3.5H7.5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2V8z"/><path d="M14 3.5V8h4.5M9 12.5h6M9 16h4"/>',
  archive: '<rect x="3.5" y="4" width="17" height="4.5" rx="1.2"/><path d="M5 8.5v10a1.5 1.5 0 0 0 1.5 1.5h11a1.5 1.5 0 0 0 1.5-1.5v-10M10 12.5h4"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  hourglass: '<path d="M7 3.5h10M7 20.5h10M8 3.5c0 4.5 8 4.5 8 8.5s-8 4-8 8.5M16 3.5c0 4.5-8 4.5-8 8.5"/>',
  alert: '<path d="M10.3 4.3 2.8 17.5a2 2 0 0 0 1.7 3h15a2 2 0 0 0 1.7-3L13.7 4.3a2 2 0 0 0-3.4 0z"/><path d="M12 9.5v4"/><circle class="f" cx="12" cy="17" r="1.1"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  checks: '<path d="m2.5 12.5 4.5 4.5L16 8M11.5 16.5l.5.5 9-9"/>',
  sparkle: '<path d="M12 3.5 13.8 9l5.7 1.8-5.7 1.9L12 18.5l-1.8-5.8L4.5 10.8 10.2 9z"/><path d="M19 3v3M17.5 4.5h3"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m3.5 7 8.5 6 8.5-6"/>',
  inbox: '<path d="M3 13.5 5.4 6a2 2 0 0 1 1.9-1.5h9.4A2 2 0 0 1 18.6 6l2.4 7.5V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 13.5h5l1.5 2.5h5l1.5-2.5h5"/>',
  folder: '<path d="M3.5 7.5a2 2 0 0 1 2-2h3.6l2 2h7.4a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
  logout: '<path d="M14.5 4.5H18a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-3.5M10 8l-4 4 4 4M6 12h10"/>',
  login: '<path d="M14.5 4.5H18a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-3.5M9.5 8l4 4-4 4M3.5 12h10"/>',
  power: '<path d="M12 3.5v8M7 6.3a8 8 0 1 0 10 0"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  arrowLeft: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  wifiOff: '<path d="M3 3l18 18M8.5 16.4a5 5 0 0 1 7 0M5 12.9a10 10 0 0 1 5-2.7M14.8 10.3A10 10 0 0 1 19 12.9M2 9.3a15 15 0 0 1 4.3-2.7M10.6 5.6A15 15 0 0 1 22 9.3"/><circle class="f" cx="12" cy="19.5" r="1.1"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
};
const icon = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${IC[n] || ''}</svg>`;
const mi = (n, label) => `${icon(n)}<span>${label}</span>`;  // item de menu
function paintIcons(root = document) {
  root.querySelectorAll('[data-ic]').forEach(el => { el.innerHTML = icon(el.dataset.ic) + (el.dataset.label ? `<span>${el.dataset.label}</span>` : ''); });
}

/* ------------------------------------------------------------- emoticons */
const EMOTICONS = {
  ':)': '🙂', ':-)': '🙂', ':D': '😄', ':-D': '😄', ';)': '😉', ';-)': '😉', ':(': '🙁', ':-(': '🙁',
  ':P': '😛', ':-P': '😛', ':O': '😮', ':-O': '😮', ":'(": '😢', '8)': '😎', '8-)': '😎', ':@': '😠',
  ':S': '😕', ':$': '😳', ':|': '😐', '<3': '❤️', '</3': '💔', '(y)': '👍', '(n)': '👎', '(l)': '❤️',
  '(u)': '💔', '(k)': '💋', '(f)': '🌹', '(c)': '☕', '(*)': '⭐', '(pi)': '🍕', '(^)': '🎂',
  '(z)': '💤', '(mp)': '📱', '(e)': '✉️', '(g)': '🎁', '(8)': '🎵', '(h)': '😎', '(a)': '😇',
  '(6)': '😈', '(b)': '🍺', '(d)': '🍸', '(r)': '🌈', '(s)': '🌙', '(#)': '☀️', '(o)': '⏰', '(ok)': '👌',
  '(hug)': '🤗', 'xD': '😆', '^^': '😊', ':*': '😘',
};
const EMO_L = Object.fromEntries(Object.entries(EMOTICONS).map(([k, v]) => [k.toLowerCase(), v]));
const EMO_RE = new RegExp('(^|\\s)(' + Object.keys(EMOTICONS).sort((a, b) => b.length - a.length)
  .map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')(?=\\s|$)', 'gi');
const emo = t => t.replace(EMO_RE, (all, pre, k) => pre + (EMO_L[k.toLowerCase()] || k));

const EMOJI_SETS = {
  'Carinhas': '😀 😄 😁 😆 😂 🤣 🙂 😉 😊 😇 🥰 😍 😘 😋 😛 😜 🤪 😎 🤓 🥳 🤩 😏 😌 😴 🤔 🤨 😐 😶 🙄 😬 😮 😲 😳 🥺 😢 😭 😤 😠 😡 🤯 😱 🤗 🤭 🫡 🤫 😷 🤒 🤠 😈 👻 💀 🤖'.split(' '),
  'Gestos': '👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 💪 👋 🤝 ✍️ 👀 🫶'.split(' '),
  'Coisas': '❤️ 🧡 💛 💚 💙 💜 🖤 💔 💯 ✨ ⭐ 🔥 🎉 🎂 🎁 🎵 🎮 ☕ 🍕 🍺 🍫 🌹 🌈 ☀️ 🌙 ⚡ 💤 📱 💻 📷 ✉️ ⏰ 🚀 🐶 🐱 🦋 🌻'.split(' '),
};

function styled(s) {
  return s
    .replace(/(^|[\s(])\*([^*\n]+?)\*(?=[\s).,!?;:]|$)/g, '$1<b>$2</b>')
    .replace(/(^|[\s(])_([^_\n]+?)_(?=[\s).,!?;:]|$)/g, '$1<i>$2</i>')
    .replace(/(^|[\s(])~([^~\n]+?)~(?=[\s).,!?;:]|$)/g, '$1<s>$2</s>')
    .replace(/(^|[\s(])`([^`\n]+?)`(?=[\s).,!?;:]|$)/g, '$1<code>$2</code>');
}
function fmt(text, hl) {
  const t = emo(String(text || ''));
  let html = t.split(/(https?:\/\/[^\s<>"]+)/g).map((part, i) => i % 2
    ? `<a href="${esc(part)}" target="_blank" rel="noopener noreferrer">${esc(part)}</a>`
    : styled(esc(part))).join('').replace(/\n/g, '<br>');
  if (hl) html = highlight(html, hl);
  return html;
}
function highlight(html, q) {
  const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  return html.split(/(<[^>]+>)/g).map(p => p.startsWith('<') ? p : p.replace(re, m => `<mark class="hl">${m}</mark>`)).join('');
}
const isJumbo = t => /^(?:\p{Extended_Pictographic}|\p{Emoji_Modifier}|‍|️|\s){1,16}$/u.test(t) && /\p{Extended_Pictographic}/u.test(t);

/* ----------------------------------------------------------------- sons */
let AC = null;
function tone(seq) {
  if (!S.me?.sounds) return;
  try {
    AC = AC || new AudioContext();
    let t = AC.currentTime + 0.02;
    for (const [f, d, type = 'sine', vol = 0.12] of seq) {
      const o = AC.createOscillator(), g = AC.createGain();
      o.type = type; o.frequency.value = f;
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g).connect(AC.destination);
      o.start(t); o.stop(t + d + 0.03);
      t += d * 0.82;
    }
  } catch { /* sem áudio */ }
}
const SND = {
  msg: [[784, .1], [1175, .16]],
  signin: [[523, .13], [659, .13], [784, .13], [1047, .26]],
  nudge: [[150, .09, 'square', .07], [120, .09, 'square', .07], [150, .09, 'square', .07], [120, .09, 'square', .07], [150, .14, 'square', .07]],
  sent: [[988, .05, 'sine', .04]],
};

/* ------------------------------------------------------------- avatar */
function hue(id) { let h = 7; for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; }
function initials(n) { return (String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => [...w][0]).join('') || '?').toUpperCase(); }
function avatarHTML(p, size = '') {
  const st = p.status || 'offline';
  const h = hue(p.id);
  const inner = p.avatar
    ? `<img src="${esc(p.avatar)}" alt="">`
    : `<span style="background:linear-gradient(135deg,hsl(${h} 72% 58%),hsl(${(h + 55) % 360} 70% 46%))">${esc(initials(p.name))}</span>`;
  return `<div class="avatar ${size} st-${st}">${inner}<i class="ring"></i></div>`;
}

/* ------------------------------------------------------------ utilitários */
const pad = n => String(n).padStart(2, '0');
const hhmm = ts => { const d = new Date(ts * 1000); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
function dayLabel(ts) {
  const d = new Date(ts * 1000), today = new Date(); today.setHours(0, 0, 0, 0);
  const diff = Math.round((today - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  if (diff === 0) return 'Hoje';
  if (diff === 1) return 'Ontem';
  return d.toLocaleDateString('pt-BR', { weekday: diff < 7 ? 'long' : undefined, day: '2-digit', month: 'long', year: d.getFullYear() !== today.getFullYear() ? 'numeric' : undefined });
}
function ago(ts) {
  if (!ts) return 'nunca visto';
  const s = Date.now() / 1000 - ts;
  if (s < 90) return 'visto agora há pouco';
  if (s < 3600) return `visto há ${Math.round(s / 60)} min`;
  if (s < 86400) return `visto hoje às ${hhmm(ts)}`;
  return `visto em ${new Date(ts * 1000).toLocaleDateString('pt-BR')}`;
}
const fsize = n => n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(1)} MB`;
function fileIcon(mime, name) {
  if (/^image\//.test(mime)) return icon('image');
  if (/^audio\//.test(mime)) return icon('music');
  if (/^video\//.test(mime)) return icon('video');
  if (/zip|rar|7z|tar|gzip/.test(mime + name)) return icon('archive');
  if (/pdf$|text|word|document/.test(mime)) return icon('fileText');
  return icon('file');
}

function toast(title, sub = '', opts = {}) {
  const el = document.createElement('div');
  el.className = 'toast' + (opts.err ? ' err' : '');
  el.innerHTML = `${opts.icon ? `<div>${opts.icon}</div>` : ''}<div><b>${esc(title)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</div>`;
  el.onclick = () => { el.remove(); opts.onClick?.(); };
  $('#toasts').append(el);
  setTimeout(() => el.remove(), opts.ms || 4500);
}
const fail = e => toast('Ops!', e.message || String(e), { err: true, icon: icon('alert') });

function notify(title, body, peer) {
  if (!S.me?.notify || !document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    const n = new Notification(title, { body, icon: 'icone.svg', tag: peer || 'aura' });
    n.onclick = () => { window.focus(); if (peer) openChat(peer); n.close(); };
  } catch { /* ignora */ }
}

let titleBlink = null;
function updateTitle() {
  const total = [...S.contacts.values()].reduce((a, c) => a + (c.unread || 0), 0);
  const base = total ? `(${total}) AURA MSN` : 'AURA MSN';
  clearInterval(titleBlink); titleBlink = null;
  document.title = base;
  if (total && document.hidden) {
    let flip = false;
    titleBlink = setInterval(() => { flip = !flip; document.title = flip ? '• Nova mensagem!' : base; }, 1200);
  }
}
document.addEventListener('visibilitychange', () => {
  updateTitle();
  if (!document.hidden && S.active) markRead(S.active);
});

/* ---------------------------------------------------------------- perfil */
function applyTheme() {
  const r = document.documentElement;
  if (S.me.theme === 'auto') delete r.dataset.theme; else r.dataset.theme = S.me.theme;
  r.style.setProperty('--accent', S.me.accent || '#3b82f6');
}
function renderMe() {
  const me = S.me;
  $('#meAvatar').innerHTML = avatarHTML({ ...me, status: me.status === 'invisible' ? 'offline' : me.status }, 'lg');
  if (document.activeElement !== $('#meName')) $('#meName').value = me.name;
  if (document.activeElement !== $('#mePsm')) $('#mePsm').value = me.psm;
  $('#statusLabel').textContent = STATUS[me.status];
  $('#statusBtn .dot').className = 'dot ' + me.status;
  applyTheme();
}
async function saveProfile(patch) {
  try { S.me = await api('/api/profile', patch); renderMe(); } catch (e) { fail(e); }
}
function bindProfile() {
  for (const [id, key] of [['#meName', 'name'], ['#mePsm', 'psm']]) {
    const el = $(id);
    el.addEventListener('keydown', e => { if (e.key === 'Enter') el.blur(); if (e.key === 'Escape') { el.value = S.me[key]; el.blur(); } });
    el.addEventListener('blur', () => { if (el.value.trim() !== S.me[key]) saveProfile({ [key]: el.value }); });
  }
  $('#statusBtn').onclick = e => showMenu(e.currentTarget, ['online', 'away', 'busy', 'invisible'].map(st => ({
    html: `<i class="dot ${st}"></i> ${STATUS[st]}`, run: () => { S.autoAway = false; saveProfile({ status: st }); },
  })));
  $('#meAvatar').onclick = e => showMenu(e.currentTarget, [
    { html: mi('image', 'Escolher imagem…'), run: () => $('#avatarFile').click() },
    ...(S.me.avatar ? [{ html: mi('trash', 'Remover foto'), danger: true, run: () => saveProfile({ avatar: '' }) }] : []),
  ]);
  $('#avatarFile').onchange = async e => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    try { saveProfile({ avatar: await resizeImage(f, 160) }); } catch { toast('Imagem inválida', '', { err: true }); }
  };
}
function resizeImage(file, size) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas'); c.width = c.height = size;
      const s = Math.min(img.width, img.height);
      c.getContext('2d').drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
      URL.revokeObjectURL(img.src);
      res(c.toDataURL('image/jpeg', 0.86));
    };
    img.onerror = rej;
    img.src = URL.createObjectURL(file);
  });
}

/* ---------------------------------------------------------------- contatos */
function renderContacts() {
  const q = S.filter.toLowerCase();
  const all = [...S.contacts.values()].filter(c => !c.hidden || c.unread);
  const list = all.filter(c => !q || c.name.toLowerCase().includes(q) || (c.psm || '').toLowerCase().includes(q));
  const by = (a, b) => (b.unread - a.unread) || a.name.localeCompare(b.name, 'pt-BR');
  const ok = list.filter(c => (c.state || 'ok') === 'ok');
  const groups = [
    ['Favoritos', ok.filter(c => c.favorite)],
    ['Disponíveis', ok.filter(c => !c.favorite && c.status !== 'offline')],
    ['Offline', ok.filter(c => !c.favorite && c.status === 'offline')],
    ['Aguardando resposta', list.filter(c => c.state === 'out')],
  ];
  let html = '';
  const reqs = list.filter(c => c.state === 'in');
  if (reqs.length) {
    html += `<div class="group" style="cursor:default">Querem te adicionar (${reqs.length})</div>`;
    for (const c of reqs) {
      html += `<div class="contact request" data-req="${esc(c.id)}">${avatarHTML({ ...c, status: 'offline' }, 'md')}
        <div class="c-main"><div class="c-name">${fmt(c.name)}</div><div class="c-psm">${esc(c.email)}</div></div>
        <div class="req-acts"><button class="yes" data-acc="1">Aceitar</button><button class="no" data-acc="0">Recusar</button></div></div>`;
    }
  }
  for (const [g, items] of groups) {
    if (!items.length) continue;
    const closed = S.closedGroups.has(g) && !q;
    const on = items.filter(c => c.status !== 'offline').length;
    html += `<button class="group ${closed ? 'closed' : ''}" data-g="${g}"><span class="arrow">▾</span>${g} (${g === 'Offline' || g === 'Aguardando resposta' ? items.length : `${on}/${items.length}`})</button>`;
    if (closed) continue;
    for (const c of items.sort(by)) {
      if (c.state === 'out') {
        html += `<div class="contact waiting offline" data-id="${esc(c.id)}">${avatarHTML({ ...c, status: 'offline' }, 'md')}
          <div class="c-main"><div class="c-name">${fmt(c.name)}</div><div class="c-psm">convite enviado para ${esc(c.email)}</div></div></div>`;
        continue;
      }
      html += `<div class="contact ${c.id === S.active ? 'active' : ''} ${c.status === 'offline' ? 'offline' : ''}" data-id="${esc(c.id)}">
        ${avatarHTML(c, 'md')}
        <div class="c-main"><div class="c-name">${c.blocked ? icon('ban', 'inl') : ''}${fmt(c.name)}</div>
        <div class="c-psm">${c.psm ? fmt(c.psm) : esc(c.status === 'offline' ? ago(c.seen_at) : STATUS[c.status])}</div></div>
        ${c.unread ? `<span class="badge">${c.unread}</span>` : ''}</div>`;
    }
  }
  if (!all.length) {
    html = S.mode === 'cloud'
      ? `<div class="hint">${icon('userPlus', 'big')}<br>Sua lista está vazia.<br>Clique em <b>Adicionar contato</b> e digite o e-mail de um amigo.</div>`
      : `<div class="hint">${icon('search', 'big')}<br>Procurando pessoas na rede…<br>Abra o AURA MSN em outro computador da mesma rede, ou use “Adicionar por endereço”.</div>`;
  } else if (!list.length) {
    html = `<div class="hint">Nenhum contato com “${esc(S.filter)}”.</div>`;
  }
  html += '<div id="results"></div>';
  $('#contacts').innerHTML = html;
  if (S.lastResults) renderResults(S.lastResults);
  updateTitle();
}
function renderResults(res) {
  const el = $('#results');
  if (!el) return;
  if (!res.length || S.filter.length < 2) { el.innerHTML = ''; return; }
  el.innerHTML = `<div class="group" style="cursor:default">Mensagens (${res.length})</div>` + res.map(r => {
    const c = S.contacts.get(r.peer);
    return `<div class="result" data-peer="${esc(r.peer)}" data-mid="${esc(r.id)}"><b>${esc(r.dir === 'out' ? 'Você → ' : '')}${esc(c?.name || 'Contato')}</b>
      <span class="muted" style="font-size:11px"> · ${new Date(r.ts * 1000).toLocaleDateString('pt-BR')}</span>
      <div class="snip">${highlight(esc(emo(r.text)), S.filter)}</div></div>`;
  }).join('');
}
let searchTimer;
function bindContacts() {
  $('#contacts').addEventListener('click', e => {
    const g = e.target.closest('.group[data-g]');
    if (g) {
      const k = g.dataset.g;
      S.closedGroups.has(k) ? S.closedGroups.delete(k) : S.closedGroups.add(k);
      safeSet('closedGroups', JSON.stringify([...S.closedGroups]));
      return renderContacts();
    }
    const acc = e.target.closest('[data-acc]');
    if (acc) {
      const id = acc.closest('[data-req]').dataset.req;
      acc.disabled = true;
      return api('/api/contacts/answer', { peer: id, accept: acc.dataset.acc === '1' })
        .then(() => { if (acc.dataset.acc === '1') toast('Contato adicionado', S.contacts.get(id)?.name || '', { icon: icon('sparkle') }); })
        .catch(fail);
    }
    if (e.target.closest('.contact.request')) return;
    const w = e.target.closest('.contact.waiting');
    if (w) return contactMenu({ clientX: e.clientX, clientY: e.clientY }, w.dataset.id);
    const r = e.target.closest('.result');
    if (r) return openChat(r.dataset.peer, r.dataset.mid);
    const c = e.target.closest('.contact');
    if (c) openChat(c.dataset.id);
  });
  $('#contacts').addEventListener('contextmenu', e => {
    const c = e.target.closest('.contact');
    if (!c) return;
    e.preventDefault();
    contactMenu({ clientX: e.clientX, clientY: e.clientY }, c.dataset.id);
  });
  $('#search').addEventListener('input', e => {
    S.filter = e.target.value.trim();
    S.lastResults = null;
    renderContacts();
    clearTimeout(searchTimer);
    if (S.filter.length >= 2) searchTimer = setTimeout(async () => {
      try { S.lastResults = (await api('/api/search?q=' + encodeURIComponent(S.filter))).results; renderResults(S.lastResults); } catch { /* ignora */ }
    }, 250);
  });
  $('#addBtn').onclick = addContactDialog;
}

/* ---------------------------------------------------------------- conversa */
async function openChat(id, focusMid) {
  if (!S.contacts.has(id) || (S.contacts.get(id).state || 'ok') !== 'ok') return;
  S.active = id;
  S.convFilter = '';
  $('#convSearch').value = '';
  $('#convSearch').classList.add('hidden');
  $('#app').classList.add('in-chat');
  $('#empty').classList.add('hidden');
  $('#conv').classList.remove('hidden');
  $('#emojiPanel').classList.add('hidden');
  $('#typing').innerHTML = '';
  renderHead();
  renderContacts();
  if (!S.hist.has(id)) {
    $('#msgs').innerHTML = '<div class="hint">Carregando…</div>';
    try { S.hist.set(id, (await api('/api/history?peer=' + encodeURIComponent(id))).messages); } catch (e) { return fail(e); }
    if (S.active !== id) return;
  }
  renderMsgs();
  markRead(id);
  if (focusMid) {
    const el = document.getElementById('m-' + focusMid);
    if (el) { el.scrollIntoView({ block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1800); }
  }
  $('#input').focus();
}
// botão "voltar" do Android: fecha janelas e conversa antes de sair do app
window.auraBack = () => {
  if (!$('#modal').classList.contains('hidden')) { closeModal(); return true; }
  if (!$('#menu').classList.contains('hidden')) { hideMenu(); return true; }
  if (!$('#emojiPanel').classList.contains('hidden')) { $('#emojiPanel').classList.add('hidden'); return true; }
  if (S.active && matchMedia('(max-width: 760px)').matches) { closeChat(); return true; }
  return false;
};
function closeChat() {
  S.active = null;
  $('#app').classList.remove('in-chat');
  $('#conv').classList.add('hidden');
  $('#empty').classList.remove('hidden');
  renderContacts();
}
function renderHead() {
  const c = S.contacts.get(S.active);
  if (!c) return;
  $('#headAvatar').innerHTML = avatarHTML(c, 'md');
  $('#headName').innerHTML = (c.blocked ? icon('ban', 'inl') : '') + fmt(c.name);
  const st = c.status === 'offline' ? ago(c.seen_at) : STATUS[c.status];
  $('#headSub').innerHTML = esc(st) + (c.psm ? ' · ' + fmt(c.psm) : '');
  $('#favBtn').innerHTML = icon('star', c.favorite ? 'fill' : '');
  $('#favBtn').classList.toggle('on', c.favorite);
}
function tick(state, m) {
  if (state === 'failed' && m?.error) return `<span class="tick failed" title="${esc(m.error)}">${icon('alert')} não enviada</span>`;
  return {
    sending: `<span class="tick" title="Enviando">${icon('clock')}</span>`,
    sent: `<span class="tick" title="Entregue">${icon('check')}</span>`,
    read: `<span class="tick read" title="Lida">${icon('checks')}</span>`,
    pending: `<span class="tick pending" title="${S.mode === 'cloud' ? 'Será enviada quando a internet voltar' : 'Será entregue quando o contato ficar online'}">${icon('hourglass')} na fila</span>`,
    failed: `<span class="tick failed" title="Não foi possível entregar">${icon('alert')} falhou</span>`,
  }[state] || '';
}
function msgHTML(m, prev) {
  const c = S.contacts.get(m.peer);
  const name = esc(c?.name || 'Contato');
  if (m.kind === 'nudge') {
    return `<div class="sys" id="m-${m.id}">${icon('nudge')} ${m.dir === 'out' ? `Você chamou a atenção de ${name}` : `${name} chamou sua atenção!`}${m.state === 'failed' ? ' (não entregue)' : ''}<time>${hhmm(m.ts)}</time></div>`;
  }
  let body;
  if (m.kind === 'file') {
    const f = m.file, url = CORE ? (f.url || '') : `/api/download?peer=${encodeURIComponent(m.peer)}&mid=${m.id}&t=${encodeURIComponent(TOKEN)}`;
    const isImg = /^image\/(png|jpe?g|gif|webp|bmp|svg\+xml)$/.test(f.mime) && url;
    const img = !isImg ? '' : CORE ? `<img class="thumb" data-view="${esc(url)}" src="${esc(url)}" loading="lazy" alt="">`
      : `<a href="${url}" target="_blank"><img class="thumb" src="${url}" loading="lazy" alt=""></a>`;
    const acts = CORE ? `${isImg ? `<button data-view="${esc(url)}">Ver</button>` : ''}<button data-reveal="${m.id}">Salvar no aparelho</button>`
      : `<a href="${url}" target="_blank">Abrir</a><button data-reveal="${m.id}">Mostrar na pasta</button>`;
    body = `${img}<div class="file"><div class="ico">${fileIcon(f.mime, f.name)}</div><div><div class="fname">${esc(f.name)}</div>
      <div class="fsize">${fsize(f.size)}</div><div class="acts">${acts}</div></div></div>`;
  } else {
    const jumbo = isJumbo(emo(m.text));
    body = `<div class="text ${jumbo ? 'jumbo' : ''}">${fmt(m.text, S.convFilter)}</div>`;
  }
  const reacts = Object.values(m.reactions || {});
  const same = prev && prev.dir === m.dir && prev.kind !== 'nudge' && m.ts - prev.ts < 120;
  return `<div class="msg ${m.dir} ${same ? 'same' : ''} ${reacts.length ? 'has-react' : ''}" id="m-${m.id}" data-id="${m.id}">
    <div class="bubble">${body}<div class="meta"><time>${hhmm(m.ts)}</time>${m.dir === 'out' ? tick(m.state, m) : ''}</div>
    ${reacts.length ? `<div class="reacts">${reacts.join('')}</div>` : ''}</div>
    ${m.kind !== 'nudge' ? `<button class="react-btn" title="Reagir">${icon('smilePlus')}</button>` : ''}</div>`;
}
function renderMsgs() {
  const list = S.hist.get(S.active) || [];
  const q = S.convFilter.toLowerCase();
  const shown = q ? list.filter(m => (m.text || m.file?.name || '').toLowerCase().includes(q)) : list;
  let html = '', lastDay = '', prev = null;
  for (const m of shown) {
    const d = dayLabel(m.ts);
    if (d !== lastDay) { html += `<div class="day">${esc(d)}</div>`; lastDay = d; prev = null; }
    html += msgHTML(m, prev);
    prev = m;
  }
  if (!shown.length) {
    const c = S.contacts.get(S.active);
    html = q ? '<div class="hint">Nada encontrado nesta conversa.</div>'
      : `<div class="hint">${icon('chat', 'big')}<br>Diga oi para ${fmt(c?.name)}!<br><span style="font-size:12px">Dica: :) ;) (y) &lt;3 viram emojis, *negrito*, _itálico_ e ~riscado~ também funcionam.</span></div>`;
  }
  const box = $('#msgs');
  box.style.scrollBehavior = 'auto';
  box.innerHTML = html;
  box.scrollTop = box.scrollHeight;
  box.style.scrollBehavior = '';
}
function addMsg(m) {
  if (!S.hist.has(m.peer)) return;
  const list = S.hist.get(m.peer);
  if (list.some(x => x.id === m.id)) return;
  list.push(m);
  if (m.peer === S.active && !S.convFilter) {
    const box = $('#msgs');
    const near = box.scrollHeight - box.scrollTop - box.clientHeight < 160 || m.dir === 'out';
    if (list.length === 1) return renderMsgs();
    const prev = list[list.length - 2];
    if (dayLabel(prev.ts) !== dayLabel(m.ts)) box.insertAdjacentHTML('beforeend', `<div class="day">${esc(dayLabel(m.ts))}</div>`);
    box.insertAdjacentHTML('beforeend', msgHTML(m, prev));
    if (near) box.scrollTop = box.scrollHeight;
  } else if (m.peer === S.active) renderMsgs();
}
function updateMsg(m) {
  const list = S.hist.get(m.peer);
  if (!list) return;
  const i = list.findIndex(x => x.id === m.id);
  if (i < 0) return;
  list[i] = m;
  const el = document.getElementById('m-' + m.id);
  if (el && m.peer === S.active) el.outerHTML = msgHTML(m, list[i - 1]);
}
async function markRead(id) {
  const c = S.contacts.get(id);
  if (!c || document.hidden) return;
  if (c.unread || (S.hist.get(id) || []).some(m => m.dir === 'in' && m.state === 'received')) {
    c.unread = 0; renderContacts();
    api('/api/read', { peer: id }).catch(() => {});
  }
}

function sendText() {
  const el = $('#input'), text = el.value.trim();
  if (!text || !S.active) return;
  el.value = ''; autoGrow();
  api('/api/send', { peer: S.active, text }).then(m => { addMsg(m); tone(SND.sent); }).catch(fail);
}
let lastNudge = 0;
function sendNudge() {
  if (!S.active) return;
  if (Date.now() - lastNudge < 6000) return toast('Calma!', 'Espere alguns segundos para chamar a atenção de novo.');
  lastNudge = Date.now();
  api('/api/nudge', { peer: S.active }).then(addMsg).catch(fail);
  shake();
}
async function sendFiles(files) {
  const peer = S.active;
  for (const f of files) {
    if (f.size > 25 * 1024 * 1024) { toast('Arquivo grande demais', `${f.name} passa de 25 MB`, { err: true }); continue; }
    const data = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(f); });
    api('/api/file', { peer, name: f.name || 'imagem.png', data }).then(addMsg).catch(fail);
  }
}
function autoGrow() { const el = $('#input'); el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 160) + 'px'; }

function shake() {
  const app = $('#app');
  app.classList.remove('shake'); void app.offsetWidth; app.classList.add('shake');
  setTimeout(() => { app.classList.remove('shake'); repaint(); }, 700);
}
// força a janela a se redesenhar por inteiro (evita "pedaços" presos na tela)
function repaint() {
  const app = $('#app');
  app.style.visibility = 'hidden'; void app.offsetHeight; app.style.visibility = '';
}
window.addEventListener('focus', () => setTimeout(repaint, 50));
document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(repaint, 50); });

function showTyping(id) {
  if (id !== S.active) return;
  const c = S.contacts.get(id);
  $('#typing').innerHTML = `${fmt(c?.name)} está digitando <span class="dots"><i></i><i></i><i></i></span>`;
  clearTimeout(S.typingTimer);
  S.typingTimer = setTimeout(() => { $('#typing').innerHTML = ''; }, 5000);
}

function bindConv() {
  const input = $('#input');
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendText(); }
  });
  input.addEventListener('input', () => {
    autoGrow();
    if (S.active && input.value && Date.now() - S.lastTypingSent > 3000) {
      S.lastTypingSent = Date.now();
      api('/api/typing', { peer: S.active }).catch(() => {});
    }
  });
  input.addEventListener('paste', e => {
    const files = [...(e.clipboardData?.files || [])];
    if (files.length) { e.preventDefault(); sendFiles(files); }
  });
  $('#sendBtn').onclick = sendText;
  $('#nudgeBtn').onclick = sendNudge;
  $('#fileBtn').onclick = () => $('#sendFile').click();
  $('#sendFile').onchange = e => { sendFiles([...e.target.files]); e.target.value = ''; };
  $('#favBtn').onclick = () => { const c = S.contacts.get(S.active); if (c) updateContact(c.id, { favorite: !c.favorite }); };
  $('#moreBtn').onclick = e => contactMenu(e.currentTarget, S.active);
  $('#findBtn').onclick = () => {
    const s = $('#convSearch'); s.classList.toggle('hidden');
    if (!s.classList.contains('hidden')) s.focus(); else { s.value = ''; S.convFilter = ''; renderMsgs(); }
  };
  $('#convSearch').addEventListener('input', e => { S.convFilter = e.target.value.trim(); renderMsgs(); });
  $('#headAvatar').onclick = () => { if (matchMedia('(max-width: 760px)').matches) closeChat(); };
  $('#backBtn').onclick = closeChat;

  // emojis
  const panel = $('#emojiPanel');
  panel.innerHTML = Object.entries(EMOJI_SETS).map(([sec, list]) => `<div class="sec">${sec}</div>` + list.map(e => `<button>${e}</button>`).join('')).join('');
  $('#emojiBtn').onclick = e => { e.stopPropagation(); panel.classList.toggle('hidden'); };
  panel.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    e.stopPropagation();
    const i = input.selectionStart ?? input.value.length;
    input.value = input.value.slice(0, i) + b.textContent + input.value.slice(input.selectionEnd ?? i);
    input.focus(); input.selectionStart = input.selectionEnd = i + b.textContent.length;
  });
  document.addEventListener('click', e => { if (!panel.contains(e.target)) panel.classList.add('hidden'); });

  // mensagens: reações e "mostrar na pasta"
  $('#msgs').addEventListener('click', e => {
    const vw = e.target.closest('[data-view]');
    if (vw) return modal(`<img class="viewer" src="${esc(vw.dataset.view)}" alt=""><div class="actions"><button class="btn primary" data-x>Fechar</button></div>`,
      el => { el.querySelector('[data-x]').onclick = closeModal; });
    const rv = e.target.closest('[data-reveal]');
    if (rv) return api('/api/reveal', { peer: S.active, mid: rv.dataset.reveal }).catch(fail);
    const rb = e.target.closest('.react-btn');
    if (rb) {
      const mid = rb.closest('.msg').dataset.id;
      const m = S.hist.get(S.active)?.find(x => x.id === mid);
      const mine = m?.reactions?.me;
      showMenu(rb, ['👍', '❤️', '😂', '😮', '😢', '🔥', '🎉'].map(em => ({
        html: em, run: () => api('/api/react', { peer: S.active, mid, emoji: em === mine ? '' : em }).catch(fail),
      })), 'reactions');
    }
  });

  // arrastar e soltar
  const conv = $('#conv');
  let depth = 0;
  conv.addEventListener('dragenter', e => { if (e.dataTransfer?.types.includes('Files')) { depth++; conv.classList.add('dragging'); } });
  conv.addEventListener('dragleave', () => { if (--depth <= 0) { depth = 0; conv.classList.remove('dragging'); } });
  conv.addEventListener('dragover', e => e.preventDefault());
  conv.addEventListener('drop', e => { e.preventDefault(); depth = 0; conv.classList.remove('dragging'); if (e.dataTransfer.files.length) sendFiles([...e.dataTransfer.files]); });
}

/* ------------------------------------------------------------ menus */
function showMenu(anchor, items, cls = '') {
  const menu = $('#menu');
  menu.className = 'menu ' + cls;
  menu.innerHTML = items.map((it, i) => it === '-' ? '<hr>' : `<button data-i="${i}" class="${it.danger ? 'danger' : ''}">${it.html}</button>`).join('');
  menu.onclick = e => { const b = e.target.closest('button'); if (!b) return; hideMenu(); items[+b.dataset.i].run(); };
  menu.classList.remove('hidden');
  let x, y;
  if (anchor.getBoundingClientRect) { const r = anchor.getBoundingClientRect(); x = r.left; y = r.bottom + 4; } else { x = anchor.clientX; y = anchor.clientY; }
  const mw = menu.offsetWidth, mh = menu.offsetHeight;
  menu.style.left = Math.max(8, Math.min(x, innerWidth - mw - 8)) + 'px';
  menu.style.top = (y + mh > innerHeight - 8 ? Math.max(8, y - mh - 40) : y) + 'px';
  setTimeout(() => document.addEventListener('click', hideMenu, { once: true }), 0);
}
function hideMenu() { $('#menu').classList.add('hidden'); }

function contactMenu(anchor, id) {
  const c = S.contacts.get(id);
  if (!c) return;
  const removeItem = { html: mi('userX', 'Remover contato…'), danger: true, run: () => confirmDialog('Remover contato?', `${c.name} sai da sua lista. O histórico fica neste computador.`, 'Remover', async () => {
    await api('/api/contacts/remove', { peer: id }); if (S.active === id) closeChat();
  }) };
  if (c.state === 'out') return showMenu(anchor, [{ html: mi('undo', 'Cancelar convite'), danger: true, run: () => api('/api/contacts/remove', { peer: id }).catch(fail) }]);
  showMenu(anchor, [
    { html: mi('chat', 'Abrir conversa'), run: () => openChat(id) },
    { html: mi('pencil', 'Renomear contato…'), run: () => renameDialog(c) },
    { html: mi('star', c.favorite ? 'Tirar dos favoritos' : 'Favoritar'), run: () => updateContact(id, { favorite: !c.favorite }) },
    { html: mi('info', 'Informações'), run: () => infoDialog(c) },
    '-',
    { html: mi('eyeOff', 'Ocultar da lista'), run: () => { updateContact(id, { hidden: true }); if (S.active === id) closeChat(); } },
    { html: c.blocked ? mi('checkCircle', 'Desbloquear') : mi('ban', 'Bloquear'), danger: !c.blocked, run: () => updateContact(id, { blocked: !c.blocked }) },
    { html: mi('eraser', 'Apagar histórico…'), danger: true, run: () => confirmDialog('Apagar histórico?', `Todas as mensagens com ${c.name} serão apagadas deste computador.`, 'Apagar', async () => {
      await api('/api/history/clear', { peer: id }); S.hist.set(id, []); if (S.active === id) renderMsgs();
    }) },
    ...(S.mode === 'cloud' ? [removeItem] : []),
  ]);
}
async function updateContact(id, patch) {
  try { const v = await api('/api/contacts/update', { peer: id, ...patch }); S.contacts.set(v.id, v); renderContacts(); if (S.active === v.id) renderHead(); } catch (e) { fail(e); }
}

/* ------------------------------------------------------------ diálogos */
function modal(html, onReady) {
  $('#modalCard').innerHTML = html;
  $('#modal').classList.remove('hidden');
  onReady?.($('#modalCard'));
}
function closeModal() { $('#modal').classList.add('hidden'); $('#modalCard').innerHTML = ''; }
$('#modal').addEventListener('mousedown', e => { if (e.target.id === 'modal') closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); hideMenu(); } });

function confirmDialog(title, text, okLabel, action) {
  modal(`<h2>${esc(title)}</h2><p>${esc(text)}</p><div class="actions"><button class="btn" data-x>Cancelar</button><button class="btn primary" data-ok>${esc(okLabel)}</button></div>`, el => {
    el.querySelector('[data-x]').onclick = closeModal;
    el.querySelector('[data-ok]').onclick = async () => { closeModal(); try { await action(); } catch (e) { fail(e); } };
  });
}
function renameDialog(c) {
  modal(`<h2>Renomear contato</h2><p class="muted">Só você vê esse apelido. Nome original: <b>${esc(c.realname)}</b></p>
    <input class="field" id="aliasIn" maxlength="80" value="${esc(c.alias)}" placeholder="${esc(c.realname)}">
    <div class="actions"><button class="btn" data-x>Cancelar</button><button class="btn primary" data-ok>Salvar</button></div>`, el => {
    const inp = el.querySelector('#aliasIn'); inp.focus(); inp.select();
    const ok = () => { updateContact(c.id, { alias: inp.value }); closeModal(); };
    el.querySelector('[data-ok]').onclick = ok;
    inp.onkeydown = e => { if (e.key === 'Enter') ok(); };
    el.querySelector('[data-x]').onclick = closeModal;
  });
}
function infoDialog(c) {
  modal(`<div style="display:flex;gap:16px;align-items:center">${avatarHTML(c, 'lg')}<div><h2 style="margin:0">${fmt(c.name)}</h2>
    <div class="muted">${esc(c.status === 'offline' ? ago(c.seen_at) : STATUS[c.status])}</div></div></div>
    ${c.psm ? `<p>${fmt(c.psm)}</p>` : ''}
    <h3>Detalhes</h3>
    <div class="row"><span>Nome escolhido por ele(a)</span><b>${esc(c.realname)}</b></div>
    ${S.mode === 'cloud'
      ? `<div class="row"><span>E-mail</span><code class="addr">${esc(c.email)}</code></div>`
      : `<div class="row"><span>Endereço na rede</span><code class="addr">${esc(c.addr)}</code></div>
    <div class="row"><span>Adicionado</span><span>${c.manual ? 'por endereço' : 'descoberto na rede local'}</span></div>`}
    <div class="actions"><button class="btn primary" data-x>Fechar</button></div>`, el => { el.querySelector('[data-x]').onclick = closeModal; });
}
function addContactDialog() {
  if (S.mode === 'cloud') return addByEmailDialog();
  modal(`<h2>Adicionar por endereço</h2>
    <p class="muted">No modo rede local os computadores da mesma rede aparecem sozinhos. Use isto se alguém não apareceu.</p>
    <input class="field" id="addrIn" placeholder="ex.: 192.168.0.20:47101">
    <p class="muted" style="font-size:12.5px">Seu endereço para passar aos outros: ${S.addresses.map(a => `<code class="addr">${esc(a)}</code>`).join(' ')}</p>
    <div class="actions"><button class="btn" data-x>Cancelar</button><button class="btn primary" data-ok>Adicionar</button></div>`, el => {
    const inp = el.querySelector('#addrIn'); inp.focus();
    const ok = async () => {
      const b = el.querySelector('[data-ok]'); b.disabled = true; b.textContent = 'Conectando…';
      try {
        const v = await api('/api/contacts/add', { address: inp.value });
        S.contacts.set(v.id, v); renderContacts(); closeModal(); toast('Contato adicionado', v.name, { icon: icon('sparkle') }); openChat(v.id);
      } catch (e) { fail(e); b.disabled = false; b.textContent = 'Adicionar'; }
    };
    el.querySelector('[data-ok]').onclick = ok;
    inp.onkeydown = e => { if (e.key === 'Enter') ok(); };
    el.querySelector('[data-x]').onclick = closeModal;
  });
}
function addByEmailDialog() {
  modal(`<h2>Adicionar contato</h2>
    <p class="muted">Digite o e-mail que seu amigo usa no AURA MSN. Ele recebe um pedido e, quando aceitar, aparece na sua lista.</p>
    <input class="field" id="addrIn" type="email" placeholder="amigo@gmail.com">
    <div id="addMsg"></div>
    <div class="actions"><button class="btn" data-x>Cancelar</button><button class="btn primary" data-ok>Adicionar</button></div>`, el => {
    const inp = el.querySelector('#addrIn'); inp.focus();
    const ok = async () => {
      const b = el.querySelector('[data-ok]'); b.disabled = true; b.textContent = 'Procurando…';
      try {
        const v = await api('/api/contacts/add', { email: inp.value });
        if (v.not_found) {
          el.querySelector('#addMsg').innerHTML = `<p class="muted"><b>${esc(v.email)}</b> ainda não tem conta no AURA MSN.</p>
            <button class="btn with-ic" id="inviteBtn">${icon('mail')} Mandar um convite por e-mail</button>`;
          el.querySelector('#inviteBtn').onclick = async ev => {
            ev.target.disabled = true;
            try { await api('/api/contacts/invite', { email: v.email }); closeModal(); toast('Convite enviado', v.email, { icon: icon('mail') }); } catch (e) { fail(e); ev.target.disabled = false; }
          };
          b.disabled = false; b.textContent = 'Adicionar';
          return;
        }
        if (v.id) S.contacts.set(v.id, v);
        renderContacts(); closeModal();
        if (v.state === 'ok') { toast('Contato adicionado', v.name, { icon: icon('sparkle') }); openChat(v.id); } else toast('Pedido enviado', `${v.name || v.email} vai aparecer na sua lista quando aceitar.`, { icon: icon('inbox') });
      } catch (e) { fail(e); b.disabled = false; b.textContent = 'Adicionar'; }
    };
    el.querySelector('[data-ok]').onclick = ok;
    inp.onkeydown = e => { if (e.key === 'Enter') ok(); };
    el.querySelector('[data-x]').onclick = closeModal;
  });
}
function settingsDialog() {
  const me = S.me;
  const colors = ['#3b82f6', '#8b5cf6', '#14b8a6', '#22c55e', '#f97316', '#ec4899', '#ef4444', '#64748b'];
  const sw = (id, on) => `<label class="switch"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}><span></span></label>`;
  modal(`<h2>Configurações</h2>
    <h3>Aparência</h3>
    <div class="row"><span>Tema</span><select id="themeSel">
      <option value="auto">Automático (do sistema)</option><option value="light">Claro</option><option value="dark">Escuro</option></select></div>
    <div class="row"><span>Cor de destaque</span><div class="swatches">${colors.map(c => `<button data-c="${c}" class="${c === me.accent ? 'sel' : ''}" style="background:${c}" title="${c}"></button>`).join('')}</div></div>
    <h3>Alertas</h3>
    <div class="row"><span>Sons</span>${sw('sndSw', me.sounds)}</div>
    <div class="row"><span>Notificações na área de trabalho</span>${sw('ntfSw', me.notify)}</div>
    ${S.mode === 'cloud' ? `<h3>Conta</h3>
    <div class="row"><span>E-mail</span><code class="addr">${esc(S.account?.email || '')}</code></div>
    <div class="row"><span>Servidor</span><span class="muted">${esc(S.account?.server || '')} <i class="dot ${S.connected ? 'online' : 'busy'}"></i></span></div>
    <div class="row"><span>Sair desta conta neste computador</span><button class="btn with-ic" id="logoutBtn">${icon('logout')} Sair da conta</button></div>
    ${CORE ? '' : '<h3>Arquivos</h3>'}` : `<h3>Rede local</h3>
    <div class="row"><span>Seu endereço</span><span>${S.addresses.map(a => `<code class="addr">${esc(a)}</code>`).join(' ')}</span></div>
    <div class="row"><span>Conversar pela internet</span><button class="btn primary with-ic" id="logoutBtn">${icon('login')} Entrar com uma conta</button></div>`}
    ${CORE ? '' : `<div class="row"><span>Arquivos recebidos</span><button class="btn with-ic" id="openDl">${icon('folder')} Abrir pasta</button></div>
    <p class="muted" style="font-size:12px;margin:2px 0 0">${esc(S.downloads)}</p>`}
    <h3>Sobre</h3>
    <p style="margin:0">AURA MSN <b>${esc(S.version)}</b> — mensageiro instantâneo AURA MSN.
      Inspirado nos mensageiros clássicos dos anos 2000, refeito para o Windows 10/11, o Linux e o celular.</p>
    <div class="actions">${CORE ? '' : `<button class="btn danger with-ic" id="quitBtn">${icon('power')} Fechar o AURA</button>`}<button class="btn primary" data-x>Fechar</button></div>`, el => {
    const sel = el.querySelector('#themeSel'); sel.value = me.theme;
    sel.onchange = () => saveProfile({ theme: sel.value });
    el.querySelectorAll('.swatches button').forEach(b => b.onclick = () => {
      el.querySelectorAll('.swatches button').forEach(x => x.classList.remove('sel')); b.classList.add('sel'); saveProfile({ accent: b.dataset.c });
    });
    el.querySelector('#sndSw').onchange = e => { saveProfile({ sounds: e.target.checked }); if (e.target.checked) setTimeout(() => tone(SND.msg), 200); };
    el.querySelector('#ntfSw').onchange = async e => {
      if (e.target.checked && 'Notification' in window && Notification.permission === 'default') await Notification.requestPermission();
      saveProfile({ notify: e.target.checked });
    };
    el.querySelector('#openDl')?.addEventListener('click', () => api('/api/openfolder', {}).catch(fail));
    el.querySelector('#quitBtn')?.addEventListener('click', quit);
    el.querySelector('#logoutBtn').onclick = () => S.mode === 'cloud'
      ? confirmDialog('Sair da conta?', 'Você deixa de receber mensagens neste computador até entrar de novo. O histórico continua salvo aqui.', 'Sair', () => api('/api/auth/logout', {}))
      : api('/api/auth/logout', {}).catch(fail);
    el.querySelector('[data-x]').onclick = closeModal;
  });
}
async function quit() {
  closeModal();
  try { await api('/api/quit', {}); } catch { /* ok */ }
  showOffline();
  setTimeout(() => window.close(), 400);
}
function showOffline() { $('#offline').classList.remove('hidden'); }

/* ---------------------------------------------------------------- eventos */
function connect() {
  const es = CORE ? CORE.events() : new EventSource('/api/events?t=' + encodeURIComponent(TOKEN));
  let failures = 0, wasDown = false;
  es.addEventListener('hello', async () => {
    failures = 0; wasDown = false;
    try { await loadState(); } catch { /* tenta de novo no próximo hello */ }  // pega o estado já com os eventos ligados
  });
  es.addEventListener('contact', e => {
    const c = JSON.parse(e.data);
    S.contacts.set(c.id, c);
    renderContacts();
    if (S.active === c.id) renderHead();
  });
  es.addEventListener('signin', e => {
    const { id } = JSON.parse(e.data);
    const c = S.contacts.get(id);
    if (!c || c.blocked || c.hidden || Date.now() - S.started < 8000 || S.me.status === 'busy') return;
    tone(SND.signin);
    toast(c.name, 'acabou de ficar online', { icon: avatarHTML(c, 'sm'), onClick: () => openChat(id) });
    notify(c.name, 'acabou de ficar online', id);
  });
  es.addEventListener('auth', e => {
    const d = JSON.parse(e.data);
    if (d.ok) onLoggedIn(); else showLogin(d.msg);
  });
  es.addEventListener('autherr', e => { if (L.view === 'google') loginView('login', { err: JSON.parse(e.data).msg }); });
  es.addEventListener('net', e => {
    const d = JSON.parse(e.data);
    S.connected = d.ok;
    $('#netBar').classList.toggle('hidden', d.ok || !S.loggedIn);
    renderNet();
  });
  es.addEventListener('remove', e => {
    const { id } = JSON.parse(e.data);
    S.contacts.delete(id);
    if (S.active === id) closeChat(); else renderContacts();
  });
  es.addEventListener('request', e => {
    const c = JSON.parse(e.data);
    if (Date.now() - S.started < 4000) return;
    tone(SND.signin);
    toast(c.name, 'quer te adicionar como contato', { icon: icon('inbox') });
    notify(c.name, 'quer te adicionar como contato no AURA MSN');
  });
  es.addEventListener('message', e => {
    const m = JSON.parse(e.data);
    addMsg(m);
    if (m.dir !== 'in' || m.quiet) return;
    const c = S.contacts.get(m.peer);
    const visible = m.peer === S.active && !document.hidden;
    if (visible) markRead(m.peer);
    if (m.kind === 'nudge') return;
    const preview = m.kind === 'file' ? `Arquivo: ${m.file.name}` : emo(m.text);
    if (S.me.status !== 'busy') tone(SND.msg);
    if (!visible) {
      if (!document.hidden) toast(c?.name || 'Nova mensagem', preview.slice(0, 120), { icon: c ? avatarHTML(c, 'sm') : icon('chat'), onClick: () => openChat(m.peer) });
      notify(c?.name || 'Nova mensagem', preview.slice(0, 180), m.peer);
    }
    if (m.peer === S.active) $('#typing').innerHTML = '';
  });
  es.addEventListener('update', e => updateMsg(JSON.parse(e.data)));
  es.addEventListener('saved', e => toast('Arquivo salvo', 'Em Downloads/AURA MSN: ' + JSON.parse(e.data).name, { icon: icon('check') }));
  es.addEventListener('typing', e => showTyping(JSON.parse(e.data).id));
  es.addEventListener('nudge', e => {
    const { id } = JSON.parse(e.data);
    const c = S.contacts.get(id);
    if (S.me.status === 'busy') return;
    tone(SND.nudge); shake();
    notify(c?.name || 'AURA', 'chamou sua atenção!', id);
    if (S.active !== id) toast(c?.name || 'Alguém', 'chamou sua atenção!', { icon: icon('nudge'), onClick: () => openChat(id) });
  });
  es.addEventListener('me', e => { S.me = JSON.parse(e.data); renderMe(); });
  es.addEventListener('bye', () => { es.close(); showOffline(); });
  es.onerror = () => {
    wasDown = true;
    if (++failures > 6) { es.close(); showOffline(); }
  };
}

function renderNet() {
  $('#netInfo').innerHTML = S.mode === 'cloud'
    ? (S.connected ? `<i class="dot online"></i> ${esc(S.account?.email || '')}` : '<i class="dot busy"></i> Sem conexão com o servidor')
    : `Rede local · você está em <code class="addr">${esc(S.addresses[0] || '')}</code>`;
}
async function loadState() {
  const st = await api('/api/state');
  S.version = st.version;
  if (st.login) { if (!S.loggedIn && !$('#login').classList.contains('hidden')) return; return showLogin(); }
  S.loggedIn = true;
  S.me = st.me; S.addresses = st.addresses || []; S.downloads = st.downloads;
  S.mode = st.mode; S.account = st.account; S.connected = st.mode !== 'cloud' || st.connected !== false;
  S.contacts = new Map(st.contacts.map(c => [c.id, c]));
  $('#addBtn').innerHTML = icon('userPlus') + `<span>${S.mode === 'cloud' ? 'Adicionar contato' : 'Adicionar por endereço'}</span>`;
  $('#emptyHint').textContent = S.mode === 'cloud'
    ? 'Adicione amigos pelo e-mail com o botão “Adicionar contato”.'
    : 'Modo rede local: quem abrir o AURA na mesma rede aparece sozinho na lista.';
  renderNet();
  hideLogin();
  renderMe();
  renderContacts();
  if (S.active) { S.hist.delete(S.active); openChat(S.active); }
}

/* ------------------------------------------------------- ausente automático */
function activity() {
  S.lastActivity = Date.now();
  if (S.loggedIn && S.autoAway && S.me?.status === 'away') { S.autoAway = false; saveProfile({ status: 'online' }); }
}
['mousemove', 'keydown', 'mousedown', 'focus'].forEach(ev => window.addEventListener(ev, activity, { passive: true }));
setInterval(() => {
  if (S.loggedIn && S.me?.status === 'online' && Date.now() - S.lastActivity > 10 * 60 * 1000) { S.autoAway = true; saveProfile({ status: 'away' }); }
  if (S.active) renderHead();
}, 30000);

/* ---------------------------------------------------------------- login */
const GOOGLE_SVG = '<svg viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.1-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>';
const L = { info: null, email: '', status: 'online', view: 'login' };

async function showLogin(msg) {
  S.loggedIn = false;
  closeModal(); hideMenu();
  $('#netBar').classList.add('hidden');
  $('#login').classList.remove('hidden');
  try { L.info = await api('/api/auth/info', {}); } catch { L.info = { configured: false }; }
  L.email = L.email || L.info.last_email || '';
  loginView('login', msg ? { err: msg } : {});
}
function hideLogin() { $('#login').classList.add('hidden'); }

function loginView(view, o = {}) {
  L.view = view;
  const info = L.info || {};
  const body = $('#loginBody');
  const err = o.err ? `<p class="err">${icon('alert')} ${esc(o.err)}</p>` : '';
  const ok = o.ok ? `<p class="ok">${icon('check')} ${esc(o.ok)}</p>` : '';
  const statusSel = `<div class="status-line">Entrar como:
      <select id="lgStatus">${['online', 'away', 'busy', 'invisible'].map(s => `<option value="${s}" ${s === L.status ? 'selected' : ''}>${STATUS[s]}</option>`).join('')}</select></div>`;
  const google = info.google ? `<div class="login-sep">ou</div><button class="btn google" id="lgGoogle">${GOOGLE_SVG} Entrar com Google</button>` : '';
  let html = '';
  if (!info.configured || (!info.reachable && view === 'login' && info.error)) {
    html = `<h2>${info.configured ? 'Servidor fora do ar' : 'Servidor não configurado'}</h2>
      <p class="muted">${info.configured
        ? `Não foi possível falar com <code class="addr">${esc(info.server)}</code>. ${esc(info.error || '')}`
        : 'O endereço do servidor AURA não está no arquivo <code class="addr">aura_config.json</code>.'}</p>
      ${info.configured ? '<button class="btn primary" id="lgRetry">Tentar de novo</button>' : ''}`;
  } else if (view === 'login') {
    html = `<h2>Entrar</h2>
      <label for="lgEmail">E-mail</label><input class="field" id="lgEmail" type="email" autocomplete="username" value="${esc(L.email)}" placeholder="voce@gmail.com">
      <label for="lgPass">Senha</label><input class="field" id="lgPass" type="password" autocomplete="current-password">
      ${statusSel}${err}${ok}
      <button class="btn primary" id="lgGo">Entrar</button>${google}
      <div class="links"><button class="link-btn" data-v="register">Criar uma conta</button><button class="link-btn" data-v="forgot">Esqueci minha senha</button></div>`;
  } else if (view === 'register') {
    html = `<h2>Criar conta</h2>
      <label for="lgName">Seu nome (como os amigos vão te ver)</label><input class="field" id="lgName" maxlength="80" placeholder="ex.: Drimah">
      <label for="lgEmail">E-mail</label><input class="field" id="lgEmail" type="email" autocomplete="username" value="${esc(L.email)}" placeholder="voce@gmail.com">
      <label for="lgPass">Senha (mínimo 8 caracteres)</label><input class="field" id="lgPass" type="password" autocomplete="new-password">
      <label for="lgPass2">Repita a senha</label><input class="field" id="lgPass2" type="password" autocomplete="new-password">
      ${err}<button class="btn primary" id="lgGo">Criar conta</button>${google.replace('Entrar com Google', 'Criar com Google')}
      <div class="links"><button class="link-btn" data-v="login">Já tenho conta</button></div>`;
  } else if (view === 'verify') {
    html = `<h2>Confirme seu e-mail</h2>
      <p class="muted">Mandamos um código de 6 dígitos para <b>${esc(L.email)}</b>. Se não aparecer em 1 minuto, olhe na caixa de spam.</p>
      <input class="field code-in" id="lgCode" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="••••••">
      ${err}${ok}<button class="btn primary" id="lgGo">Confirmar</button>
      <div class="links"><button class="link-btn" id="lgResend">Mandar outro código</button><button class="link-btn" data-v="login">Voltar</button></div>`;
  } else if (view === 'forgot') {
    html = `<h2>Esqueci minha senha</h2>
      <p class="muted">Digite o e-mail da sua conta. Vamos mandar um código para você criar uma senha nova.</p>
      <label for="lgEmail">E-mail</label><input class="field" id="lgEmail" type="email" value="${esc(L.email)}">
      ${err}<button class="btn primary" id="lgGo">Mandar código</button>
      <div class="links"><button class="link-btn" data-v="login">Voltar</button></div>`;
  } else if (view === 'reset') {
    html = `<h2>Criar senha nova</h2>
      <p class="muted">Se existir uma conta com <b>${esc(L.email)}</b>, o código chegou lá.</p>
      <label for="lgCode">Código</label><input class="field code-in" id="lgCode" inputmode="numeric" maxlength="6" placeholder="••••••">
      <label for="lgPass">Senha nova (mínimo 8 caracteres)</label><input class="field" id="lgPass" type="password" autocomplete="new-password">
      ${err}<button class="btn primary" id="lgGo">Salvar e entrar</button>
      <div class="links"><button class="link-btn" data-v="forgot">Mandar outro código</button><button class="link-btn" data-v="login">Voltar</button></div>`;
  } else if (view === 'google') {
    html = `<h2>Continue no navegador</h2><div class="spinner"></div>
      <p class="muted center">Abrimos o Google no seu navegador. Escolha sua conta lá e volte para cá — o AURA entra sozinho.</p>
      ${err}<div class="links"><button class="link-btn" id="lgReopen">Abrir de novo</button><button class="link-btn" data-v="login">Cancelar</button></div>`;
  }
  body.innerHTML = html;
  $('#loginFoot').innerHTML = CORE ? `AURA MSN ${esc(S.version || CORE.version)}`
    : `<button class="link-btn" id="lgLan">Usar só na rede local, sem conta</button> · AURA MSN ${esc(S.version)}`;
  if ($('#lgLan')) $('#lgLan').onclick = () => confirmDialog('Usar sem conta?', 'No modo rede local você só conversa com quem está na mesma rede (casa ou escritório), sem servidor. Dá para entrar numa conta depois, pelas Configurações.', 'Usar rede local', async () => {
    await api('/api/auth/lan', {});
  });

  // olhinho para mostrar/esconder a senha
  body.querySelectorAll('input[type=password]').forEach(inp => {
    const wrap = document.createElement('div');
    wrap.className = 'pass-wrap';
    inp.replaceWith(wrap);
    wrap.append(inp);
    const eye = document.createElement('button');
    eye.type = 'button'; eye.className = 'pass-eye'; eye.title = 'Mostrar senha'; eye.tabIndex = -1;
    eye.innerHTML = icon('eye');
    eye.onclick = () => {
      const show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      eye.innerHTML = icon(show ? 'eyeOff' : 'eye');
      eye.title = show ? 'Esconder senha' : 'Mostrar senha';
      inp.focus();
    };
    wrap.append(eye);
  });
  body.querySelectorAll('[data-v]').forEach(b => b.onclick = () => { rememberEmail(); loginView(b.dataset.v); });
  const go = $('#lgGo');
  if (go) go.onclick = () => submitLogin(view);
  body.querySelectorAll('input').forEach(inp => inp.addEventListener('keydown', e => { if (e.key === 'Enter') submitLogin(view); }));
  $('#lgStatus')?.addEventListener('change', e => { L.status = e.target.value; });
  $('#lgGoogle')?.addEventListener('click', startGoogle);
  $('#lgReopen')?.addEventListener('click', startGoogle);
  $('#lgRetry')?.addEventListener('click', () => showLogin());
  $('#lgResend')?.addEventListener('click', async () => {
    try { await api('/api/auth/resend', { email: L.email }); loginView('verify', { ok: 'Código reenviado.' }); } catch (e) { loginView('verify', { err: e.message }); }
  });
  const first = body.querySelector(view === 'login' && L.email ? '#lgPass' : 'input');
  first?.focus();
}
function rememberEmail() { const e = $('#lgEmail'); if (e) L.email = e.value.trim(); }

async function submitLogin(view) {
  rememberEmail();
  const v = id => ($(id)?.value || '');
  const go = $('#lgGo');
  const busy = label => { if (go) { go.disabled = true; go.textContent = label; } };
  try {
    let r;
    if (view === 'login') {
      if (!L.email || !v('#lgPass')) return loginView('login', { err: 'Digite seu e-mail e sua senha.' });
      busy('Entrando…');
      r = await api('/api/auth/login', { email: L.email, password: v('#lgPass'), status: L.status });
    } else if (view === 'register') {
      if (v('#lgPass') !== v('#lgPass2')) return loginView('register', { err: 'As duas senhas não são iguais.' });
      busy('Criando…');
      const name = v('#lgName').trim();
      r = await api('/api/auth/register', { email: L.email, password: v('#lgPass'), name });
    } else if (view === 'verify') {
      busy('Confirmando…');
      r = await api('/api/auth/verify', { email: L.email, code: v('#lgCode'), status: L.status });
    } else if (view === 'forgot') {
      busy('Enviando…');
      await api('/api/auth/forgot', { email: L.email });
      return loginView('reset');
    } else if (view === 'reset') {
      busy('Salvando…');
      r = await api('/api/auth/reset', { email: L.email, code: v('#lgCode'), password: v('#lgPass'), status: L.status });
    }
    if (r?.need_verify) return loginView('verify');
    // logado: o evento "auth" troca de tela
  } catch (e) {
    const keep = { register: { name: v('#lgName') } };
    loginView(view, { err: e.message });
    if (view === 'register' && keep.register.name) $('#lgName').value = keep.register.name;
  }
}
async function startGoogle() {
  try { await api('/api/auth/google', {}); loginView('google'); } catch (e) { loginView('login', { err: e.message }); }
}
async function onLoggedIn() {
  hideLogin();
  S.hist.clear(); S.active = null; closeChat();
  try { await loadState(); } catch (e) { fail(e); }
}

// a janela em si nunca rola (só a lista e as mensagens)
window.addEventListener('scroll', () => { if (window.scrollY || window.scrollX) window.scrollTo(0, 0); }, { passive: true });

/* ----------------------------------------------------------------- início */
window.addEventListener('click', function firstClick() {
  if (S.me?.notify && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission();
  window.removeEventListener('click', firstClick);
});
if (CORE) document.documentElement.classList.add('is-core', CORE.android ? 'is-android' : 'is-web');
(async function init() {
  if (!TOKEN && !CORE) { document.body.innerHTML = '<p style="padding:30px">Abra o AURA MSN pelo atalho ou executando <code>aura_msn.py</code>.</p>'; return; }
  paintIcons();
  if (CORE || matchMedia('(max-width: 760px)').matches) $('#input').placeholder = 'Mensagem…';
  bindProfile(); bindContacts(); bindConv();
  $('#settingsBtn').onclick = settingsDialog;
  connect();
})();
