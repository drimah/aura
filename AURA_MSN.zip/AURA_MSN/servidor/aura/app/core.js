'use strict';
/*
 * AURA MSN — núcleo para celular e navegador.
 * Faz no próprio navegador o que o aura_msn.py faz no computador: fala com o servidor
 * (../api.php), guarda o histórico no aparelho e entrega eventos para a interface (app.js).
 */
(function () {
  const VERSION = '26.2.1';
  const SERVER = new URL('..', location.href).href.replace(/\/$/, '');
  const MAX_FILE = 25 * 1024 * 1024;
  const MAX_TEXT = 8000;
  const MAX_AVATAR = 400 * 1024;
  const STATUSES = ['online', 'away', 'busy', 'invisible'];
  const PEER = ['online', 'away', 'busy', 'offline'];
  const ANDROID = !!window.AuraAndroid;

  /* ------------------------------------------------ armazenamento */
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v, (key, val) => key === 'url' ? undefined : val)); } catch (e) { console.warn('armazenamento cheio', e); } },
    del(k) { try { localStorage.removeItem(k); } catch { /* ok */ } },
  };
  const IDB = {
    db: null,
    open() {
      if (this.db) return Promise.resolve(this.db);
      return new Promise((res, rej) => {
        const r = indexedDB.open('aura-msn', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('files');
        r.onsuccess = () => { this.db = r.result; res(this.db); };
        r.onerror = () => rej(r.error);
      });
    },
    async put(key, blob) {
      const db = await this.open();
      return new Promise((res, rej) => { const t = db.transaction('files', 'readwrite'); t.objectStore('files').put(blob, key); t.oncomplete = res; t.onerror = () => rej(t.error); });
    },
    async get(key) {
      const db = await this.open();
      return new Promise((res) => { const r = db.transaction('files').objectStore('files').get(key); r.onsuccess = () => res(r.result || null); r.onerror = () => res(null); });
    },
  };
  const urls = new Map();   // chave do arquivo -> blob: URL
  async function fileURL(key) {
    if (!key) return '';
    if (urls.has(key)) return urls.get(key);
    const b = await IDB.get(key);
    if (!b) return '';
    const u = URL.createObjectURL(b);
    urls.set(key, u);
    return u;
  }
  async function withURL(m) {
    if (m.kind === 'file' && m.file) return { ...m, file: { ...m.file, url: await fileURL(m.file.key) } };
    return { ...m };
  }

  /* ------------------------------------------------ servidor */
  class CloudError extends Error {
    constructor(msg, status = 0, data = {}) { super(msg); this.status = status; this.data = data; }
  }
  async function call(action, payload, opt = {}) {
    let url = `${SERVER}/api.php?a=${action}`;
    if (opt.query) url += '&' + new URLSearchParams(opt.query);
    const headers = { Accept: 'application/json' };
    if (C.acc?.token) headers['X-Aura-Token'] = C.acc.token;
    let body;
    if (opt.raw !== undefined) { body = opt.raw; headers['Content-Type'] = 'application/octet-stream'; }
    else if (payload !== undefined) { body = JSON.stringify(payload); headers['Content-Type'] = 'application/json'; }
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), opt.timeout || 25000);
    let r;
    try {
      r = await fetch(url, { method: body !== undefined ? 'POST' : 'GET', headers, body, signal: ctl.signal, cache: 'no-store' });
    } catch {
      throw new CloudError('Sem conexão com o servidor AURA. Confira sua internet.', 0);
    } finally { clearTimeout(timer); }
    if (!r.ok) {
      let d = {};
      try { d = await r.json(); } catch { /* ok */ }
      throw new CloudError(d.error || `O servidor respondeu com erro ${r.status}.`, r.status, d);
    }
    if (opt.blob) return r.blob();
    try { return await r.json(); } catch { throw new CloudError('O servidor respondeu algo inesperado.', 0); }
  }

  /* ------------------------------------------------ eventos para a interface */
  const handlers = {};
  function emit(kind, data) {
    for (const fn of handlers[kind] || []) {
      try { fn({ data: JSON.stringify(data) }); } catch (e) { console.error(e); }
    }
  }
  const now = () => Date.now() / 1000;
  const uid = pid => parseInt(String(pid).replace(/^u/, ''), 10);
  const newId = () => [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join('');
  const cleanId = v => String(v || '').replace(/[^0-9a-zA-Z]/g, '').slice(0, 64);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /* ------------------------------------------------ estado */
  const C = {
    acc: LS.get('aura_acc', null),
    running: false, connected: false, cursor: 0,
    profile: null, contacts: {}, hist: {}, online: new Set(), delivering: new Set(),
    wake: null, fails: 0, tick: 0,
  };
  const key = s => `aura_${C.acc.uid}_${s}`;
  const saveProfile = () => LS.set(key('perfil'), C.profile);
  const saveContacts = () => LS.set(key('contatos'), C.contacts);
  function history(pid) {
    if (!C.hist[pid]) C.hist[pid] = LS.get(key('h_' + pid), []);
    return C.hist[pid];
  }
  function saveHistory(pid) {
    const h = history(pid);
    if (h.length > 2000) h.splice(0, h.length - 2000);
    LS.set(key('h_' + pid), h);
  }
  function findMsg(pid, mid) {
    const h = history(pid);
    for (let i = h.length - 1; i >= 0; i--) if (h[i].id === mid) return h[i];
    return null;
  }
  async function updateMsg(pid, mid, fields) {
    const m = findMsg(pid, mid);
    if (!m) return null;
    Object.assign(m, fields);
    saveHistory(pid);
    emit('update', await withURL(m));
    return m;
  }
  function newContact(pid) {
    return { id: pid, name: '', alias: '', psm: '', status: 'offline', email: '', state: 'ok', ah: '', avatar: '',
      seen_at: 0, favorite: false, blocked: false, hidden: false, unread: 0 };
  }
  function isOnline(c) { return C.connected && c.status && c.status !== 'offline'; }
  function view(c) {
    return {
      id: c.id, name: c.alias || c.name || 'Contato', realname: c.name || '', alias: c.alias || '', psm: c.psm || '',
      status: isOnline(c) ? c.status : 'offline', avatar: c.avatar || '', favorite: !!c.favorite, blocked: !!c.blocked,
      hidden: !!c.hidden, unread: c.unread || 0, addr: c.email || '', email: c.email || '', seen_at: c.seen_at || 0,
      manual: true, state: c.state || 'ok',
    };
  }
  function requireContact(pid) {
    const c = C.contacts[pid];
    if (!c) throw new Error('Contato desconhecido');
    return c;
  }
  async function remote(action, payload, opt) {
    try { return await call(action, payload, opt); } catch (e) {
      if (e.status === 401) authLost(e.message);
      throw new Error(e.message);
    }
  }

  /* ------------------------------------------------ sessão */
  function start() {
    const a = C.acc;
    C.profile = Object.assign({ id: 'u' + a.uid, name: a.user?.name || a.email.split('@')[0], status: 'online', psm: a.user?.psm || '',
      avatar: a.user?.avatar || '', theme: 'auto', accent: '#3b82f6', sounds: true, notify: true }, LS.get(key('perfil'), {}));
    C.profile.id = 'u' + a.uid;
    C.profile.email = a.email;
    if (STATUSES.includes(a.status)) { C.profile.status = a.status; delete a.status; LS.set('aura_acc', a); }
    saveProfile();
    C.contacts = LS.get(key('contatos'), {});
    for (const c of Object.values(C.contacts)) { c.status = 'offline'; }
    C.hist = {};
    C.cursor = LS.get(key('cursor'), 0);
    C.connected = false;
    C.online = new Set();
    C.running = true;
    pollLoop();
  }
  function finishLogin(r, status) {
    const u = r.user || {};
    C.acc = { server: SERVER, token: r.token, uid: u.id, email: u.email, user: { name: u.name, psm: u.psm, avatar: u.avatar },
      status: STATUSES.includes(status) ? status : 'online' };
    LS.set('aura_acc', C.acc);
    LS.set('aura_last_email', u.email);
    start();
    emit('auth', { ok: true });
    return { ok: true, logged: true };
  }
  function stop() {
    C.running = false;
    if (C.wake) C.wake();
  }
  function authLost(msg) {
    if (!C.running) return;
    stop();
    C.acc = null;
    LS.del('aura_acc');
    emit('auth', { ok: false, msg });
  }

  /* ------------------------------------------------ contatos */
  async function syncContacts(items) {
    const changed = [], requests = [], avatars = [];
    const seen = new Set();
    for (const sc of items) {
      const pid = 'u' + parseInt(sc.id, 10);
      if (pid === 'uNaN') continue;
      seen.add(pid);
      let c = C.contacts[pid];
      let isNew = !c;
      if (isNew) c = C.contacts[pid] = newContact(pid);
      const before = JSON.stringify([c.name, c.psm, c.status, c.state, c.email, c.blocked, c.seen_at]);
      const status = PEER.includes(sc.status) ? sc.status : 'offline';
      Object.assign(c, { name: String(sc.name || '').slice(0, 80), psm: String(sc.psm || '').slice(0, 200), status,
        email: String(sc.email || ''), state: sc.state || 'ok', blocked: !!sc.blocked, seen_at: parseInt(sc.seen_at || 0, 10) });
      const ah = String(sc.ah || '');
      if (ah && ah !== c.ah) avatars.push(pid);
      else if (!ah && c.avatar) { c.avatar = c.ah = ''; isNew = true; }
      const after = JSON.stringify([c.name, c.psm, c.status, c.state, c.email, c.blocked, c.seen_at]);
      if (isNew || before !== after) {
        changed.push(pid);
        if (c.state === 'in' && (isNew || JSON.parse(before)[3] !== 'in')) requests.push(pid);
      }
    }
    const removed = Object.keys(C.contacts).filter(pid => !seen.has(pid));
    for (const pid of removed) { delete C.contacts[pid]; C.online.delete(pid); }
    if (changed.length || removed.length) saveContacts();
    for (const pid of changed) emit('contact', view(C.contacts[pid]));
    for (const pid of removed) emit('remove', { id: pid });
    for (const pid of requests) emit('request', view(C.contacts[pid]));
    for (const pid of avatars) fetchAvatar(pid);
    for (const pid of Object.keys(C.contacts)) checkOnline(pid);
  }
  function checkOnline(pid) {
    const c = C.contacts[pid];
    if (!c) return;
    const on = isOnline(c);
    if (on === C.online.has(pid)) return;
    on ? C.online.add(pid) : C.online.delete(pid);
    emit('contact', view(c));
    if (on) { emit('signin', { id: pid }); flushPending(pid); }
  }
  async function fetchAvatar(pid) {
    try {
      const r = await call('avatar', undefined, { query: { id: uid(pid) } });
      const a = String(r.avatar || '');
      if (a && (!a.startsWith('data:image/') || a.length > MAX_AVATAR)) return;
      const c = C.contacts[pid];
      if (!c) return;
      c.avatar = a; c.ah = String(r.ah || '').slice(0, 40);
      saveContacts();
      emit('contact', view(c));
    } catch { /* tenta de novo depois */ }
  }

  /* ------------------------------------------------ envio */
  function newMsg(pid, kind, extra) {
    return Object.assign({ id: newId(), peer: pid, dir: 'out', kind, ts: now(), state: 'sending' }, extra);
  }
  async function send(pid, kind, extra) {
    const c = requireContact(pid);
    if (c.state !== 'ok') throw new Error('Essa pessoa ainda não aceitou seu convite.');
    const m = newMsg(pid, kind, extra);
    history(pid).push(m);
    saveHistory(pid);
    const out = await withURL(m);
    emit('message', out);
    deliver(pid, m.id);
    return out;
  }
  function fire(pid, payload) {
    if (!C.connected || !C.contacts[pid]) return;
    call('send', Object.assign({ to: uid(pid) }, payload), { timeout: 10000 }).catch(() => {});
  }
  async function deliver(pid, mid) {
    if (C.delivering.has(mid)) return;
    C.delivering.add(mid);
    try {
      const m = findMsg(pid, mid);
      if (!m || !C.contacts[pid]) return;
      try {
        if (m.kind === 'file') await upload(pid, m);
        else await call('send', { to: uid(pid), kind: m.kind, id: m.id, ts: m.ts, text: m.text || '' });
        if (m.state !== 'read') await updateMsg(pid, mid, { state: 'sent' });
      } catch (e) {
        if (e.status === 401) authLost(e.message);
        const temporary = !(e instanceof CloudError) ? false : (e.status === 0 || e.status >= 500 || e.status === 429);
        if (m.kind === 'nudge' || !temporary) await updateMsg(pid, mid, { state: 'failed', error: e.message });
        else await updateMsg(pid, mid, { state: 'pending' });
      }
    } finally { C.delivering.delete(mid); }
  }
  async function upload(pid, m) {
    const blob = await IDB.get(m.file.key);
    if (!blob) throw new Error('O arquivo não está mais neste aparelho.');
    const r = await call('file_init', { to: uid(pid), name: m.file.name, size: blob.size, mime: m.file.mime });
    const size = parseInt(r.chunk || 1048576, 10);
    let off = 0, stuck = 0;
    while (off < blob.size) {
      const part = await blob.slice(off, off + size).arrayBuffer();
      const rr = await call('file_chunk', undefined, { query: { fid: r.fid, off }, raw: part, timeout: 180000 });
      const got = parseInt(rr.received ?? off, 10);
      stuck = got <= off ? stuck + 1 : 0;
      if (stuck > 3) throw new CloudError('O servidor não está aceitando o arquivo.', 500);
      off = got;
    }
    await call('file_done', { fid: r.fid, id: m.id, ts: m.ts });
  }
  function flushPending(pid) {
    for (const m of history(pid)) if (m.dir === 'out' && m.state === 'pending') deliver(pid, m.id);
  }
  function flushAll() { for (const pid of Object.keys(C.contacts)) flushPending(pid); }

  /* ------------------------------------------------ recebimento */
  async function download(fid) {
    try { return await call('file_get', undefined, { query: { fid }, blob: true, timeout: 300000 }); } catch (e) {
      if (e.status === 403 || e.status === 404) return null;
      throw e;
    }
  }
  async function storeFile(mid, f, blob) {
    const mime = f.mime || blob.type || 'application/octet-stream';
    const k = 'f_' + C.acc.uid + '_' + mid;
    await IDB.put(k, new Blob([blob], { type: mime }));
    return { name: String(f.name || 'arquivo').slice(0, 150), size: blob.size, mime, key: k };
  }
  async function ingest(pid, kind, env, blob) {
    const c = C.contacts[pid];
    if (!c) return;
    if (kind === 'typing') return emit('typing', { id: pid });
    if (kind === 'text' || kind === 'nudge' || kind === 'file') {
      const mid = cleanId(env.id) || newId();
      if (findMsg(pid, mid)) return;
      const m = { id: mid, peer: pid, dir: 'in', kind, ts: now(), state: 'received' };
      if (kind === 'text') m.text = String(env.text || '').slice(0, MAX_TEXT);
      if (kind === 'file') {
        if (!blob || blob.size > MAX_FILE) return;
        m.file = await storeFile(mid, env.file || {}, blob);
      }
      if (env.ts && kind !== 'nudge') m.ts = Math.min(parseFloat(env.ts) || now(), now());
      history(pid).push(m);
      saveHistory(pid);
      c.unread = (c.unread || 0) + 1;
      c.hidden = false;
      saveContacts();
      const out = await withURL(m);
      if (env.stale) out.quiet = true;
      emit('message', out);
      emit('contact', view(c));
      if (kind === 'nudge' && !env.stale) { emit('nudge', { id: pid }); vibrate(); }
      if (!env.stale && kind !== 'nudge' && ANDROID) {
        try { AuraAndroid.notify(view(c).name, kind === 'file' ? 'Arquivo: ' + m.file.name : m.text.slice(0, 160)); } catch { /* ok */ }
      } else if (!env.stale && kind === 'nudge' && ANDROID) {
        try { AuraAndroid.notify(view(c).name, 'chamou sua atenção!'); } catch { /* ok */ }
      }
    } else if (kind === 'read') {
      for (const id of (env.ids || []).slice(0, 500)) {
        const m = findMsg(pid, String(id));
        if (m && m.dir === 'out' && m.state !== 'read') await updateMsg(pid, m.id, { state: 'read' });
      }
    } else if (kind === 'react') {
      const m = findMsg(pid, String(env.target || ''));
      if (m) {
        const r = Object.assign({}, m.reactions || {});
        const em = String(env.emoji || '').slice(0, 8);
        em ? (r[pid] = em) : delete r[pid];
        await updateMsg(pid, m.id, { reactions: r });
      }
    }
  }
  async function handleSelf(kind, pid, d) {
    if (!C.contacts[pid]) return;
    if (kind === 'text' || kind === 'nudge' || kind === 'file') {
      const mid = cleanId(d.id);
      if (!mid || findMsg(pid, mid)) return;
      const m = { id: mid, peer: pid, dir: 'out', kind, ts: Math.min(parseFloat(d.ts) || now(), now()), state: 'sent' };
      if (kind === 'text') m.text = String(d.text || '').slice(0, MAX_TEXT);
      if (kind === 'file') {
        const blob = await download(String(d.file?.fid || ''));
        if (!blob) return;
        m.file = await storeFile(mid, d.file || {}, blob);
      }
      history(pid).push(m);
      saveHistory(pid);
      emit('message', Object.assign(await withURL(m), { quiet: true }));
    } else if (kind === 'read') {
      const ids = new Set((d.ids || []).map(String));
      let changed = false;
      for (const m of history(pid)) if (m.dir === 'in' && ids.has(m.id) && m.state !== 'read') { m.state = 'read'; changed = true; }
      if (changed) saveHistory(pid);
      C.contacts[pid].unread = 0;
      saveContacts();
      emit('contact', view(C.contacts[pid]));
    } else if (kind === 'react') {
      const m = findMsg(pid, String(d.target || ''));
      if (m) {
        const r = Object.assign({}, m.reactions || {});
        const em = String(d.emoji || '').slice(0, 8);
        em ? (r.me = em) : delete r.me;
        await updateMsg(pid, m.id, { reactions: r });
      }
    }
  }
  async function handleEvent(ev, serverTime) {
    const kind = String(ev.kind || '');
    const d = ev.data && typeof ev.data === 'object' ? ev.data : {};
    const stale = serverTime - (parseFloat(ev.ts) || serverTime) > 90;
    if (kind === 'contacts') return;
    if (kind.startsWith('self_')) return handleSelf(kind.slice(5), 'u' + d.peer, d);
    const pid = 'u' + ev.from;
    const c = C.contacts[pid];
    if (!c || c.blocked) return;
    if (kind === 'typing' && stale) return;
    let blob = null;
    if (kind === 'file') {
      const mid = cleanId(d.id);
      if (mid && findMsg(pid, mid)) return;
      blob = await download(String(d.file?.fid || ''));
      if (!blob) return;
    }
    await ingest(pid, kind, Object.assign({}, d, { stale }), blob);
  }
  async function applyPoll(r) {
    const serverTime = parseFloat(r.time) || now();
    await syncContacts(r.contacts || []);
    let cursor = C.cursor, complete = true;
    for (const ev of r.events || []) {
      try { await handleEvent(ev, serverTime); } catch (e) {
        if (e instanceof CloudError) { complete = false; break; }
        console.warn('evento ignorado', e);
      }
      cursor = Math.max(cursor, parseInt(ev.id || 0, 10));
    }
    if (complete) cursor = Math.max(cursor, parseInt(r.cursor || 0, 10));
    if (cursor !== C.cursor) { C.cursor = cursor; LS.set(key('cursor'), cursor); }
  }
  function setConnected(ok, msg = '') {
    if (ok === C.connected) return;
    C.connected = ok;
    emit('net', { ok, msg });
    for (const c of Object.values(C.contacts)) emit('contact', view(c));
    for (const pid of Object.keys(C.contacts)) checkOnline(pid);
    if (ok) flushAll();
  }
  async function pollLoop() {
    const myAcc = C.acc;
    while (C.running && C.acc === myAcc) {
      let more = false;
      try {
        const r = await call('poll', { cursor: C.cursor, status: C.profile.status }, { timeout: 30000 });
        if (!C.running || C.acc !== myAcc) return;
        C.fails = 0;
        await applyPoll(r);
        setConnected(true);
        more = !!r.more;
        if (++C.tick % 15 === 0) flushAll();
      } catch (e) {
        if (e.status === 401) { authLost(e.message); return; }
        C.fails++;
        if (C.fails >= 2) setConnected(false, e.message);
      }
      if (!C.running) return;
      if (more) continue;
      let wait = (document.hidden ? 6000 : 2000) * (C.profile.status === 'away' ? 2.5 : 1);
      if (C.fails) wait = Math.min(20000, 2000 + C.fails * 3000);
      await new Promise(res => { const t = setTimeout(res, wait); C.wake = () => { clearTimeout(t); res(); }; });
      C.wake = null;
    }
  }
  function wakeUp() { if (C.wake) C.wake(); }

  /* ------------------------------------------------ ações da interface */
  async function markRead(pid) {
    const c = requireContact(pid);
    const ids = [];
    for (const m of history(pid)) if (m.dir === 'in' && m.state === 'received') { m.state = 'read'; ids.push(m.id); }
    if (ids.length) saveHistory(pid);
    const changed = (c.unread || 0) !== 0;
    c.unread = 0;
    if (changed) { saveContacts(); emit('contact', view(c)); }
    if (ids.length) fire(pid, { kind: 'read', ids: ids.slice(-500) });
  }
  async function updateProfile(d) {
    const rem = {};
    for (const k of ['name', 'psm', 'avatar']) if (k in d) rem[k] = d[k];
    if (Object.keys(rem).length) await remote('profile', rem);
    const p = C.profile;
    if ('name' in d) p.name = String(d.name).trim().slice(0, 80) || p.name;
    if ('psm' in d) p.psm = String(d.psm).trim().slice(0, 200);
    if (STATUSES.includes(d.status)) p.status = d.status;
    if ('avatar' in d) {
      const a = String(d.avatar || '');
      if (a && (!a.startsWith('data:image/') || a.length > MAX_AVATAR)) throw new Error('Imagem de perfil inválida ou grande demais');
      p.avatar = a;
    }
    if (['auto', 'light', 'dark'].includes(d.theme)) p.theme = d.theme;
    if (typeof d.accent === 'string' && /^#[0-9a-fA-F]{6}$/.test(d.accent)) p.accent = d.accent;
    for (const k of ['sounds', 'notify']) if (k in d) p[k] = !!d[k];
    saveProfile();
    wakeUp();
    emit('me', p);
    return p;
  }
  async function addByEmail(email) {
    email = String(email || '').trim().toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Digite um e-mail válido, ex.: amigo@gmail.com');
    let r;
    try { r = await call('contact_add', { email }); } catch (e) {
      if (e.status === 401) authLost(e.message);
      if (e.data?.not_found) return { not_found: true, email };
      throw new Error(e.message);
    }
    await syncContacts(r.contacts || []);
    const c = Object.values(C.contacts).find(x => x.email === email);
    if (c) { c.hidden = false; saveContacts(); return view(c); }
    return { ok: true };
  }
  async function saveToDevice(pid, mid) {
    const m = findMsg(pid, mid);
    if (!m?.file) return;
    const blob = await IDB.get(m.file.key);
    if (!blob) throw new Error('O arquivo não está mais neste aparelho.');
    if (ANDROID) {
      const b64 = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(blob); });
      const ok = AuraAndroid.saveFile(m.file.name, m.file.mime, b64);
      if (ok !== 'ok') throw new Error('Não foi possível salvar: ' + ok);
      emit('saved', { name: m.file.name });
      return;
    }
    const a = document.createElement('a');
    a.href = await fileURL(m.file.key); a.download = m.file.name;
    document.body.append(a); a.click(); a.remove();
  }
  function vibrate() {
    try { if (ANDROID) AuraAndroid.vibrate(500); else navigator.vibrate?.([120, 80, 120, 80, 220]); } catch { /* ok */ }
  }
  function search(q) {
    q = q.toLowerCase().trim();
    const out = [];
    if (q.length < 2) return out;
    for (const pid of Object.keys(C.contacts)) {
      for (const m of history(pid).slice().reverse()) {
        const t = m.text || m.file?.name || '';
        if (t.toLowerCase().includes(q)) out.push({ peer: pid, id: m.id, text: t.slice(0, 160), ts: m.ts, dir: m.dir });
        if (out.length >= 80) break;
      }
    }
    return out.sort((a, b) => b.ts - a.ts);
  }
  function b64ToBlob(b64, mime) {
    const bin = atob(b64 || '');
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  }
  function mimeOf(name) {
    const ext = String(name).split('.').pop().toLowerCase();
    return { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp',
      mp3: 'audio/mpeg', ogg: 'audio/ogg', wav: 'audio/wav', m4a: 'audio/mp4', mp4: 'video/mp4', webm: 'video/webm',
      pdf: 'application/pdf', txt: 'text/plain', zip: 'application/zip', doc: 'application/msword',
      docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }[ext] || 'application/octet-stream';
  }

  async function handle(path, d = {}) {
    const u = new URL(path, location.href);
    const p = u.pathname.replace(/^.*\/api\//, '/api/');
    const q = u.searchParams;
    const peer = String(d.peer || '');

    if (p === '/api/ping') return { ok: true };
    if (p.startsWith('/api/auth/')) {
      const action = p.slice('/api/auth/'.length);
      if (action === 'info') {
        const info = { server: SERVER, configured: true, google: false, reachable: false, lan: false, last_email: LS.get('aura_last_email', '') };
        try { const r = await call('info', undefined, { timeout: 8000 }); info.reachable = r.app === 'aura-server'; } catch (e) { info.error = e.message; }
        return info;
      }
      if (action === 'logout') {
        if (C.acc) { try { await call('logout', {}, { timeout: 6000 }); } catch { /* ok */ } }
        stop();
        LS.set('aura_last_email', C.acc?.email || '');
        C.acc = null;
        LS.del('aura_acc');
        emit('auth', { ok: false });
        return { ok: true };
      }
      if (action === 'lan' || action === 'google') throw new Error('Essa opção não está disponível no celular.');
      if (C.running) return { ok: true, logged: true };
      if (!['login', 'register', 'verify', 'resend', 'forgot', 'reset'].includes(action)) throw new Error('Ação desconhecida');
      const payload = {};
      for (const k of ['email', 'password', 'name', 'code']) if (k in d) payload[k] = d[k];
      payload.device = ANDROID ? 'Celular Android' : 'Navegador';
      let r;
      try { r = await call(action, payload); } catch (e) { throw new Error(e.message); }
      if (r.token) return finishLogin(r, d.status || 'online');
      return r;
    }
    if (p === '/api/quit') return { ok: true };
    if (p === '/api/state') {
      if (!C.running) return { login: true, version: VERSION, platform: ANDROID ? 'android' : 'web', server: SERVER };
      return { me: C.profile, contacts: Object.values(C.contacts).map(view), version: VERSION, mode: 'cloud',
        downloads: ANDROID ? 'Downloads/AURA MSN' : 'Downloads', platform: ANDROID ? 'android' : 'web', server: SERVER,
        addresses: [], account: { email: C.acc.email, server: SERVER }, connected: C.connected };
    }
    if (!C.running) throw new Error('Entre na sua conta primeiro.');
    switch (p) {
      case '/api/history': {
        const list = history(q.get('peer') || '').slice(-1500);
        return { messages: await Promise.all(list.map(withURL)) };
      }
      case '/api/search': return { results: search(q.get('q') || '') };
      case '/api/profile': return updateProfile(d);
      case '/api/send': {
        const text = String(d.text || '').trim().slice(0, MAX_TEXT);
        if (!text) throw new Error('Mensagem vazia');
        return send(peer, 'text', { text });
      }
      case '/api/file': {
        const name = String(d.name || 'arquivo').replace(/[\\/:*?"<>|]/g, '_').slice(0, 150) || 'arquivo';
        const blob = b64ToBlob(d.data, mimeOf(name));
        if (blob.size > MAX_FILE) throw new Error('Arquivo maior que 25 MB');
        const id = newId();
        const k = 'f_' + C.acc.uid + '_' + id;
        await IDB.put(k, blob);
        const c = requireContact(peer);
        if (c.state !== 'ok') throw new Error('Essa pessoa ainda não aceitou seu convite.');
        const m = { id, peer, dir: 'out', kind: 'file', ts: now(), state: 'sending', file: { name, size: blob.size, mime: blob.type, key: k } };
        history(peer).push(m); saveHistory(peer);
        const out = await withURL(m);
        emit('message', out);
        deliver(peer, id);
        return out;
      }
      case '/api/nudge': return send(peer, 'nudge', {});
      case '/api/typing': requireContact(peer); fire(peer, { kind: 'typing' }); return { ok: true };
      case '/api/read': await markRead(peer); return { ok: true };
      case '/api/react': {
        const m = findMsg(peer, String(d.mid || ''));
        if (!m) throw new Error('Mensagem não encontrada');
        const em = String(d.emoji || '').slice(0, 8);
        const r = Object.assign({}, m.reactions || {});
        em ? (r.me = em) : delete r.me;
        await updateMsg(peer, m.id, { reactions: r });
        fire(peer, { kind: 'react', target: m.id, emoji: em });
        return { ok: true };
      }
      case '/api/contacts/add': return addByEmail(d.email || d.address);
      case '/api/contacts/answer': { const r = await remote('contact_answer', { id: uid(peer), accept: !!d.accept }); await syncContacts(r.contacts || []); return { ok: true }; }
      case '/api/contacts/remove': { const r = await remote('contact_remove', { id: uid(peer) }); await syncContacts(r.contacts || []); return { ok: true }; }
      case '/api/contacts/invite': await remote('invite', { email: String(d.email || '').trim().toLowerCase() }); return { ok: true };
      case '/api/contacts/update': {
        const c = requireContact(peer);
        if ('blocked' in d) await remote('contact_block', { id: uid(peer), blocked: !!d.blocked });
        if ('alias' in d) c.alias = String(d.alias).trim().slice(0, 80);
        for (const k of ['favorite', 'blocked', 'hidden']) if (k in d) c[k] = !!d[k];
        saveContacts();
        const v = view(c);
        emit('contact', v);
        return v;
      }
      case '/api/history/clear': C.hist[peer] = []; saveHistory(peer); return { ok: true };
      case '/api/reveal': await saveToDevice(peer, String(d.mid || '')); return { ok: true };
      case '/api/openfolder': return { ok: true };
    }
    throw new Error('Ação desconhecida');
  }

  /* ------------------------------------------------ app em segundo plano (Android) */
  let hiddenFlag = false;
  try {
    Object.defineProperty(document, 'hidden', { configurable: true, get: () => hiddenFlag || document.visibilityState === 'hidden' });
  } catch { /* navegador sem suporte: usa o padrão */ }
  window.__auraSetHidden = h => {
    hiddenFlag = !!h;
    document.dispatchEvent(new Event('visibilitychange'));
    if (!h) wakeUp();
  };

  window.AuraCore = {
    version: VERSION,
    android: ANDROID,
    async api(path, body) {
      try { return await handle(path, body || {}); } catch (e) { throw (e instanceof Error ? e : new Error(String(e))); }
    },
    events() {
      setTimeout(() => emit('hello', {}), 0);
      return {
        addEventListener(kind, fn) { (handlers[kind] = handlers[kind] || []).push(fn); },
        close() { /* nada */ },
        set onerror(fn) { /* sem erros de conexão local */ },
      };
    },
    vibrate,
  };

  if (C.acc?.token) start();
})();
