@echo off
rem Abre o AURA MSN sem precisar instalar.
cd /d "%~dp0"
where pyw >nul 2>nul
if %errorlevel%==0 (
  start "" pyw -3 "%~dp0aura_msn.py" %*
  exit /b
)
where pythonw >nul 2>nul
if %errorlevel%==0 (
  start "" pythonw "%~dp0aura_msn.py" %*
  exit /b
)
echo.
echo  O AURA MSN precisa do Python 3 (gratuito).
echo  Instale com o comando abaixo e depois abra este arquivo de novo:
echo.
echo     winget install Python.Python.3.12
echo.
echo  ou baixe em https://www.python.org/downloads/ (marque "Add python.exe to PATH").
echo.
pause
