# AURA MSN 26

Um mensageiro instantâneo inspirado nos programas de bate-papo dos anos 2000, imaginado
como se tivesse continuado a evoluir por 20 anos. Os mensageiros antigos morreram quando
os servidores foram desligados, por isso o AURA **não depende de servidor nenhum**: os
computadores se encontram sozinhos na rede e conversam direto entre si.

Funciona no **Windows 10, Windows 11 e Linux Mint** (e em outros Linux com Python 3).

## O que ele faz

| Clássico dos anos 2000 | Como ficou no AURA |
|---|---|
| Lista de contatos com status | Status com anel colorido: Disponível, Ausente, Ocupado e Invisível. Grupos Favoritos, Disponíveis e Offline |
| Mensagem pessoal | Editável direto no cabeçalho, com emoticons |
| Foto de exibição | Recortada e reduzida automaticamente. Sem foto, mostra as iniciais num gradiente |
| "Chamar a atenção" | Tremida na janela + som (com limite de tempo para ninguém abusar) |
| Emoticons `:)` `(y)` `<3` | Viram emojis Unicode. Painel de emojis e emoji sozinho aparece gigante |
| Envio de arquivos | Até 25 MB: arraste para a conversa, cole uma imagem (Ctrl+V) ou use 📎. Imagens aparecem inline |
| "Fulano está digitando" | ✔ |
| Mensagens offline | Ficam na fila (⏳) e são entregues quando o contato aparecer |
| — | Confirmação de entrega ✓ e de leitura ✓✓ |
| — | Reações às mensagens (👍 ❤️ 😂 …) |
| — | Busca em todas as conversas e dentro de uma conversa |
| — | Tema claro/escuro automático e 8 cores de destaque |
| — | Notificações nativas do sistema e título piscando |
| — | Ausente automático após 10 minutos sem uso |
| — | Apelidos, favoritos, ocultar e bloquear contatos |
| — | *negrito*, _itálico_, ~riscado~ e links clicáveis |

## Instalação

### Windows 10/11
1. Clique com o botão direito em **`instalar-windows.ps1`** e escolha **Executar com o PowerShell**.
   Se o Python 3 não estiver instalado, o script instala sozinho pelo `winget`.
2. Use o atalho **AURA MSN** no Menu Iniciar ou na Área de Trabalho.
3. Na primeira vez, o Firewall do Windows vai perguntar. Marque **Redes privadas** e clique em **Permitir**.

Para usar sem instalar, dê dois cliques em **`AURA MSN.bat`**.

### Linux Mint
```bash
bash instalar-linux-mint.sh
```
Depois procure **AURA MSN** no menu. Para ele abrir numa janela própria, sem barra de
endereço, instale o Chromium (`sudo apt install chromium`). Sem o Chromium, ele abre como aba do Firefox.

Para desinstalar, use `bash instalar-linux-mint.sh --desinstalar` ou
`instalar-windows.ps1 -Desinstalar`.

## Estado da edição AURA MSN

Esta edição recebeu a identidade AURA MSN e mantém o aplicativo desktop para Windows e Linux Mint.
**A comunicação entre computadores ainda é ponto a ponto/rede local nesta versão.** O cadastro por
Google/e-mail e o serviço de mensagens global precisam de um backend online configurado; não seria
correto prometer conversas entre redes diferentes antes de instalar e configurar esse serviço.

### Etapa necessária para liberar o uso pela internet
- Backend online com autenticação por e-mail e Google.
- Banco remoto para perfis, contatos e mensagens, com políticas de segurança por usuário.
- Serviço de presença e entrega de mensagens em tempo real.
- Credenciais públicas do projeto e configuração do provedor Google OAuth.

Não coloque chaves administrativas ou `service_role` dentro do aplicativo. O aplicativo distribuído
deve usar somente chaves públicas e políticas RLS no servidor.

## Onde ficam os dados
- Perfil, contatos e histórico:
  - Windows: `%APPDATA%\AURAMSN\`
  - Linux: `~/.local/share/aura-msn/`
- Arquivos recebidos: `Downloads/AURA MSN/`

## Opções de linha de comando
```
python aura_msn.py --perfil maria    # outro perfil (duas contas no mesmo PC)
python aura_msn.py --manter-aberto   # continua online mesmo com a janela fechada
python aura_msn.py --sem-janela      # só o serviço; mostra o endereço da interface
```

## Privacidade e limitações
- As mensagens vão direto de um computador para o outro e não passam por nenhum servidor.
  Elas **não são criptografadas** na rede local, então use o AURA em redes de confiança (casa ou
  escritório) ou através de uma VPN, que já criptografa o tráfego.
- A interface só aceita conexões do próprio computador e exige um token aleatório criado a cada execução.
- Ainda não tem conversas em grupo nem chamadas de voz ou vídeo.

Requisitos: Python 3.8 ou mais novo, só a biblioteca padrão, sem dependências extras.
