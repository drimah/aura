#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AURA MSN 26
Mensageiro instantâneo ponto a ponto para a rede local.

- Edição desktop renomeada; transporte original ponto a ponto preservado nesta versão.
- Funciona no Windows 10/11 e no Linux (Mint, Ubuntu...) usando apenas Python 3.8+.
- Interface moderna aberta numa janela própria (Edge/Chrome/Chromium em modo app).

Uso:
    python3 aura_msn.py                 abre o mensageiro
    python3 aura_msn.py --perfil maria  usa outro perfil (várias contas no mesmo PC)
    python3 aura_msn.py --gerar-icones  gera icone.png / icone.ico na pasta web/
"""
from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
import json
import mimetypes
import os
import queue
import re
import secrets
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse
from urllib.request import ProxyHandler, Request, build_opener

APP_NAME = "AURA MSN"
VERSION = "26.0.1"
PROTO = 1
DISCOVERY_PORT = 47100
P2P_PORT = 47101
PRESENCE_EVERY = 4          # segundos entre anúncios de presença
ONLINE_TTL = 15             # sem anúncio por esse tempo => offline
MAX_FILE = 25 * 1024 * 1024
MAX_BODY = MAX_FILE * 4 // 3 + 256 * 1024
MAX_TEXT = 8000
MAX_AVATAR = 400 * 1024
STATUSES = {"online", "away", "busy", "invisible"}
PEER_STATUSES = {"online", "away", "busy", "offline"}
WEB_DIR = Path(__file__).resolve().parent / "web"
OPENER = build_opener(ProxyHandler({}))  # nunca usar proxy para falar com a rede local


# ----------------------------------------------------------------- utilidades
def now() -> float:
    return time.time()


def data_root() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("APPDATA", str(Path.home()))) / "AURAMSN"
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "aura-msn"


def downloads_dir() -> Path:
    d = Path.home() / "Downloads"
    if os.name != "nt" and shutil.which("xdg-user-dir"):
        try:
            out = subprocess.run(["xdg-user-dir", "DOWNLOAD"], capture_output=True,
                                 text=True, timeout=3).stdout.strip()
            if out and out != str(Path.home()):
                d = Path(out)
        except Exception:
            pass
    return d / APP_NAME


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, obj) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)


_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


def safe_name(name) -> str:
    name = str(name).replace("\\", "/").split("/")[-1]
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name).strip(" .")
    if name.split(".")[0].upper() in _RESERVED:
        name = "_" + name
    return name[:150] or "arquivo"


def unique_path(folder: Path, name: str) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    p = folder / name
    i = 1
    while p.exists():
        p = folder / f"{Path(name).stem} ({i}){Path(name).suffix}"
        i += 1
    return p


def primary_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # não envia nada, só escolhe a interface
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def local_ips() -> list[str]:
    ips = {primary_ip()}
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except Exception:
        pass
    ips = {ip for ip in ips if not ip.startswith("127.") and not ip.startswith("169.254.")}
    return sorted(ips) or ["127.0.0.1"]


def is_loopback(host: str) -> bool:
    return host.startswith("127.") or host == "::1"


def open_path(path: Path, select: bool = False) -> None:
    try:
        if os.name == "nt":
            if select and path.is_file():
                subprocess.Popen(["explorer", "/select,", str(path)])
            else:
                os.startfile(str(path if path.is_dir() else path.parent))  # type: ignore[attr-defined]
        else:
            target = path.parent if (select or path.is_file()) else path
            subprocess.Popen(["xdg-open", str(target)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        print("Não foi possível abrir a pasta:", exc)


# ------------------------------------------------------------ núcleo do app
class Messenger:
    def __init__(self, profile_name: str, preferred_port: int):
        self.root = data_root() / safe_name(profile_name)
        self.hist_dir = self.root / "historico"
        self.sent_dir = self.root / "enviados"
        self.recv_dir = downloads_dir()
        for d in (self.root, self.hist_dir, self.sent_dir):
            d.mkdir(parents=True, exist_ok=True)

        self.lock = threading.RLock()
        self.listeners: list[queue.Queue] = []
        self.had_client = False
        self.last_client = now()
        self.running = True
        self.p2p_port = preferred_port
        self.udp: socket.socket | None = None
        self.online: set[str] = set()
        self.delivering: set[str] = set()
        self.histories: dict[str, list] = {}

        try:
            default_name = getpass.getuser().capitalize()
        except Exception:
            default_name = "Eu"
        self.profile = read_json(self.root / "perfil.json", {})
        for k, v in {"id": uuid.uuid4().hex, "name": default_name, "status": "online", "psm": "",
                     "avatar": "", "theme": "auto", "accent": "#3b82f6", "sounds": True,
                     "notify": True}.items():
            self.profile.setdefault(k, v)
        if self.profile["status"] not in STATUSES:
            self.profile["status"] = "online"
        self.save_profile()

        self.contacts: dict[str, dict] = read_json(self.root / "contatos.json", {})
        for c in self.contacts.values():
            c["last_seen"] = 0
            c["status"] = "offline"

    # ---------------------------------------------------------- persistência
    def save_profile(self):
        with self.lock:
            write_json(self.root / "perfil.json", self.profile)

    def save_contacts(self):
        with self.lock:
            write_json(self.root / "contatos.json", self.contacts)

    def history(self, pid: str) -> list:
        with self.lock:
            if pid not in self.histories:
                self.histories[pid] = read_json(self.hist_dir / f"{safe_name(pid)}.json", [])
            return self.histories[pid]

    def save_history(self, pid: str):
        with self.lock:
            write_json(self.hist_dir / f"{safe_name(pid)}.json", self.history(pid))

    def add_msg(self, pid: str, m: dict):
        with self.lock:
            self.history(pid).append(m)
            self.save_history(pid)

    def find_msg(self, pid: str, mid: str):
        with self.lock:
            for m in reversed(self.history(pid)):
                if m.get("id") == mid:
                    return m
        return None

    def update_msg(self, pid: str, mid: str, **fields):
        with self.lock:
            m = self.find_msg(pid, mid)
            if not m:
                return None
            m.update(fields)
            self.save_history(pid)
            snapshot = dict(m)
        self.emit("update", snapshot)
        return snapshot

    # ------------------------------------------------------------- eventos
    def emit(self, kind: str, data):
        for q in list(self.listeners):
            q.put((kind, data))

    # ------------------------------------------------------------ perfil
    def avatar_hash(self) -> str:
        a = self.profile.get("avatar") or ""
        return hashlib.sha1(a.encode()).hexdigest()[:12] if a else ""

    def public_status(self) -> str:
        st = self.profile["status"]
        return "offline" if (st == "invisible" or not self.running) else st

    def public(self) -> dict:
        p = self.profile
        return {"app": "aura", "proto": PROTO, "v": VERSION, "id": p["id"], "name": p["name"],
                "psm": p["psm"], "status": self.public_status(), "port": self.p2p_port,
                "ah": self.avatar_hash()}

    def update_profile(self, data: dict) -> dict:
        with self.lock:
            p = self.profile
            if "name" in data:
                p["name"] = str(data["name"]).strip()[:80] or p["name"]
            if "psm" in data:
                p["psm"] = str(data["psm"]).strip()[:200]
            if data.get("status") in STATUSES:
                p["status"] = data["status"]
            if "avatar" in data:
                a = str(data["avatar"] or "")
                if a and (not a.startswith("data:image/") or len(a) > MAX_AVATAR):
                    raise ValueError("Imagem de perfil inválida ou grande demais")
                p["avatar"] = a
            if data.get("theme") in ("auto", "light", "dark"):
                p["theme"] = data["theme"]
            if isinstance(data.get("accent"), str) and re.fullmatch(r"#[0-9a-fA-F]{6}", data["accent"]):
                p["accent"] = data["accent"]
            for k in ("sounds", "notify"):
                if k in data:
                    p[k] = bool(data[k])
            self.save_profile()
            snapshot = dict(p)
        self.announce()
        self.emit("me", snapshot)
        return snapshot

    # ----------------------------------------------------------- contatos
    @staticmethod
    def new_contact(pid: str) -> dict:
        return {"id": pid, "name": "", "alias": "", "psm": "", "status": "offline", "host": "",
                "port": P2P_PORT, "ah": "", "avatar": "", "last_seen": 0, "seen_at": 0,
                "favorite": False, "blocked": False, "hidden": False, "manual": False, "unread": 0}

    def is_online(self, c: dict) -> bool:
        return c.get("status") != "offline" and now() - c.get("last_seen", 0) < ONLINE_TTL

    def contact_view(self, c: dict) -> dict:
        on = self.is_online(c)
        return {"id": c["id"], "name": c.get("alias") or c.get("name") or "Contato",
                "realname": c.get("name", ""), "alias": c.get("alias", ""), "psm": c.get("psm", ""),
                "status": c.get("status", "online") if on else "offline", "avatar": c.get("avatar", ""),
                "favorite": c.get("favorite", False), "blocked": c.get("blocked", False),
                "hidden": c.get("hidden", False), "unread": c.get("unread", 0),
                "addr": f"{c.get('host')}:{c.get('port')}", "seen_at": c.get("seen_at", 0),
                "manual": c.get("manual", False)}

    def _set_host(self, c: dict, host: str):
        # não troca um IP de rede por 127.0.0.1 (instâncias no mesmo PC)
        if not c.get("host") or not is_loopback(host) or is_loopback(c["host"]):
            c["host"] = host

    def handle_presence(self, pkt: dict, host: str) -> dict | None:
        pid = str(pkt.get("id", ""))[:64]
        if not pid or pid == self.profile["id"]:
            return None
        try:
            port = int(pkt.get("port", P2P_PORT))
        except (TypeError, ValueError):
            port = P2P_PORT
        status = pkt.get("status") if pkt.get("status") in PEER_STATUSES else "online"
        name = str(pkt.get("name", ""))[:80]
        psm = str(pkt.get("psm", ""))[:200]
        ah = str(pkt.get("ah", ""))[:40]
        with self.lock:
            c = self.contacts.get(pid)
            new = c is None
            if new:
                c = self.contacts[pid] = self.new_contact(pid)
            before = (c["name"], c["psm"], c["status"], c["host"], c["port"])
            self._set_host(c, host)
            c.update(name=name or c["name"], psm=psm, status=status, port=port)
            if status == "offline":
                c["last_seen"] = 0
            else:
                c["last_seen"] = c["seen_at"] = now()
            need_avatar = bool(ah) and ah != c.get("ah")
            if not ah and c.get("avatar"):
                c["avatar"] = c["ah"] = ""
                new = True
            changed = new or before != (c["name"], c["psm"], c["status"], c["host"], c["port"])
            if changed:
                self.save_contacts()
            view = self.contact_view(c)
        if need_avatar:
            threading.Thread(target=self.fetch_avatar, args=(pid,), daemon=True).start()
        if changed:
            self.emit("contact", view)
        self.check_online(pid)
        return view

    def check_online(self, pid: str):
        with self.lock:
            c = self.contacts.get(pid)
            if not c:
                return
            on = self.is_online(c)
            if on == (pid in self.online):
                return
            (self.online.add if on else self.online.discard)(pid)
            view = self.contact_view(c)
        self.emit("contact", view)
        if on:
            self.emit("signin", {"id": pid})
            self.flush_pending(pid)

    def fetch_avatar(self, pid: str):
        c = self.contacts.get(pid)
        if not c:
            return
        try:
            r = self.peer_call(c, "/p2p/avatar")
            a = str(r.get("avatar") or "")
            if a and (not a.startswith("data:image/") or len(a) > MAX_AVATAR):
                return
            with self.lock:
                c["avatar"], c["ah"] = a, str(r.get("ah", ""))[:40]
                self.save_contacts()
                view = self.contact_view(c)
            self.emit("contact", view)
        except Exception:
            pass

    def add_by_address(self, address: str) -> dict:
        address = address.strip()
        m = re.fullmatch(r"\[?([0-9A-Za-z.\-:]+?)\]?(?::(\d{1,5}))?", address)
        if not m:
            raise ValueError("Endereço inválido. Use algo como 192.168.0.20:47101")
        host, port = m.group(1), int(m.group(2) or P2P_PORT)
        try:
            hello = self.peer_call({"host": host, "port": port}, "/p2p/hello", timeout=5)
        except Exception:
            raise ValueError(f"Ninguém respondeu em {host}:{port}. O AURA está aberto lá?")
        if hello.get("app") != "aura":
            raise ValueError("Esse endereço não é um AURA MSN.")
        view = self.handle_presence(hello, host)
        if not view:
            raise ValueError("Esse endereço é você mesmo 🙂")
        with self.lock:
            c = self.contacts[view["id"]]
            c["manual"] = True
            c["hidden"] = False
            self.save_contacts()
            view = self.contact_view(c)
        self.emit("contact", view)
        self.announce()
        return view

    def update_contact(self, pid: str, data: dict) -> dict:
        with self.lock:
            c = self.require_contact(pid)
            if "alias" in data:
                c["alias"] = str(data["alias"]).strip()[:80]
            for k in ("favorite", "blocked", "hidden"):
                if k in data:
                    c[k] = bool(data[k])
            self.save_contacts()
            view = self.contact_view(c)
        self.emit("contact", view)
        return view

    def require_contact(self, pid: str) -> dict:
        c = self.contacts.get(str(pid))
        if not c:
            raise ValueError("Contato desconhecido")
        return c

    # ------------------------------------------------------- comunicação P2P
    def peer_call(self, c: dict, path: str, payload=None, timeout: float = 6):
        host = c["host"]
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        data = json.dumps(payload).encode() if payload is not None else None
        req = Request(f"http://{host}:{c['port']}{path}", data=data,
                      headers={"Content-Type": "application/json"},
                      method="POST" if data is not None else "GET")
        with OPENER.open(req, timeout=timeout) as r:
            return json.loads(r.read(MAX_BODY).decode("utf-8") or "{}")

    def envelope(self, kind: str, **kw) -> dict:
        env = {"from": self.profile["id"], "name": self.profile["name"], "fp": self.p2p_port,
               "st": self.public_status(), "kind": kind}
        env.update(kw)
        return env

    def fire(self, pid: str, env: dict):
        """Envio sem fila (digitando, confirmação de leitura, reação)."""
        c = self.contacts.get(pid)
        if not c or not c.get("host"):
            return

        def run():
            try:
                self.peer_call(c, "/p2p/msg", env, timeout=4)
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()

    def new_msg(self, pid: str, kind: str, **kw) -> dict:
        m = {"id": uuid.uuid4().hex, "peer": pid, "dir": "out", "kind": kind, "ts": now(),
             "state": "sending"}
        m.update(kw)
        return m

    def send(self, pid: str, kind: str, **kw) -> dict:
        self.require_contact(pid)
        m = self.new_msg(pid, kind, **kw)
        self.add_msg(pid, m)
        self.emit("message", m)
        threading.Thread(target=self.deliver, args=(pid, m["id"]), daemon=True).start()
        return m

    def send_text(self, pid: str, text: str) -> dict:
        text = str(text or "").strip()[:MAX_TEXT]
        if not text:
            raise ValueError("Mensagem vazia")
        return self.send(pid, "text", text=text)

    def send_file(self, pid: str, name: str, b64: str) -> dict:
        raw = base64.b64decode(b64 or "", validate=True)
        if len(raw) > MAX_FILE:
            raise ValueError("Arquivo maior que 25 MB")
        path = unique_path(self.sent_dir, safe_name(name))
        path.write_bytes(raw)
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        return self.send(pid, "file", file={"name": path.name, "size": len(raw), "mime": mime,
                                            "path": str(path)})

    def deliver(self, pid: str, mid: str):
        with self.lock:
            if mid in self.delivering:
                return
            self.delivering.add(mid)
        try:
            m = self.find_msg(pid, mid)
            c = self.contacts.get(pid)
            if not m or not c:
                return
            env = self.envelope(m["kind"], id=m["id"], ts=m["ts"])
            if m["kind"] == "text":
                env["text"] = m["text"]
            elif m["kind"] == "file":
                f = m["file"]
                try:
                    data = Path(f["path"]).read_bytes()
                except OSError:
                    self.update_msg(pid, mid, state="failed")
                    return
                env["file"] = {"name": f["name"], "size": f["size"], "mime": f["mime"],
                               "data": base64.b64encode(data).decode()}
            ok = False
            if c.get("host") and not c.get("blocked"):
                try:
                    ok = bool(self.peer_call(c, "/p2p/msg", env,
                                             timeout=120 if m["kind"] == "file" else 6).get("ok"))
                except Exception:
                    ok = False
            if ok:
                if m.get("state") != "read":
                    self.update_msg(pid, mid, state="sent")
            else:
                # texto e arquivos ficam na fila e saem quando o contato aparecer
                self.update_msg(pid, mid, state="failed" if m["kind"] == "nudge" else "pending")
        finally:
            with self.lock:
                self.delivering.discard(mid)

    def flush_pending(self, pid: str):
        with self.lock:
            ids = [m["id"] for m in self.history(pid) if m.get("dir") == "out" and m.get("state") == "pending"]
        for mid in ids:
            threading.Thread(target=self.deliver, args=(pid, mid), daemon=True).start()

    def mark_read(self, pid: str):
        with self.lock:
            c = self.require_contact(pid)
            ids = []
            for m in self.history(pid):
                if m.get("dir") == "in" and m.get("state") == "received":
                    m["state"] = "read"
                    ids.append(m["id"])
            if ids:
                self.save_history(pid)
            changed = c.get("unread", 0) != 0
            c["unread"] = 0
            if changed:
                self.save_contacts()
            view = self.contact_view(c)
        if changed:
            self.emit("contact", view)
        if ids:
            self.fire(pid, self.envelope("read", ids=ids[-500:]))

    def react(self, pid: str, mid: str, emoji: str):
        emoji = str(emoji or "")[:8]
        with self.lock:
            m = self.find_msg(pid, mid)
            if not m:
                raise ValueError("Mensagem não encontrada")
            r = dict(m.get("reactions") or {})
            if emoji:
                r["me"] = emoji
            else:
                r.pop("me", None)
        self.update_msg(pid, mid, reactions=r)
        self.fire(pid, self.envelope("react", target=mid, emoji=emoji))

    def clear_history(self, pid: str):
        with self.lock:
            self.histories[pid] = []
            self.save_history(pid)

    def search(self, q: str) -> list:
        q = q.lower().strip()
        out = []
        if len(q) < 2:
            return out
        for f in sorted(self.hist_dir.glob("*.json")):
            pid = f.stem
            for m in reversed(self.history(pid)):
                txt = m.get("text") or (m.get("file") or {}).get("name") or ""
                if q in txt.lower():
                    out.append({"peer": pid, "id": m["id"], "text": txt[:160], "ts": m["ts"], "dir": m["dir"]})
                    if len(out) >= 80:
                        return sorted(out, key=lambda x: -x["ts"])
        return sorted(out, key=lambda x: -x["ts"])

    # ------------------------------------------------------- recebimento P2P
    def receive(self, env: dict, host: str) -> dict:
        pid = str(env.get("from", ""))[:64]
        if not pid or pid == self.profile["id"]:
            return {"ok": False}
        kind = env.get("kind")
        with self.lock:
            c = self.contacts.get(pid)
            new = c is None
            if new:
                c = self.contacts[pid] = self.new_contact(pid)
                c["name"] = str(env.get("name", ""))[:80] or host
            self._set_host(c, host)
            try:
                c["port"] = int(env.get("fp", c["port"]))
            except (TypeError, ValueError):
                pass
            st = env.get("st")
            if st in PEER_STATUSES:
                c["status"] = st
                if st != "offline":
                    c["last_seen"] = c["seen_at"] = now()
            if kind in ("text", "nudge", "file"):
                c["hidden"] = False
            if new:
                self.save_contacts()
            blocked = c.get("blocked")
            view = self.contact_view(c)
        if new:
            self.emit("contact", view)
            threading.Thread(target=self.fetch_avatar, args=(pid,), daemon=True).start()
        self.check_online(pid)
        if blocked:
            return {"ok": True}

        if kind == "typing":
            self.emit("typing", {"id": pid})
        elif kind in ("text", "nudge", "file"):
            mid = re.sub(r"[^0-9a-zA-Z]", "", str(env.get("id") or ""))[:64] or uuid.uuid4().hex
            if self.find_msg(pid, mid):
                return {"ok": True}  # duplicada (reenvio da fila)
            m = {"id": mid, "peer": pid, "dir": "in", "kind": kind, "ts": now(), "state": "received"}
            if kind == "text":
                m["text"] = str(env.get("text", ""))[:MAX_TEXT]
            elif kind == "file":
                f = env.get("file") or {}
                try:
                    raw = base64.b64decode(f.get("data", ""), validate=True)
                except Exception:
                    return {"ok": False}
                if len(raw) > MAX_FILE:
                    return {"ok": False}
                path = unique_path(self.recv_dir, safe_name(f.get("name", "arquivo")))
                path.write_bytes(raw)
                m["file"] = {"name": path.name, "size": len(raw),
                             "mime": mimetypes.guess_type(path.name)[0] or "application/octet-stream",
                             "path": str(path)}
            self.add_msg(pid, m)
            with self.lock:
                c["unread"] = c.get("unread", 0) + 1
                self.save_contacts()
                view = self.contact_view(c)
            self.emit("message", m)
            self.emit("contact", view)
            if kind == "nudge":
                self.emit("nudge", {"id": pid})
        elif kind == "read":
            ids = env.get("ids") if isinstance(env.get("ids"), list) else []
            for mid in ids[:500]:
                m = self.find_msg(pid, str(mid))
                if m and m.get("dir") == "out" and m.get("state") != "read":
                    self.update_msg(pid, m["id"], state="read")
        elif kind == "react":
            m = self.find_msg(pid, str(env.get("target", "")))
            if m:
                r = dict(m.get("reactions") or {})
                emoji = str(env.get("emoji") or "")[:8]
                if emoji:
                    r[pid] = emoji
                else:
                    r.pop(pid, None)
                self.update_msg(pid, m["id"], reactions=r)
        return {"ok": True}

    # ----------------------------------------------------------- descoberta
    def start_discovery(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        try:
            s.bind(("", DISCOVERY_PORT))
        except OSError as exc:
            print(f"Aviso: porta de descoberta {DISCOVERY_PORT} indisponível ({exc}); "
                  "use 'Adicionar por endereço'.")
            s.bind(("", 0))
        s.settimeout(1.0)
        self.udp = s
        threading.Thread(target=self._udp_recv, daemon=True).start()
        threading.Thread(target=self._udp_announce_loop, daemon=True).start()
        threading.Thread(target=self._watchdog, daemon=True).start()

    def announce(self, status: str | None = None):
        if not self.udp:
            return
        pkt = self.public()
        if status:
            pkt["status"] = status
        data = json.dumps(pkt).encode("utf-8")
        targets = {"255.255.255.255", "127.0.0.1"}
        for ip in local_ips():
            parts = ip.split(".")
            if len(parts) == 4:
                targets.add(".".join(parts[:3] + ["255"]))
        with self.lock:
            for c in self.contacts.values():
                if c.get("host") and ":" not in c["host"] and not c.get("blocked"):
                    targets.add(c["host"])
        for t in targets:
            try:
                self.udp.sendto(data, (t, DISCOVERY_PORT))
            except OSError:
                pass

    def _udp_announce_loop(self):
        while self.running:
            self.announce()
            for _ in range(PRESENCE_EVERY * 4):
                if not self.running:
                    return
                time.sleep(0.25)

    def _udp_recv(self):
        while self.running:
            try:
                data, addr = self.udp.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                if not self.running:
                    return
                continue  # Windows: ICMP "port unreachable" vira ConnectionResetError
            try:
                pkt = json.loads(data.decode("utf-8"))
            except Exception:
                continue
            if isinstance(pkt, dict) and pkt.get("app") == "aura":
                self.handle_presence(pkt, addr[0])

    def _watchdog(self):
        tick = 0
        while self.running:
            time.sleep(2)
            tick += 1
            for pid in list(self.contacts):
                self.check_online(pid)
            if tick % 15 == 0:  # a cada ~30 s tenta de novo a fila de quem está online
                for pid in list(self.online):
                    self.flush_pending(pid)

    def shutdown(self):
        if not self.running:
            return
        self.running = False
        for _ in range(2):
            self.announce("offline")
            time.sleep(0.1)
        self.emit("bye", {})
        try:
            if self.udp:
                self.udp.close()
        except OSError:
            pass


# ------------------------------------------------------------ servidores HTTP
class Server(ThreadingHTTPServer):
    daemon_threads = True
    # No Windows SO_REUSEADDR deixa dois processos "dividirem" a mesma porta TCP.
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class BaseHandler(BaseHTTPRequestHandler):
    app: Messenger
    server_version = "AURA/" + VERSION

    def log_message(self, *args):
        pass

    def send_json(self, obj, code: int = 200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise ValueError("Conteúdo grande demais")
        raw = self.rfile.read(n) if n else b"{}"
        data = json.loads(raw.decode("utf-8") or "{}")
        if not isinstance(data, dict):
            raise ValueError("JSON inválido")
        return data


class P2PHandler(BaseHandler):
    """Porta aberta para a rede: só fala o protocolo entre mensageiros."""

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/p2p/hello":
            self.send_json(self.app.public())
        elif path == "/p2p/avatar":
            invisible = self.app.profile["status"] == "invisible"
            self.send_json({"avatar": "" if invisible else self.app.profile.get("avatar", ""),
                            "ah": self.app.avatar_hash()})
        else:
            self.send_json({"error": "não encontrado"}, 404)

    def do_POST(self):
        if urlparse(self.path).path != "/p2p/msg":
            return self.send_json({"error": "não encontrado"}, 404)
        try:
            env = self.read_body()
            self.send_json(self.app.receive(env, self.client_address[0]))
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)


class UIHandler(BaseHandler):
    """Porta local (127.0.0.1) que serve a interface e a API protegida por token."""
    token = ""
    STATIC = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
              ".js": "application/javascript; charset=utf-8", ".svg": "image/svg+xml",
              ".png": "image/png", ".ico": "image/x-icon"}

    def authed(self, q) -> bool:
        tok = self.headers.get("X-Token") or (q.get("t") or [""])[0]
        return secrets.compare_digest(tok, self.token)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if not u.path.startswith("/api/"):
            return self.static(u.path)
        if not self.authed(q):
            return self.send_json({"error": "não autorizado"}, 403)
        app = self.app
        try:
            if u.path == "/api/ping":
                self.send_json({"ok": True})
            elif u.path == "/api/state":
                with app.lock:
                    contacts = [app.contact_view(c) for c in app.contacts.values()]
                self.send_json({"me": app.profile, "contacts": contacts, "version": VERSION,
                                "addresses": [f"{ip}:{app.p2p_port}" for ip in local_ips()],
                                "downloads": str(app.recv_dir), "platform": sys.platform})
            elif u.path == "/api/history":
                pid = q.get("peer", [""])[0]
                with app.lock:
                    msgs = list(app.history(pid))[-1500:]
                self.send_json({"messages": msgs})
            elif u.path == "/api/search":
                self.send_json({"results": app.search(q.get("q", [""])[0])})
            elif u.path == "/api/events":
                self.events()
            elif u.path == "/api/download":
                self.download(q.get("peer", [""])[0], q.get("mid", [""])[0])
            else:
                self.send_json({"error": "não encontrado"}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        u = urlparse(self.path)
        if not self.authed(parse_qs(u.query)):
            return self.send_json({"error": "não autorizado"}, 403)
        app = self.app
        try:
            d = self.read_body()
            peer = str(d.get("peer", ""))
            r: object = {"ok": True}
            if u.path == "/api/profile":
                r = app.update_profile(d)
            elif u.path == "/api/send":
                r = app.send_text(peer, d.get("text", ""))
            elif u.path == "/api/file":
                r = app.send_file(peer, d.get("name", "arquivo"), d.get("data", ""))
            elif u.path == "/api/nudge":
                r = app.send(peer, "nudge")
            elif u.path == "/api/typing":
                app.require_contact(peer)
                app.fire(peer, app.envelope("typing"))
            elif u.path == "/api/read":
                app.mark_read(peer)
            elif u.path == "/api/react":
                app.react(peer, str(d.get("mid", "")), d.get("emoji", ""))
            elif u.path == "/api/contacts/add":
                r = app.add_by_address(str(d.get("address", "")))
            elif u.path == "/api/contacts/update":
                r = app.update_contact(peer, d)
            elif u.path == "/api/history/clear":
                app.clear_history(peer)
            elif u.path == "/api/reveal":
                m = app.find_msg(peer, str(d.get("mid", "")))
                if m and m.get("file"):
                    open_path(Path(m["file"]["path"]), select=True)
            elif u.path == "/api/openfolder":
                app.recv_dir.mkdir(parents=True, exist_ok=True)
                open_path(app.recv_dir)
            elif u.path == "/api/quit":
                threading.Thread(target=app.shutdown, daemon=True).start()
            else:
                return self.send_json({"error": "não encontrado"}, 404)
            self.send_json(r)
        except ValueError as exc:
            self.send_json({"error": str(exc)}, 400)
        except Exception as exc:  # pragma: no cover
            self.send_json({"error": f"Erro interno: {exc}"}, 500)

    def static(self, path: str):
        name = "index.html" if path in ("/", "") else path.lstrip("/")
        f = (WEB_DIR / name).resolve()
        if WEB_DIR.resolve() not in f.parents or not f.is_file():
            return self.send_json({"error": "não encontrado"}, 404)
        body = f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", self.STATIC.get(f.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)

    def download(self, peer: str, mid: str):
        m = self.app.find_msg(peer, mid)
        if not m or not m.get("file"):
            return self.send_json({"error": "não encontrado"}, 404)
        p = Path(m["file"]["path"])
        if not p.is_file():
            return self.send_json({"error": "O arquivo foi movido ou apagado"}, 404)
        self.send_response(200)
        self.send_header("Content-Type", m["file"].get("mime") or "application/octet-stream")
        self.send_header("Content-Length", str(p.stat().st_size))
        self.send_header("Content-Disposition", f"inline; filename*=UTF-8''{quote(p.name)}")
        self.end_headers()
        with p.open("rb") as fh:
            shutil.copyfileobj(fh, self.wfile)

    def events(self):
        app = self.app
        q: queue.Queue = queue.Queue()
        app.listeners.append(q)
        app.had_client = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(b"retry: 1500\nevent: hello\ndata: {}\n\n")
            self.wfile.flush()
            while app.running:
                try:
                    kind, data = q.get(timeout=15)
                    chunk = f"event: {kind}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
                except queue.Empty:
                    chunk = ": ping\n\n"
                self.wfile.write(chunk.encode("utf-8"))
                self.wfile.flush()
            self.wfile.write(b"event: bye\ndata: {}\n\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        finally:
            if q in app.listeners:
                app.listeners.remove(q)
            app.last_client = now()


# ---------------------------------------------------------------- janela
def find_app_browser() -> str | None:
    if os.name == "nt":
        roots = [os.environ.get(k) for k in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA")]
        rel = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe",
               r"BraveSoftware\Brave-Browser\Application\brave.exe", r"Chromium\Application\chrome.exe"]
        for r in rel:
            for root in roots:
                if root and Path(root, r).is_file():
                    return str(Path(root, r))
        return None
    for exe in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable",
                "brave-browser", "microsoft-edge", "microsoft-edge-stable", "vivaldi-stable"):
        p = shutil.which(exe)
        if p:
            return p
    return None


def open_window(url: str, profile_dir: Path) -> None:
    exe = find_app_browser()
    if exe:
        try:
            subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile_dir}",
                              "--no-first-run", "--no-default-browser-check",
                              "--window-size=1120,740", "--disable-features=Translate"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except OSError:
            pass
    webbrowser.open(url)


# ------------------------------------------------------------------ ícones
def make_icon_png(size: int) -> bytes:
    """Desenha o ícone (gradiente aura + balão) sem bibliotecas externas."""
    stops = [(0.0, (59, 130, 246)), (0.55, (139, 92, 246)), (1.0, (20, 184, 166))]

    def grad(t):
        for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
            if t <= t1:
                k = (t - t0) / (t1 - t0)
                return tuple(c0[i] + (c1[i] - c0[i]) * k for i in range(3))
        return stops[-1][1]

    def sample(x, y):
        r = 0.22
        dx = max(r - x, 0, x - (1 - r))
        dy = max(r - y, 0, y - (1 - r))
        if dx * dx + dy * dy > r * r:
            return None
        bg = grad((x + y) / 2)
        ex, ey = (x - 0.5) / 0.31, (y - 0.46) / 0.235
        in_bubble = ex * ex + ey * ey <= 1
        # cauda do balão
        if not in_bubble and 0.27 <= x <= 0.45 and 0.62 <= y <= 0.82:
            in_bubble = (y - 0.62) <= (0.45 - x) * 1.1 and x >= 0.27 + (y - 0.62) * 0.2
        if in_bubble:
            dots = any(((x - cx) ** 2 + (y - 0.46) ** 2) <= 0.045 ** 2 for cx in (0.38, 0.5, 0.62))
            return bg if dots else (255, 255, 255)
        return bg

    ss = 3
    rows = []
    for py in range(size):
        row = bytearray([0])
        for px in range(size):
            acc = [0.0, 0.0, 0.0]
            a = 0
            for sy in range(ss):
                for sx in range(ss):
                    c = sample((px + (sx + 0.5) / ss) / size, (py + (sy + 0.5) / ss) / size)
                    if c:
                        a += 1
                        for i in range(3):
                            acc[i] += c[i]
            if a:
                row += bytes([int(acc[0] / a), int(acc[1] / a), int(acc[2] / a), int(255 * a / (ss * ss))])
            else:
                row += b"\0\0\0\0"
        rows.append(bytes(row))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))


def generate_icons(folder: Path) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    pngs = {s: make_icon_png(s) for s in (16, 32, 48, 256)}
    (folder / "icone.png").write_bytes(pngs[256])
    header = struct.pack("<HHH", 0, 1, len(pngs))
    entries, data, offset = b"", b"", 6 + 16 * len(pngs)
    for s, png in pngs.items():
        entries += struct.pack("<BBBBHHII", s % 256, s % 256, 0, 0, 1, 32, len(png), offset)
        data += png
        offset += len(png)
    (folder / "icone.ico").write_bytes(header + entries + data)
    print("Ícones gerados em", folder)


# ------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=f"{APP_NAME} {VERSION}")
    ap.add_argument("--perfil", default="padrao", help="nome do perfil (várias contas no mesmo PC)")
    ap.add_argument("--porta", type=int, default=P2P_PORT, help="porta TCP para os contatos (padrão 47101)")
    ap.add_argument("--sem-janela", action="store_true", help="não abre a janela, só mostra o endereço")
    ap.add_argument("--manter-aberto", action="store_true", help="não encerra ao fechar a janela")
    ap.add_argument("--gerar-icones", action="store_true", help="gera icone.png e icone.ico e sai")
    args = ap.parse_args()

    if args.gerar_icones:
        return generate_icons(WEB_DIR)

    app = Messenger(args.perfil, args.porta)

    if sys.stdout is None or sys.stderr is None:  # pythonw no Windows: registra em arquivo
        log = open(app.root / "aura.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = log

    # instância única por perfil: se já está aberto, só mostra a janela
    rt_file = app.root / "execucao.json"
    rt = read_json(rt_file, {})
    if rt.get("port") and rt.get("token"):
        try:
            req = Request(f"http://127.0.0.1:{rt['port']}/api/ping", headers={"X-Token": rt["token"]})
            with OPENER.open(req, timeout=2) as r:
                if json.loads(r.read()).get("ok"):
                    url = f"http://127.0.0.1:{rt['port']}/?t={rt['token']}"
                    print("O AURA já está aberto:", url)
                    if not args.sem_janela:
                        open_window(url, app.root / "janela")
                    return
        except Exception:
            pass

    P2PHandler.app = app
    p2p = None
    for port in range(args.porta, args.porta + 20):
        try:
            p2p = Server(("0.0.0.0", port), P2PHandler)
            break
        except OSError:
            continue
    if not p2p:
        sys.exit("Nenhuma porta livre entre %d e %d" % (args.porta, args.porta + 19))
    app.p2p_port = p2p.server_address[1]

    UIHandler.app = app
    UIHandler.token = secrets.token_urlsafe(24)
    ui = Server(("127.0.0.1", 0), UIHandler)
    ui_port = ui.server_address[1]
    write_json(rt_file, {"port": ui_port, "token": UIHandler.token, "pid": os.getpid()})

    threading.Thread(target=p2p.serve_forever, daemon=True).start()
    threading.Thread(target=ui.serve_forever, daemon=True).start()
    app.start_discovery()

    url = f"http://127.0.0.1:{ui_port}/?t={UIHandler.token}"
    print(f"{APP_NAME} {VERSION} — perfil '{args.perfil}'")
    print(f"  Seus contatos te acham em: {', '.join(f'{ip}:{app.p2p_port}' for ip in local_ips())}")
    print(f"  Interface: {url}")
    if not args.sem_janela:
        open_window(url, app.root / "janela")

    keep = args.manter_aberto or args.sem_janela
    try:
        while app.running:
            time.sleep(0.5)
            if not keep and app.had_client and not app.listeners and now() - app.last_client > 25:
                print("Janela fechada — encerrando.")
                break
    except KeyboardInterrupt:
        pass
    finally:
        app.shutdown()
        time.sleep(0.3)
        try:
            rt_file.unlink()
        except OSError:
            pass
        p2p.shutdown()
        ui.shutdown()


if __name__ == "__main__":
    main()
