<?php
/* AURA MSN — API usada pelo aplicativo. Todas as respostas são JSON. */
declare(strict_types=1);
require __DIR__ . '/lib.php';

const KINDS_TO_PEER = ['text', 'nudge', 'typing', 'read', 'react'];

$a = preg_replace('/[^a-z_]/', '', (string)($_GET['a'] ?? ''));
try {
    $fn = 'act_' . $a;
    if ($a === '' || !function_exists($fn)) fail('Ação desconhecida', 404);
    $r = $fn();
    if (is_array($r)) out($r);
} catch (ApiError $e) {
    out(['error' => $e->getMessage()] + $e->extra, $e->status);
} catch (PDOException $e) {
    error_log('AURA db: ' . $e->getMessage());
    out(['error' => 'Erro no banco de dados do servidor.'], 500);
} catch (Throwable $e) {
    error_log('AURA: ' . $e->getMessage());
    out(['error' => 'Erro interno do servidor.'], 500);
}

/* ================================================================ público */
function act_info(): array {
    return ['ok' => true, 'app' => 'aura-server', 'version' => AURA_SERVER_VERSION,
            'google' => (bool)(cfg('google_client_id') && cfg('google_client_secret')),
            'max_file' => (int)cfg('max_file_mb', 25) * 1048576, 'time' => time()];
}

function act_register(): array {
    $d = body();
    $email = norm_email(str_in($d, 'email', 190));
    $pass = (string)($d['password'] ?? '');
    $name = str_in($d, 'name', 80);
    if (!valid_email($email)) fail('E-mail inválido.');
    if (mb_strlen($pass) < 8) fail('A senha precisa ter pelo menos 8 caracteres.');
    if (mb_strlen($pass) > 200) fail('Senha longa demais.');
    if ($name === '') $name = explode('@', $email)[0];
    guard('reg:' . client_ip(), 10, 3600);

    $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
    if ($u && $u['verified']) fail('Já existe uma conta com esse e-mail. Use "Entrar" ou "Esqueci minha senha".', 409);
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    if ($u) {   // conta criada mas nunca confirmada: atualiza e manda outro código
        q('UPDATE aura_users SET pass_hash = ?, name = ? WHERE id = ?', [$hash, $name, $u['id']]);
    } else {
        q('INSERT INTO aura_users (email, pass_hash, name, created) VALUES (?, ?, ?, ?)', [$email, $hash, $name, time()]);
    }
    $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
    send_code($u, 'verify');
    return ['ok' => true, 'need_verify' => true, 'email' => $email];
}

function act_verify(): array {
    $d = body();
    $email = norm_email(str_in($d, 'email', 190));
    guard('code:' . client_ip(), 30, 900);
    $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
    if (!$u) fail('Conta não encontrada.');
    check_code($u, 'verify', str_in($d, 'code', 20));
    q('UPDATE aura_users SET verified = 1 WHERE id = ?', [$u['id']]);
    $u['verified'] = 1;
    return login_result($u, str_in($d, 'device', 80));
}

function act_resend(): array {
    $email = norm_email(str_in(body(), 'email', 190));
    $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
    if ($u && !$u['verified']) send_code($u, 'verify');
    return ['ok' => true];
}

function act_login(): array {
    $d = body();
    $email = norm_email(str_in($d, 'email', 190));
    $pass = (string)($d['password'] ?? '');
    if (too_many('login:' . $email, 8, 900) || too_many('loginip:' . client_ip(), 30, 900)) {
        fail('Muitas tentativas erradas. Espere 15 minutos ou use "Esqueci minha senha".', 429);
    }
    $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
    if (!$u || !$u['pass_hash'] || !password_verify($pass, $u['pass_hash'])) {
        hit('login:' . $email);
        hit('loginip:' . client_ip());
        if ($u && !$u['pass_hash'] && $u['google_sub']) fail('Essa conta foi criada com o Google. Use "Entrar com Google".');
        fail('E-mail ou senha incorretos.');
    }
    if (password_needs_rehash($u['pass_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE aura_users SET pass_hash = ? WHERE id = ?', [password_hash($pass, PASSWORD_DEFAULT), $u['id']]);
    }
    if (!$u['verified']) {
        send_code($u, 'verify');
        return ['ok' => true, 'need_verify' => true, 'email' => $email];
    }
    return login_result($u, str_in($d, 'device', 80));
}

function act_forgot(): array {
    $email = norm_email(str_in(body(), 'email', 190));
    guard('forgot:' . client_ip(), 10, 3600);
    $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
    if ($u) send_code($u, 'reset');
    // responde igual mesmo se a conta não existir, para não revelar quem está cadastrado
    return ['ok' => true];
}

function act_reset(): array {
    $d = body();
    $email = norm_email(str_in($d, 'email', 190));
    $pass = (string)($d['password'] ?? '');
    if (mb_strlen($pass) < 8) fail('A senha precisa ter pelo menos 8 caracteres.');
    guard('code:' . client_ip(), 30, 900);
    $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
    if (!$u) fail('Código incorreto.');
    check_code($u, 'reset', str_in($d, 'code', 20));
    q('UPDATE aura_users SET pass_hash = ?, verified = 1 WHERE id = ?', [password_hash($pass, PASSWORD_DEFAULT), $u['id']]);
    q('DELETE FROM aura_sessions WHERE user_id = ?', [$u['id']]);   // derruba as sessões antigas
    return login_result(row('SELECT * FROM aura_users WHERE id = ?', [$u['id']]), str_in($d, 'device', 80));
}

function act_google_ticket(): array {
    $d = body();
    $t = str_in($d, 'ticket', 100);
    guard('ticket:' . client_ip(), 30, 900);
    $row = row('SELECT * FROM aura_tickets WHERE ticket_hash = ?', [token_hash($t)]);
    if (!$row || (int)$row['expires'] < time()) fail('O login com o Google expirou. Tente de novo.');
    q('DELETE FROM aura_tickets WHERE ticket_hash = ?', [$row['ticket_hash']]);
    return login_result(row('SELECT * FROM aura_users WHERE id = ?', [$row['user_id']]), str_in($d, 'device', 80));
}

/* ============================================================ autenticado */
function act_logout(): array {
    $u = current_user();
    q('DELETE FROM aura_sessions WHERE token_hash = ?', [$u['token_hash']]);
    if ((int)val('SELECT COUNT(*) FROM aura_sessions WHERE user_id = ?', [$u['id']]) === 0) {
        q('UPDATE aura_users SET last_seen = 0 WHERE id = ?', [$u['id']]);
    }
    return ['ok' => true];
}

function act_offline(): array {   // janela fechada: some da lista na hora, sem esperar o tempo limite
    $u = current_user();
    q('UPDATE aura_users SET last_seen = 0 WHERE id = ?', [$u['id']]);
    return ['ok' => true];
}

function act_me(): array { return ['ok' => true, 'user' => user_public(current_user())]; }

function act_profile(): array {
    $u = current_user();
    $d = body();
    $set = [];
    $args = [];
    if (array_key_exists('name', $d)) { $n = str_in($d, 'name', 80); if ($n !== '') { $set[] = 'name = ?'; $args[] = $n; } }
    if (array_key_exists('psm', $d)) { $set[] = 'psm = ?'; $args[] = str_in($d, 'psm', 200); }
    if (in_array($d['status'] ?? null, ['online', 'away', 'busy', 'invisible'], true)) { $set[] = 'status = ?'; $args[] = $d['status']; }
    if (array_key_exists('avatar', $d)) {
        $av = (string)($d['avatar'] ?? '');
        if ($av !== '' && (strpos($av, 'data:image/') !== 0 || strlen($av) > 400 * 1024)) fail('Imagem de perfil inválida ou grande demais.');
        $set[] = 'avatar = ?'; $args[] = $av;
        $set[] = 'avatar_hash = ?'; $args[] = $av === '' ? '' : substr(sha1($av), 0, 12);
    }
    if ($set) {
        $args[] = $u['id'];
        q('UPDATE aura_users SET ' . implode(', ', $set) . ' WHERE id = ?', $args);
    }
    return ['ok' => true, 'user' => user_public(row('SELECT * FROM aura_users WHERE id = ?', [$u['id']]))];
}

function presence(array $c): string {
    if ((int)$c['last_seen'] < time() - ONLINE_TTL || $c['status'] === 'invisible') return 'offline';
    return in_array($c['status'], ['online', 'away', 'busy'], true) ? $c['status'] : 'online';
}

function contacts_of(int $uid): array {
    $rows = q('SELECT c.state, c.blocked, u.id, u.email, u.name, u.psm, u.status, u.avatar_hash, u.last_seen, u.seen_public
               FROM aura_contacts c JOIN aura_users u ON u.id = c.contact WHERE c.owner = ?', [$uid])->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $accepted = $r['state'] === 'ok';
        $out[] = [
            'id' => (int)$r['id'], 'email' => $r['email'], 'name' => $r['name'],
            // quem ainda não aceitou não vê seu status nem sua mensagem pessoal
            'psm' => $accepted ? $r['psm'] : '',
            'status' => $accepted ? presence($r) : 'offline',
            'ah' => $accepted ? $r['avatar_hash'] : '',
            'seen_at' => $accepted ? (int)$r['seen_public'] : 0,
            'state' => $r['state'], 'blocked' => (bool)$r['blocked'],
        ];
    }
    return $out;
}

function act_poll(): array {
    $u = current_user();
    $d = body();
    $now = time();
    $cursor = max(0, (int)($d['cursor'] ?? 0));
    $fields = ['last_seen = ?'];
    $args = [$now];
    if (in_array($d['status'] ?? null, ['online', 'away', 'busy', 'invisible'], true)) { $fields[] = 'status = ?'; $args[] = $d['status']; $u['status'] = $d['status']; }
    if ($u['status'] !== 'invisible') { $fields[] = 'seen_public = ?'; $args[] = $now; }
    $args[] = $u['id'];
    q('UPDATE aura_users SET ' . implode(', ', $fields) . ' WHERE id = ?', $args);
    if (random_int(1, 20) === 1) q('UPDATE aura_sessions SET last_used = ? WHERE token_hash = ?', [$now, $u['token_hash']]);

    $events = [];
    $rows = q('SELECT id, from_id, kind, payload, created FROM aura_events WHERE user_id = ? AND id > ? ORDER BY id LIMIT 300',
              [$u['id'], $cursor])->fetchAll();
    foreach ($rows as $r) {
        if ($r['kind'] === 'typing' && (int)$r['created'] < $now - 15) { $cursor = (int)$r['id']; continue; }
        $events[] = ['id' => (int)$r['id'], 'from' => (int)$r['from_id'], 'kind' => $r['kind'],
                     'data' => json_decode($r['payload'], true) ?: [], 'ts' => (int)$r['created']];
        $cursor = (int)$r['id'];
    }
    $more = count($rows) === 300;
    if (!$rows && $cursor === 0) {
        // aparelho novo e nada para sincronizar: começa do último evento
        $cursor = (int)(val('SELECT MAX(id) FROM aura_events WHERE user_id = ?', [$u['id']]) ?? 0);
    }
    maybe_cleanup();
    return ['ok' => true, 'cursor' => $cursor, 'more' => $more, 'events' => $events,
            'contacts' => contacts_of((int)$u['id']), 'time' => $now];
}

function push_event(int $to, int $from, string $kind, array $data): void {
    q('INSERT INTO aura_events (user_id, from_id, kind, payload, created) VALUES (?, ?, ?, ?, ?)',
      [$to, $from, $kind, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), time()]);
}

function contact_id(array $d, string $key = 'id'): int {
    $id = (int)preg_replace('/\D/', '', (string)($d[$key] ?? ''));
    if ($id <= 0) fail('Contato inválido.');
    return $id;
}

/* ---------------------------------------------------------------- contatos */
function act_contact_add(): array {
    $u = current_user();
    $email = norm_email(str_in(body(), 'email', 190));
    if (!valid_email($email)) fail('E-mail inválido.');
    if ($email === $u['email']) fail('Esse é o seu próprio e-mail 🙂');
    guard('add:' . $u['id'], 40, 3600);
    $t = row('SELECT * FROM aura_users WHERE email = ? AND verified = 1', [$email]);
    if (!$t) fail('Ainda não existe ninguém com esse e-mail no AURA MSN.', 404, ['not_found' => true]);
    $mine = row('SELECT * FROM aura_contacts WHERE owner = ? AND contact = ?', [$u['id'], $t['id']]);
    if ($mine && $mine['state'] === 'ok') fail('Essa pessoa já está na sua lista.');
    if ($mine && $mine['state'] === 'in') {   // ela já tinha me convidado: aceita direto
        return act_contact_answer_inner($u, (int)$t['id'], true);
    }
    $theirs = row('SELECT * FROM aura_contacts WHERE owner = ? AND contact = ?', [$t['id'], $u['id']]);
    q('REPLACE INTO aura_contacts (owner, contact, state, blocked, created) VALUES (?, ?, "out", 0, ?)', [$u['id'], $t['id'], time()]);
    if (!$theirs) {
        q('INSERT INTO aura_contacts (owner, contact, state, blocked, created) VALUES (?, ?, "in", 0, ?)', [$t['id'], $u['id'], time()]);
    } elseif ($theirs['state'] === 'ok' && !$theirs['blocked']) {
        // a outra pessoa ainda me tem na lista (eu tinha removido): volta a ser contato dos dois lados
        q('UPDATE aura_contacts SET state = "ok" WHERE owner = ? AND contact = ?', [$u['id'], $t['id']]);
    }
    push_event((int)$t['id'], (int)$u['id'], 'contacts', []);
    return ['ok' => true, 'contacts' => contacts_of((int)$u['id'])];
}

function act_contact_answer_inner(array $u, int $cid, bool $accept): array {
    $mine = row('SELECT * FROM aura_contacts WHERE owner = ? AND contact = ?', [$u['id'], $cid]);
    if (!$mine) fail('Pedido não encontrado.');
    if ($accept) {
        q('UPDATE aura_contacts SET state = "ok" WHERE owner = ? AND contact = ?', [$u['id'], $cid]);
        q('UPDATE aura_contacts SET state = "ok" WHERE owner = ? AND contact = ? AND state = "out"', [$cid, $u['id']]);
    } else {
        q('DELETE FROM aura_contacts WHERE owner = ? AND contact = ?', [$u['id'], $cid]);
        q('DELETE FROM aura_contacts WHERE owner = ? AND contact = ? AND state = "out"', [$cid, $u['id']]);
    }
    push_event($cid, (int)$u['id'], 'contacts', []);
    return ['ok' => true, 'contacts' => contacts_of((int)$u['id'])];
}
function act_contact_answer(): array {
    $u = current_user();
    $d = body();
    return act_contact_answer_inner($u, contact_id($d), !empty($d['accept']));
}

function act_contact_remove(): array {
    $u = current_user();
    $cid = contact_id(body());
    q('DELETE FROM aura_contacts WHERE owner = ? AND contact = ?', [$u['id'], $cid]);
    q('DELETE FROM aura_contacts WHERE owner = ? AND contact = ? AND state <> "ok"', [$cid, $u['id']]);
    push_event($cid, (int)$u['id'], 'contacts', []);
    return ['ok' => true, 'contacts' => contacts_of((int)$u['id'])];
}

function act_contact_block(): array {
    $u = current_user();
    $d = body();
    q('UPDATE aura_contacts SET blocked = ? WHERE owner = ? AND contact = ?', [empty($d['blocked']) ? 0 : 1, $u['id'], contact_id($d)]);
    return ['ok' => true];
}

function act_invite(): array {   // convida por e-mail quem ainda não tem conta
    $u = current_user();
    $email = norm_email(str_in(body(), 'email', 190));
    if (!valid_email($email)) fail('E-mail inválido.');
    guard('invite:' . $u['id'], 10, 86400, 'Você já mandou muitos convites hoje.');
    guard('invited:' . $email, 2, 86400 * 7, 'Essa pessoa já recebeu um convite nesta semana.');
    $nome = htmlspecialchars($u['name']);
    $site = htmlspecialchars((string)cfg('site_url'));
    $html = mail_layout('Convite', "<p><b>$nome</b> ({$u['email']}) quer conversar com você no <b>AURA MSN</b>, o mensageiro dos anos 2000 de volta em 2026.</p>"
        . "<p>Baixe, crie sua conta com este e-mail e adicione <b>{$u['email']}</b>:</p>"
        . "<p style=\"text-align:center;margin:20px 0\"><a href=\"$site/\" style=\"background:#3b82f6;color:#fff;padding:11px 20px;border-radius:10px;text-decoration:none;font-weight:600\">Baixar o AURA MSN</a></p>");
    $text = "{$u['name']} ({$u['email']}) quer conversar com você no AURA MSN.\nBaixe em " . cfg('site_url') . "/ e adicione {$u['email']}.\n";
    if (!send_mail($email, "{$u['name']} te convidou para o AURA MSN", $html, $text)) fail('Não foi possível enviar o convite.', 500);
    return ['ok' => true];
}

function act_avatar(): array {
    $u = current_user();
    $id = (int)($_GET['id'] ?? 0);
    if ($id !== (int)$u['id'] && !row('SELECT 1 FROM aura_contacts WHERE owner = ? AND contact = ? AND state = "ok"', [$u['id'], $id])) {
        fail('Sem permissão.', 403);
    }
    $r = row('SELECT avatar, avatar_hash FROM aura_users WHERE id = ?', [$id]);
    return ['ok' => true, 'avatar' => $r['avatar'] ?? '', 'ah' => $r['avatar_hash'] ?? ''];
}

/* --------------------------------------------------------------- mensagens */
function require_peer(array $u, int $to): bool {
    $mine = row('SELECT * FROM aura_contacts WHERE owner = ? AND contact = ?', [$u['id'], $to]);
    if (!$mine || $mine['state'] !== 'ok') fail('Essa pessoa ainda não aceitou seu convite.', 403);
    // se o outro lado me bloqueou ou me removeu, finge que entregou (como no MSN)
    $theirs = row('SELECT state, blocked FROM aura_contacts WHERE owner = ? AND contact = ?', [$to, $u['id']]);
    return $theirs && $theirs['state'] === 'ok' && !$theirs['blocked'];
}

function clean_id($v): string { return substr(preg_replace('/[^0-9a-zA-Z]/', '', (string)$v), 0, 64); }

function act_send(): array {
    $u = current_user();
    $d = body();
    $to = contact_id($d, 'to');
    $kind = (string)($d['kind'] ?? '');
    if (!in_array($kind, KINDS_TO_PEER, true)) fail('Tipo de mensagem inválido.');
    $deliver = require_peer($u, $to);
    $data = [];
    if ($kind === 'text' || $kind === 'nudge') {
        $data['id'] = clean_id($d['id'] ?? '') ?: bin2hex(random_bytes(16));
        $data['ts'] = is_numeric($d['ts'] ?? null) ? (float)$d['ts'] : time();
        if ($kind === 'text') {
            $data['text'] = mb_substr((string)($d['text'] ?? ''), 0, MAX_TEXT);
            if (trim($data['text']) === '') fail('Mensagem vazia.');
        } else {
            guard('nudge:' . $u['id'] . ':' . $to, 6, 60, 'Calma! Espere um pouco para chamar a atenção de novo.');
        }
    } elseif ($kind === 'read') {
        $ids = is_array($d['ids'] ?? null) ? array_slice($d['ids'], -500) : [];
        $data['ids'] = array_values(array_filter(array_map('clean_id', $ids)));
        if (!$data['ids']) return ['ok' => true];
    } elseif ($kind === 'react') {
        $data['target'] = clean_id($d['target'] ?? '');
        $data['emoji'] = mb_substr((string)($d['emoji'] ?? ''), 0, 8);
    }
    if ($deliver) push_event($to, (int)$u['id'], $kind, $data);
    if ($kind !== 'typing') {   // cópia para os seus outros computadores
        push_event((int)$u['id'], (int)$u['id'], 'self_' . $kind, $data + ['peer' => $to]);
    }
    return ['ok' => true];
}

/* ---------------------------------------------------------------- arquivos */
function act_file_init(): array {
    $u = current_user();
    $d = body();
    $to = contact_id($d, 'to');
    require_peer($u, $to);
    $size = (int)($d['size'] ?? -1);
    $max = (int)cfg('max_file_mb', 25) * 1048576;
    if ($size < 0 || $size > $max) fail('Arquivo maior que ' . cfg('max_file_mb', 25) . ' MB.');
    guard('file:' . $u['id'], 120, 3600, 'Você enviou muitos arquivos na última hora.');
    if (!is_dir(STORAGE_DIR) || !is_writable(STORAGE_DIR)) fail('A pasta "dados" do servidor não tem permissão de escrita.', 500);
    $name = preg_replace('/[\\\\\/<>:"|?*\x00-\x1f]/u', '_', str_in($d, 'name', 150)) ?: 'arquivo';
    $mime = preg_match('#^[\w.+-]+/[\w.+-]+$#', (string)($d['mime'] ?? '')) ? (string)$d['mime'] : 'application/octet-stream';
    $fid = bin2hex(random_bytes(16));
    q('INSERT INTO aura_files (id, owner, recipient, name, size, mime, created) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [$fid, $u['id'], $to, $name, $size, $mime, time()]);
    file_put_contents(file_path($fid), '');
    return ['ok' => true, 'fid' => $fid, 'chunk' => 1048576];
}

function act_file_chunk(): array {
    $u = current_user();
    $fid = clean_id($_GET['fid'] ?? '');
    $off = (int)($_GET['off'] ?? -1);
    $f = row('SELECT * FROM aura_files WHERE id = ? AND owner = ?', [$fid, $u['id']]);
    if (!$f || $f['complete']) fail('Envio não encontrado.', 404);
    $raw = file_get_contents('php://input', false, null, 0, CHUNK_MAX + 1);
    if ($raw === false || strlen($raw) > CHUNK_MAX) fail('Pedaço grande demais.');
    $path = file_path($fid);
    clearstatcache(true, $path);
    $have = is_file($path) ? filesize($path) : 0;
    if ($off !== $have) return ['ok' => true, 'received' => $have];   // o app reenvia a partir daqui
    if ($have + strlen($raw) > (int)$f['size']) fail('O arquivo ficou maior do que o anunciado.');
    file_put_contents($path, $raw, FILE_APPEND | LOCK_EX);
    clearstatcache(true, $path);
    q('UPDATE aura_files SET received = ? WHERE id = ?', [filesize($path), $fid]);
    return ['ok' => true, 'received' => filesize($path)];
}

function act_file_done(): array {
    $u = current_user();
    $d = body();
    $fid = clean_id($d['fid'] ?? '');
    $f = row('SELECT * FROM aura_files WHERE id = ? AND owner = ?', [$fid, $u['id']]);
    if (!$f) fail('Envio não encontrado.', 404);
    clearstatcache(true, file_path($fid));
    if (!is_file(file_path($fid)) || filesize(file_path($fid)) !== (int)$f['size']) fail('O arquivo chegou incompleto.');
    $deliver = require_peer($u, (int)$f['recipient']);
    if (!$f['complete']) {
        q('UPDATE aura_files SET complete = 1 WHERE id = ?', [$fid]);
        $data = ['id' => clean_id($d['id'] ?? '') ?: $fid, 'ts' => is_numeric($d['ts'] ?? null) ? (float)$d['ts'] : time(),
                 'file' => ['fid' => $fid, 'name' => $f['name'], 'size' => (int)$f['size'], 'mime' => $f['mime']]];
        if ($deliver) push_event((int)$f['recipient'], (int)$u['id'], 'file', $data);
        push_event((int)$u['id'], (int)$u['id'], 'self_file', $data + ['peer' => (int)$f['recipient']]);
    }
    return ['ok' => true];
}

function act_file_get() {
    $u = current_user();
    $fid = clean_id($_GET['fid'] ?? '');
    $f = row('SELECT * FROM aura_files WHERE id = ? AND complete = 1 AND (owner = ? OR recipient = ?)', [$fid, $u['id'], $u['id']]);
    if (!$f || !is_file(file_path($fid))) fail('Arquivo não encontrado (o servidor guarda por ' . cfg('keep_days', 30) . ' dias).', 404);
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . filesize(file_path($fid)));
    header('Cache-Control: no-store');
    readfile(file_path($fid));
    return null;
}
