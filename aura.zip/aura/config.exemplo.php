<?php
/*
 * AURA MSN — configuração do servidor.
 *
 * 1. Renomeie este arquivo para  config.php
 * 2. Preencha os dados do banco MySQL que você criou no cPanel da HostGator
 * 3. Abra  https://SEUSITE/aura/instalar.php  uma vez para criar as tabelas
 */
return [
    // Banco de dados (cPanel → Bancos de dados MySQL). Na HostGator o nome e o
    // usuário costumam começar com o seu usuário do cPanel, ex.: "drimah_aura".
    'db_host' => 'localhost',
    'db_name' => 'USUARIOCPANEL_aura',
    'db_user' => 'USUARIOCPANEL_aura',
    'db_pass' => 'SENHA_DO_BANCO',

    // Endereço público desta pasta, sem barra no final.
    'site_url' => 'https://drimah.com.br/aura',

    // E-mail que envia os códigos de confirmação. Crie essa conta em
    // cPanel → Contas de e-mail, senão muitos provedores mandam para o spam.
    'mail_from' => 'nao-responda@drimah.com.br',
    'mail_name' => 'AURA MSN',

    // "Entrar com Google" (opcional). Deixe vazio para desligar.
    // Veja o passo a passo no arquivo LEIA-ME-SERVIDOR.md.
    'google_client_id'     => '',
    'google_client_secret' => '',

    // Limites
    'max_file_mb'   => 25,   // tamanho máximo de cada arquivo enviado
    'keep_days'     => 30,   // por quantos dias o servidor guarda mensagens e arquivos
];
