<?php
/*
 * AURA MSN — "Entrar com Google".
 *
 * 1. O aplicativo abre o navegador em  google.php?start=1&port=PORTA&state=ALEATORIO
 * 2. Esta página manda para o Google; o Google volta aqui com ?code=...
 * 3. Criamos um "ticket" de uso único e redirecionamos para o próprio computador
 *    (http://127.0.0.1:PORTA/auth/google), onde o AURA troca o ticket por uma sessão.
 * O ticket só chega no computador que iniciou o login, então um link malicioso não
 * consegue roubar a conta de ninguém.
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

$clientId = (string)cfg('google_client_id');
$clientSecret = (string)cfg('google_client_secret');
$redirect = rtrim((string)cfg('site_url'), '/') . '/google.php';

function sign(string $data): string { return b64url(hash_hmac('sha256', $data, secret(), true)); }

function http_post_form(string $url, array $fields): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($fields),
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15]);
    $r = curl_exec($ch);
    curl_close($ch);
    return json_decode((string)$r, true) ?: [];
}
function http_get_json(string $url, string $bearer): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_HTTPHEADER => ["Authorization: Bearer $bearer"],
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15]);
    $r = curl_exec($ch);
    curl_close($ch);
    return json_decode((string)$r, true) ?: [];
}

try {
    if (!$clientId || !$clientSecret) {
        html_page('Google desligado', 'O "Entrar com Google" ainda não foi configurado neste servidor.', false);
        exit;
    }

    /* ------------------------------------------------------ 1) início */
    if (isset($_GET['start'])) {
        $port = (int)($_GET['port'] ?? 0);
        $appState = (string)($_GET['state'] ?? '');
        if ($port < 1024 || $port > 65535 || !preg_match('/^[A-Za-z0-9_-]{16,80}$/', $appState)) {
            html_page('Link inválido', 'Abra o login com o Google pelo próprio AURA MSN.', false);
            exit;
        }
        $nonce = b64url(random_bytes(18));
        $payload = b64url(json_encode(['p' => $port, 's' => $appState, 'n' => $nonce, 't' => time()]));
        $state = $payload . '.' . sign($payload);
        setcookie('aura_g', $nonce, ['expires' => time() + 900, 'path' => '/', 'secure' => true,
                                     'httponly' => true, 'samesite' => 'Lax']);
        $url = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
            'client_id' => $clientId, 'redirect_uri' => $redirect, 'response_type' => 'code',
            'scope' => 'openid email profile', 'state' => $state, 'prompt' => 'select_account',
        ]);
        header('Location: ' . $url, true, 302);
        exit;
    }

    /* ------------------------------------------------------ 2) retorno */
    if (isset($_GET['error'])) {
        html_page('Login cancelado', 'Você cancelou o login com o Google. Pode fechar esta aba e voltar ao AURA MSN.', false);
        exit;
    }
    $parts = explode('.', (string)($_GET['state'] ?? ''));
    if (count($parts) !== 2 || !hash_equals(sign($parts[0]), $parts[1])) {
        html_page('Link inválido', 'Abra o login com o Google pelo próprio AURA MSN.', false);
        exit;
    }
    $st = json_decode(b64url_dec($parts[0]), true) ?: [];
    if (time() - (int)($st['t'] ?? 0) > 900 || !hash_equals((string)($st['n'] ?? ''), (string)($_COOKIE['aura_g'] ?? ''))) {
        html_page('Login expirado', 'Demorou demais ou o navegador bloqueou cookies. Tente de novo pelo AURA MSN.', false);
        exit;
    }
    setcookie('aura_g', '', ['expires' => time() - 3600, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax']);

    $tok = http_post_form('https://oauth2.googleapis.com/token', [
        'code' => (string)($_GET['code'] ?? ''), 'client_id' => $clientId, 'client_secret' => $clientSecret,
        'redirect_uri' => $redirect, 'grant_type' => 'authorization_code',
    ]);
    if (empty($tok['access_token'])) {
        html_page('Não deu certo', 'O Google não confirmou o login. Confira o Client ID e o Client Secret no config.php.', false);
        exit;
    }
    $info = http_get_json('https://openidconnect.googleapis.com/v1/userinfo', $tok['access_token']);
    $sub = (string)($info['sub'] ?? '');
    $email = norm_email((string)($info['email'] ?? ''));
    if ($sub === '' || !valid_email($email) || empty($info['email_verified'])) {
        html_page('Não deu certo', 'Essa conta do Google não tem um e-mail confirmado.', false);
        exit;
    }
    $name = mb_substr(trim((string)($info['name'] ?? '')), 0, 80) ?: explode('@', $email)[0];

    $u = row('SELECT * FROM aura_users WHERE google_sub = ?', [$sub]);
    if (!$u) {
        $u = row('SELECT * FROM aura_users WHERE email = ?', [$email]);
        if ($u) {
            // mesma pessoa que já tinha conta com senha: liga o Google a ela.
            // Se a conta nunca foi confirmada, a senha antiga é descartada (pode ter sido outra pessoa).
            $keepPass = $u['verified'] ? $u['pass_hash'] : null;
            q('UPDATE aura_users SET google_sub = ?, verified = 1, pass_hash = ? WHERE id = ?', [$sub, $keepPass, $u['id']]);
        } else {
            q('INSERT INTO aura_users (email, google_sub, verified, name, created) VALUES (?, ?, 1, ?, ?)', [$email, $sub, $name, time()]);
        }
        $u = row('SELECT * FROM aura_users WHERE google_sub = ?', [$sub]);
    }

    $ticket = new_token();
    q('INSERT INTO aura_tickets (ticket_hash, user_id, expires) VALUES (?, ?, ?)', [token_hash($ticket), $u['id'], time() + 180]);
    $back = 'http://127.0.0.1:' . (int)$st['p'] . '/auth/google?' . http_build_query(['ticket' => $ticket, 'state' => $st['s']]);
    header('Location: ' . $back, true, 302);
} catch (Throwable $e) {
    error_log('AURA google: ' . $e->getMessage());
    html_page('Erro no servidor', 'Algo deu errado no login com o Google. Tente de novo em instantes.', false);
}
