<?php
/* AURA MSN — cria as tabelas no MySQL. Pode abrir quantas vezes quiser: nunca apaga dados. */
declare(strict_types=1);
require __DIR__ . '/lib.php';

$checks = [];
$checks[] = ['PHP 7.4 ou mais novo', version_compare(PHP_VERSION, '7.4.0', '>='), 'versão ' . PHP_VERSION];
$checks[] = ['Extensão pdo_mysql', extension_loaded('pdo_mysql'), ''];
$checks[] = ['Extensão curl (para o Google)', extension_loaded('curl'), 'só precisa se for usar "Entrar com Google"'];
$checks[] = ['Extensão mbstring', extension_loaded('mbstring'), ''];
if (!is_dir(STORAGE_DIR)) @mkdir(STORAGE_DIR, 0755, true);
$checks[] = ['Pasta "dados" com permissão de escrita', is_writable(STORAGE_DIR), STORAGE_DIR];

$schema = [
"CREATE TABLE IF NOT EXISTS aura_settings (
  k VARCHAR(40) NOT NULL PRIMARY KEY,
  v TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  pass_hash VARCHAR(255) NULL,
  google_sub VARCHAR(64) NULL,
  verified TINYINT(1) NOT NULL DEFAULT 0,
  name VARCHAR(80) NOT NULL DEFAULT '',
  psm VARCHAR(200) NOT NULL DEFAULT '',
  status VARCHAR(12) NOT NULL DEFAULT 'online',
  avatar MEDIUMTEXT NULL,
  avatar_hash VARCHAR(40) NOT NULL DEFAULT '',
  last_seen INT UNSIGNED NOT NULL DEFAULT 0,
  seen_public INT UNSIGNED NOT NULL DEFAULT 0,
  created INT UNSIGNED NOT NULL DEFAULT 0,
  UNIQUE KEY uq_email (email),
  UNIQUE KEY uq_google (google_sub)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_sessions (
  token_hash CHAR(64) NOT NULL PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  device VARCHAR(80) NOT NULL DEFAULT '',
  created INT UNSIGNED NOT NULL,
  last_used INT UNSIGNED NOT NULL,
  KEY k_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_codes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  purpose VARCHAR(10) NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  expires INT UNSIGNED NOT NULL,
  tries TINYINT UNSIGNED NOT NULL DEFAULT 0,
  KEY k_user (user_id, purpose)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_tickets (
  ticket_hash CHAR(64) NOT NULL PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  expires INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_attempts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  k VARCHAR(220) NOT NULL,
  created INT UNSIGNED NOT NULL,
  KEY k_key (k, created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_contacts (
  owner INT UNSIGNED NOT NULL,
  contact INT UNSIGNED NOT NULL,
  state VARCHAR(3) NOT NULL,
  blocked TINYINT(1) NOT NULL DEFAULT 0,
  created INT UNSIGNED NOT NULL,
  PRIMARY KEY (owner, contact),
  KEY k_contact (contact)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  from_id INT UNSIGNED NOT NULL,
  kind VARCHAR(12) NOT NULL,
  payload MEDIUMTEXT NOT NULL,
  created INT UNSIGNED NOT NULL,
  KEY k_user (user_id, id),
  KEY k_created (created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
"CREATE TABLE IF NOT EXISTS aura_files (
  id CHAR(32) NOT NULL PRIMARY KEY,
  owner INT UNSIGNED NOT NULL,
  recipient INT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  size INT UNSIGNED NOT NULL,
  mime VARCHAR(100) NOT NULL,
  received INT UNSIGNED NOT NULL DEFAULT 0,
  complete TINYINT(1) NOT NULL DEFAULT 0,
  created INT UNSIGNED NOT NULL,
  KEY k_created (created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
];

$dbOk = true; $dbMsg = '';
try {
    foreach ($schema as $sql) db()->exec($sql);
    secret();
    setting('schema', '1');
    $users = (int)val('SELECT COUNT(*) FROM aura_users');
    $dbMsg = "tabelas prontas — $users conta(s) cadastrada(s)";
} catch (Throwable $e) {
    $dbOk = false;
    $dbMsg = 'não conectou: ' . $e->getMessage();
}
$checks[] = ['Banco de dados MySQL', $dbOk, $dbMsg];
$checks[] = ['site_url no config.php', strpos((string)cfg('site_url'), 'https://') === 0, (string)cfg('site_url')];
$checks[] = ['mail_from no config.php', valid_email((string)cfg('mail_from')), (string)cfg('mail_from')];
$g = cfg('google_client_id') && cfg('google_client_secret');
$checks[] = ['Entrar com Google', $g ? true : null, $g ? 'configurado — endereço de retorno: ' . cfg('site_url') . '/google.php' : 'desligado (opcional)'];

header('Content-Type: text/html; charset=utf-8');
$allOk = !in_array(false, array_column($checks, 1), true);
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Instalação do servidor AURA MSN</title></head>
<body style="margin:0;background:#eef1f7;font-family:Segoe UI,Arial,sans-serif;color:#182031">
<div style="max-width:640px;margin:30px auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.08)">
<div style="padding:22px 26px;color:#fff;background:linear-gradient(135deg,#3b82f6,#8b5cf6 60%,#14b8a6)"><b style="font-size:21px">Servidor AURA MSN</b><div>Verificação da instalação · v<?= AURA_SERVER_VERSION ?></div></div>
<div style="padding:16px 26px 24px">
<?php foreach ($checks as [$label, $ok, $info]): ?>
  <div style="display:flex;gap:12px;padding:9px 0;border-bottom:1px solid #eef1f7">
    <div style="font-size:18px;width:22px"><?= $ok === true ? '✅' : ($ok === null ? '➖' : '❌') ?></div>
    <div><b><?= htmlspecialchars($label) ?></b><div style="color:#6b7489;font-size:13px;word-break:break-all"><?= htmlspecialchars((string)$info) ?></div></div>
  </div>
<?php endforeach; ?>
<p style="margin-top:18px;font-size:15px"><?= $allOk
  ? '🎉 <b>Tudo certo!</b> Coloque este endereço no arquivo <code>aura_config.json</code> do aplicativo: <code>' . htmlspecialchars((string)cfg('site_url')) . '</code>'
  : 'Corrija os itens com ❌ no <code>config.php</code> e recarregue esta página.' ?></p>
</div></div></body></html>
