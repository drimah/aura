<?php
/* AURA MSN — funções compartilhadas do servidor (PHP 7.4+ / 8.x, MySQL 5.7+ / MariaDB 10.3+) */
declare(strict_types=1);

if (!is_file(__DIR__ . '/config.php')) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit("AURA MSN: falta o arquivo config.php. Renomeie config.exemplo.php para config.php e preencha.\n");
}
$GLOBALS['CFG'] = require __DIR__ . '/config.php';
date_default_timezone_set('America/Sao_Paulo');

const AURA_SERVER_VERSION = '1.0.0';
const STORAGE_DIR = __DIR__ . '/dados';
const ONLINE_TTL = 25;          // segundos sem "poll" => offline
const CHUNK_MAX = 1100000;      // tamanho máximo de cada pedaço de arquivo (bytes)
const MAX_TEXT = 8000;

function cfg(string $k, $default = null) { return $GLOBALS['CFG'][$k] ?? $default; }

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = 'mysql:host=' . cfg('db_host', 'localhost') . ';dbname=' . cfg('db_name') . ';charset=utf8mb4';
    $pdo = new PDO($dsn, cfg('db_user'), cfg('db_pass'), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    return $pdo;
}

function q(string $sql, array $args = []): PDOStatement {
    $st = db()->prepare($sql);
    $st->execute($args);
    return $st;
}
function row(string $sql, array $args = []): ?array { $r = q($sql, $args)->fetch(); return $r ?: null; }
function val(string $sql, array $args = []) { $r = q($sql, $args)->fetchColumn(); return $r === false ? null : $r; }

class ApiError extends Exception {
    public $status;
    public $extra;
    public function __construct(string $msg, int $status = 400, array $extra = []) {
        parent::__construct($msg);
        $this->status = $status;
        $this->extra = $extra;
    }
}
function fail(string $msg, int $status = 400, array $extra = []): void { throw new ApiError($msg, $status, $extra); }

function out(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function body(): array {
    static $b = null;
    if ($b !== null) return $b;
    $raw = file_get_contents('php://input') ?: '';
    $b = $raw === '' ? [] : json_decode($raw, true);
    if (!is_array($b)) fail('JSON inválido');
    return $b;
}
function str_in(array $d, string $k, int $max = 255): string {
    $v = $d[$k] ?? '';
    if (!is_string($v) && !is_numeric($v)) return '';
    $v = trim((string)$v);
    return mb_substr($v, 0, $max);
}

function setting(string $k, ?string $set = null): ?string {
    if ($set !== null) {
        q('REPLACE INTO aura_settings (k, v) VALUES (?, ?)', [$k, $set]);
        return $set;
    }
    $v = val('SELECT v FROM aura_settings WHERE k = ?', [$k]);
    return $v === null ? null : (string)$v;
}
function secret(): string {
    $s = setting('secret');
    if (!$s) $s = setting('secret', bin2hex(random_bytes(32)));
    return $s;
}

function client_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }
function token_hash(string $t): string { return hash('sha256', $t); }
function new_token(): string { return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '='); }
function b64url(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function b64url_dec(string $s): string { return (string)base64_decode(strtr($s, '-_', '+/')); }

/* --------------------------------------------------- limite de tentativas */
function too_many(string $key, int $max, int $window): bool {
    $n = (int)val('SELECT COUNT(*) FROM aura_attempts WHERE k = ? AND created > ?', [$key, time() - $window]);
    return $n >= $max;
}
function hit(string $key): void { q('INSERT INTO aura_attempts (k, created) VALUES (?, ?)', [$key, time()]); }
function guard(string $key, int $max, int $window, string $msg = 'Muitas tentativas. Espere alguns minutos e tente de novo.'): void {
    if (too_many($key, $max, $window)) fail($msg, 429);
    hit($key);
}

/* ------------------------------------------------------------- sessão */
function current_user(): array {
    $tok = (string)($_SERVER['HTTP_X_AURA_TOKEN'] ?? '');
    if ($tok === '' || strlen($tok) > 100) fail('Sessão expirada. Entre de novo.', 401);
    $u = row('SELECT u.*, s.token_hash FROM aura_sessions s JOIN aura_users u ON u.id = s.user_id WHERE s.token_hash = ?',
             [token_hash($tok)]);
    if (!$u) fail('Sessão expirada. Entre de novo.', 401);
    return $u;
}
function create_session(int $uid, string $device = ''): string {
    $t = new_token();
    q('INSERT INTO aura_sessions (token_hash, user_id, device, created, last_used) VALUES (?, ?, ?, ?, ?)',
      [token_hash($t), $uid, mb_substr($device, 0, 80), time(), time()]);
    return $t;
}
function user_public(array $u): array {
    return [
        'id' => (int)$u['id'], 'email' => $u['email'], 'name' => $u['name'], 'psm' => $u['psm'],
        'status' => $u['status'], 'avatar' => $u['avatar'] ?? '', 'ah' => $u['avatar_hash'] ?? '',
        'google' => !empty($u['google_sub']), 'has_password' => !empty($u['pass_hash']),
    ];
}
function login_result(array $u, string $device = ''): array {
    return ['ok' => true, 'token' => create_session((int)$u['id'], $device), 'user' => user_public($u)];
}

/* ------------------------------------------------------------- e-mail */
function valid_email(string $e): bool { return strlen($e) <= 190 && (bool)filter_var($e, FILTER_VALIDATE_EMAIL); }
function norm_email(string $e): string { return mb_strtolower(trim($e)); }

function send_mail(string $to, string $subject, string $html, string $text): bool {
    $from = cfg('mail_from');
    $name = cfg('mail_name', 'AURA MSN');
    $b = 'aura' . bin2hex(random_bytes(8));
    $headers = [
        'From: =?UTF-8?B?' . base64_encode($name) . "?= <$from>",
        "Reply-To: $from",
        'MIME-Version: 1.0',
        "Content-Type: multipart/alternative; boundary=\"$b\"",
        'X-Mailer: AURA-MSN',
    ];
    $msg = "--$b\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
         . chunk_split(base64_encode($text))
         . "--$b\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
         . chunk_split(base64_encode($html)) . "--$b--\r\n";
    $subj = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    return @mail($to, $subj, $msg, implode("\r\n", $headers), '-f' . $from);
}

function mail_layout(string $title, string $inner): string {
    $t = htmlspecialchars($title);
    return '<!doctype html><html><body style="margin:0;background:#eef1f7;font-family:Segoe UI,Arial,sans-serif;color:#182031">'
        . '<div style="max-width:480px;margin:24px auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.08)">'
        . '<div style="padding:22px 24px;color:#fff;background:linear-gradient(135deg,#3b82f6,#8b5cf6 60%,#14b8a6)">'
        . '<div style="font-size:20px;font-weight:700">AURA MSN</div><div style="opacity:.9">' . $t . '</div></div>'
        . '<div style="padding:22px 24px;font-size:15px;line-height:1.5">' . $inner . '</div>'
        . '<div style="padding:12px 24px 20px;color:#6b7489;font-size:12px">Se não foi você, é só ignorar este e-mail.</div>'
        . '</div></body></html>';
}

function send_code(array $u, string $purpose): void {
    // no máximo 5 e-mails por hora para o mesmo endereço
    guard('mail:' . $u['email'], 5, 3600, 'Já enviamos vários códigos. Confira sua caixa de entrada e o spam, ou espere uma hora.');
    $code = (string)random_int(100000, 999999);
    q('DELETE FROM aura_codes WHERE user_id = ? AND purpose = ?', [$u['id'], $purpose]);
    q('INSERT INTO aura_codes (user_id, purpose, code_hash, expires, tries) VALUES (?, ?, ?, ?, 0)',
      [$u['id'], $purpose, password_hash($code, PASSWORD_DEFAULT), time() + 1800]);
    $nome = htmlspecialchars($u['name'] ?: 'olá');
    if ($purpose === 'verify') {
        $subject = "Seu código do AURA MSN: $code";
        $intro = "Oi, $nome! Para confirmar seu e-mail e ativar sua conta, digite este código no AURA MSN:";
        $title = 'Confirme seu e-mail';
    } else {
        $subject = "Código para trocar a senha do AURA MSN: $code";
        $intro = "Oi, $nome! Recebemos um pedido para trocar a senha da sua conta. Digite este código no AURA MSN:";
        $title = 'Trocar senha';
    }
    $html = mail_layout($title, "<p>$intro</p><p style=\"font-size:34px;font-weight:700;letter-spacing:8px;text-align:center;margin:18px 0\">$code</p><p style=\"color:#6b7489\">O código vale por 30 minutos.</p>");
    $text = strip_tags(str_replace('</p>', "\n\n", $intro)) . "\n\n    $code\n\nO código vale por 30 minutos.\n";
    if (!send_mail($u['email'], $subject, $html, $text)) {
        fail('O servidor não conseguiu enviar o e-mail. Confira o "mail_from" no config.php.', 500);
    }
}

function check_code(array $u, string $purpose, string $code): void {
    $c = row('SELECT * FROM aura_codes WHERE user_id = ? AND purpose = ?', [$u['id'], $purpose]);
    if (!$c || (int)$c['expires'] < time()) fail('Código vencido. Peça um novo.');
    if ((int)$c['tries'] >= 6) fail('Tentativas demais com esse código. Peça um novo.');
    if (!password_verify(preg_replace('/\D/', '', $code), $c['code_hash'])) {
        q('UPDATE aura_codes SET tries = tries + 1 WHERE id = ?', [$c['id']]);
        fail('Código incorreto.');
    }
    q('DELETE FROM aura_codes WHERE id = ?', [$c['id']]);
}

/* ------------------------------------------------------------- limpeza */
function maybe_cleanup(): void {
    if (random_int(1, 200) !== 1) return;
    $old = time() - 86400 * (int)cfg('keep_days', 30);
    q('DELETE FROM aura_events WHERE created < ? OR (kind = "typing" AND created < ?)', [$old, time() - 120]);
    q('DELETE FROM aura_attempts WHERE created < ?', [time() - 86400]);
    q('DELETE FROM aura_codes WHERE expires < ?', [time()]);
    q('DELETE FROM aura_tickets WHERE expires < ?', [time()]);
    q('DELETE FROM aura_sessions WHERE last_used < ?', [time() - 86400 * 180]);
    foreach (q('SELECT id FROM aura_files WHERE created < ?', [$old])->fetchAll() as $f) {
        @unlink(file_path($f['id']));
    }
    q('DELETE FROM aura_files WHERE created < ?', [$old]);
}
function file_path(string $fid): string { return STORAGE_DIR . '/' . preg_replace('/[^a-f0-9]/', '', $fid) . '.bin'; }

function html_page(string $title, string $msg, bool $ok = true): void {
    header('Content-Type: text/html; charset=utf-8');
    $c = $ok ? '#22c55e' : '#ef4444';
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AURA MSN</title></head>'
       . '<body style="margin:0;min-height:100vh;display:grid;place-items:center;background:linear-gradient(135deg,#3b82f6,#8b5cf6 60%,#14b8a6);font-family:Segoe UI,Arial,sans-serif">'
       . '<div style="background:#fff;border-radius:18px;padding:30px 34px;max-width:420px;text-align:center;box-shadow:0 10px 40px rgba(0,0,0,.2)">'
       . '<div style="font-size:44px;color:' . $c . '">' . ($ok ? '✔' : '⚠') . '</div>'
       . '<h1 style="font-size:21px;margin:8px 0">' . htmlspecialchars($title) . '</h1>'
       . '<p style="color:#4b5468;line-height:1.5">' . $msg . '</p></div></body></html>';
}
